package set.tests;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class SetTest1 {

    public static void main(String[] args) {
        Set<String> s = new HashSet<String>();
        s.add("1");
        s.add("2");
        s.add("3");
        s.add("4");
        s.add("5");
        s.add("6");
        s.add("7");

        Set<String> delSet = new HashSet<>();
        for (String str : s) {
            if (Integer.parseInt(str) % 2 == 0) {
                delSet.add(str);
            }
        }
        
        s.removeAll(delSet);
        for (String str : s) {
            System.out.println(str);
        }
    }
}
