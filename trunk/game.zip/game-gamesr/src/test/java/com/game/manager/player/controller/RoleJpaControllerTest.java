/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.game.manager.player.controller;

import com.game.po.player.controller.RoleJpaController;
import com.game.engine.utils.Config;
import com.game.po.player.Role;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Vicky
 */
public class RoleJpaControllerTest {
    
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
    
    public RoleJpaControllerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        Config.serverID = 20001;
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of create method, of class RoleJpaController.
     */
    @Test
    public void testCreate() throws Exception {
//        System.out.println("create");
//        Role role = new Role();
//        role.setUserid(10001);
//        role.setUsername("vicky");
//        role.setName("张三");
//        role.setServerid(20001);
//        RoleJpaController instance = new RoleJpaController(emf);
//        instance.create(role);
    }

    /**
     * Test of edit method, of class RoleJpaController.
     */
    @Test
    public void testEdit() throws Exception {
        System.out.println("edit");
    }

    /**
     * Test of destroy method, of class RoleJpaController.
     */
    @Test
    public void testDestroy() throws Exception {
        System.out.println("destroy");
    }

    /**
     * Test of findRoleEntities method, of class RoleJpaController.
     */
    @Test
    public void testFindRoleEntities_0args() {
        System.out.println("findRoleEntities");
    }

    /**
     * Test of findRoleEntities method, of class RoleJpaController.
     */
    @Test
    public void testFindRoleEntities_int_int() {
        System.out.println("findRoleEntities");
    }

    /**
     * Test of findRole method, of class RoleJpaController.
     */
    @Test
    public void testFindRole() {
        System.out.println("findRole");
    }

    /**
     * Test of getRoleCount method, of class RoleJpaController.
     */
    @Test
    public void testGetRoleCount() {
        System.out.println("getRoleCount");
    }
    
}
