package com.game.proto.handler.login;

import com.game.engine.io.commmand.TcpHandler;
import com.game.engine.io.mina.utils.SessionUtil;
import com.game.gamesr.main.Main;
import com.game.gamesr.server.tcp.GameTcpServer;
import com.game.proto.LoginMessage;
import java.util.Map;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class ReqTokenLoginHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(ReqTokenLoginHandler.class);

    @Override
    public void run() {
        // TODO 处理LoginMessage.ReqTokenLogin消息
        LoginMessage.ReqTokenLoginMessage reqMessage = (LoginMessage.ReqTokenLoginMessage) getMessage();

        System.out.println("ReqTokenLoginMessageHandler::" + reqMessage);

        String ip = SessionUtil.getIp(getSession());
        GameTcpServer.TmpClientInfo tmpClientInfo = Main.getGameServer().getGameTcpServer().removeTmpClient(ip);
        if (tmpClientInfo == null) {
            log.error("无法获得ip:" + ip + "的临时链接信息");
            SessionUtil.close(getSession(), "未找到临时链接信息");
            return;
        }

        //ReqTokenLoginMessageHandler::token: "9aa38a7a-0cfa-4b7d-84d6-ffb0b2712192"
        //userID: 2        
        {
            // 请求LS ,验证Token是否正确
            if (reqMessage.getToken().trim().equals("")) {
                log.error("TOKEN为空");
                SessionUtil.close(getSession(), "TOKEN为空");
                return;
            }
            // 设置验证请求的消息 GLTokenCheckMessage
            LoginMessage.GLTokenCheckMessage.Builder builder = LoginMessage.GLTokenCheckMessage.newBuilder();
            builder.setToken(reqMessage.getToken());
            builder.setUserID(reqMessage.getUserID());
            builder.setUsername(reqMessage.getUsername());
            // 创建验证消息实例
            LoginMessage.GLTokenCheckMessage tokenCheckMessage = builder.build();
            // 把客户端传过来的 token 放到零时变量，
            Main.getGameServer().getGameTcpServer().putTmpClientToken(reqMessage.getToken(), getSession());
            // 然后发送 token 到 login 服务器严重
            // 获得链接的登录服务器
            Map<Integer, IoSession> typeSessions = Main.getGameServer().getGameTcpClient().getSession(1);
            for (IoSession session : typeSessions.values()) {
                if (session != null && session.isConnected()) {
                    // 发送严重命令
                    session.write(tokenCheckMessage);
                }
            }
        }
    }
}
