package com.game.proto.handler.login;

import com.game.engine.io.commmand.TcpHandler;
import com.game.engine.io.mina.utils.SessionUtil;
import com.game.engine.thread.db.CRUDCommand;
import com.game.gamesr.main.Main;
import com.game.manager.backpack.BackpackManager;
import com.game.manager.data.DataManager;
import com.game.manager.gm.GMCommandManager;
import com.game.manager.map.MapManager;
import com.game.manager.player.PlayerManager;
import com.game.manager.player.UserManager;
import com.game.po.log.RoleCreateLog;
import com.game.po.player.Role;
import com.game.proto.LoginMessage;
import com.game.service.log.LogService;
import com.game.structs.player.JobType;
import com.game.structs.player.Player;
import com.game.structs.player.PlayerState;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class ReqCreateCharacterHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(ReqCreateCharacterHandler.class);

    @Override
    public void run() {
        // TODO 处理LoginMessage.ReqCreateCharacter消息
        LoginMessage.ReqCreateCharacterMessage reqMessage = (LoginMessage.ReqCreateCharacterMessage) getMessage();
        try {
            long start = System.currentTimeMillis();

            long userid = (Long) getSession().getAttribute(UserManager.USER_ID);
            String username = (String) getSession().getAttribute(UserManager.USER_NAME);

            LoginMessage.ResCreateCharacterFailedMessage.Builder resFailBuilder = LoginMessage.ResCreateCharacterFailedMessage.newBuilder();

            if (userid < 1 || username == null || username.trim().equals("")) {
                log.error("创建角色的Session未包含USER_ID / USER_NAME :: " + userid + " " + username);
                resFailBuilder.setReason(1);
                getSession().write(resFailBuilder.build());
                return;
            }

            log.info("查询帐号角色信息");
            List<Role> roles = DataManager.getInstance().getRoleDao().selectByUser(userid, username, Main.getServerID());

            log.info("角色数量验证");
            if (roles.size() > PlayerManager.MAXCANCREATE) {
                // 禁止玩家创建多角色
                log.debug("已经创建了：" + roles.size() + "个角色" + userid);

                resFailBuilder.setReason(2);
                getSession().write(resFailBuilder.build());
                return;
            }

            log.info("名称验证");
            String name = reqMessage.getName();
            int checkNameAll = PlayerManager.getInstance().checkNameAll(name, true);
            if (checkNameAll > 0) {
                resFailBuilder.setReason(checkNameAll);
                getSession().write(resFailBuilder.build());
                return;
            }

            log.info("职业验证");
            if (reqMessage.getJob() < JobType.WARR_JOB.getJob() || reqMessage.getJob() > JobType.HUNT_JOB.getJob()) {
                // 非法提示
                log.debug("玩家职业非法：" + reqMessage.getJob());

                resFailBuilder.setReason(5);
                getSession().write(resFailBuilder.build());
                return;
            }

            log.info("性别验证");
            if (reqMessage.getSex() < 1 || reqMessage.getSex() > 2) {
                // 非法提示
                log.debug("玩家性别非法：" + reqMessage.getJob());

                resFailBuilder.setReason(6);
                getSession().write(resFailBuilder.build());
                return;
            }

            log.info("创建玩家" + name);
            Player player = PlayerManager.getInstance().createPlayer(name, reqMessage.getIcon(), reqMessage.getSex(), reqMessage.getJob());

            // 账号id
            player.setUserid(userid);
            // 账号名字
            player.setUsername(username);
            // 创建服务器
            player.setServerid(Main.getServerID());
            // 服务器名
            player.setServername(Main.getServerName());
            // 平台
            player.setServerweb(Main.getServerWeb());
            // 创建时间
            player.setCreateTime(System.currentTimeMillis());
            // ip
            player.setLoginIP(SessionUtil.getIp(getSession()));
            // 平台参数1
            player.setAgentPlusdata(reqMessage.getAgentPlusdata());
            // 平台参数2
            player.setAgentColdatas(reqMessage.getAgentColdatas());
            // 玩家为登陆状态
            player.setState(PlayerState.LOGIN);
            // 设置未成年状态
            player.setAdult(false);

            log.info("保存玩家" + name);
            try {
                PlayerManager.getInstance().insertPlayer(player);
            } catch (Exception e) {
                log.error("玩家数据写入数据库失败", e);

                PlayerManager.getInstance().removeName(name);

                // 数据库错误
                resFailBuilder.setReason(8);
                getSession().write(resFailBuilder.build());
                return;
            }

            log.info("加载金币" + name);
            try {
                BackpackManager.getInstance().loadGold(player);
            } catch (Exception e) {
                log.error("加载玩家金币失败", e);

                // 数据库错误
                resFailBuilder.setReason(9);
                getSession().write(resFailBuilder.build());
                return;
            }

            log.info("加载GM等级" + name);
            GMCommandManager.getInstance().reloadGMLevel(player);

            // 注册玩家
            PlayerManager.getInstance().registerPlayer(player);

            // 注册玩家状态
            // LogService.getInstance().updateRoleDate(player.getId());

            // 分配玩家所在线
            MapManager.getInstance().selectLine(player);

            log.debug(player.getUserid() + ":" + player.getUsername() + ":创建玩家" + player.getId() + "选线为" + player.getLine());

            log.info(Thread.currentThread() + "-->创建角色 cost:" + (System.currentTimeMillis() - start) + " ms");

            // 角色创建日志
            if (!player.getUsername().contains("#robot")) {
                RoleCreateLog createLog = new RoleCreateLog(player);
                CRUDCommand<RoleCreateLog> command = new CRUDCommand<>(
                        LogService.CRUD,
                        CRUDCommand.CRUD.CREAT,
                        createLog
                );
                LogService.getInstance().execute(command);
            }

            {
                // 返回角色列表
                Set<Player> players = new HashSet<>();
                players.add(player);

                for (Role role : roles) {
                    Player p = role.getPlayer();
                    if (p != null) {
                        players.add(p);
                    }
                }

                LoginMessage.ResTokenLoginMessage.Builder resBuilder = LoginMessage.ResTokenLoginMessage.newBuilder();
                resBuilder.setResult(1);
                for (Player p : players) {
                    resBuilder.addPlayers(PlayerManager.getInstance().buildPlayerBase(p));
                }
                getSession().write(resBuilder.build());
            }
        } catch (Exception e) {
            log.error("创建角色异常", e);
            LoginMessage.ResTokenLoginMessage.Builder resBuilder = LoginMessage.ResTokenLoginMessage.newBuilder();
            resBuilder.setResult(2);
            getSession().write(resBuilder.build());
        }

    }
}
