package com.game.proto.handler.login;

import com.game.engine.io.commmand.TcpHandler;
import com.game.engine.script.IBaseScript;
import com.game.engine.script.manager.ScriptManager;
import com.game.manager.player.PlayerManager;
import com.game.manager.player.script.ISelectPlayerScript;
import com.game.proto.LoginMessage;
import com.game.structs.player.Player;
import com.game.structs.player.PlayerState;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class ReqSelectPlayerHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(ReqSelectPlayerHandler.class);

    @Override
    public void run() {
        // TODO 处理LoginMessage.ReqSelectPlayer消息
        LoginMessage.ReqSelectPlayerMessage reqMessage = (LoginMessage.ReqSelectPlayerMessage) getMessage();
        LoginMessage.ResSelectPlayerMessage.Builder builder4Res = LoginMessage.ResSelectPlayerMessage.newBuilder();
        
        long playerid = reqMessage.getPlayerid();
        Player player = PlayerManager.getInstance().getPlayerFromRegister(playerid);
        if (player == null) {
            log.error("从缓冲区中获得玩家失败:" + playerid);
            return;
        }
        
        List<IBaseScript> evts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(ISelectPlayerScript.class.getName());
        Iterator<IBaseScript> iterator = evts.iterator();
        while (iterator.hasNext()) {
            ((ISelectPlayerScript)iterator.next()).action(player);
        }
        
        {
            // 死亡复活
            if (player.getHp() == 0 && !player.isDie()) {
                player.setHp(911/*playerFromRegister.getFinalAbility().getMaxHp()*/); // TODO 获得最终属性
                player.setMp(911/*playerFromRegister.getFinalAbility().getMaxMp()*/);
                player.setState(PlayerState.NOTHING);
            }
        }
        
        // 设置选择登录的角色ID到session中
        getSession().setAttribute(PlayerManager.LOGINPLAYERID, playerid);
        
        PlayerManager.getInstance().savePlayer(player, true);
        
        builder4Res.setMapId(player.getMapId());
        builder4Res.setMapModelId(player.getMapModelId());
        builder4Res.setX(player.getPosition().getX());
        builder4Res.setZ(player.getPosition().getY());
        
        getSession().write(builder4Res.build());
        
        log.info("玩家" + player.getUserid() + "角色" + player.getId() + "被选择了！");
    }
}
