package com.game.proto.handler.login;

import com.game.engine.io.commmand.TcpHandler;
import com.game.gamesr.main.Main;
import com.game.gamesr.server.tcp.GameTcpServer;
import com.game.manager.data.DataManager;
import com.game.manager.player.PlayerManager;
import com.game.manager.player.UserManager;
import com.game.po.player.Role;
import com.game.proto.LoginMessage;
import com.game.structs.player.Player;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * game server 请求验证token 完成 login server回调处理
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class LGTokenCheckHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(LGTokenCheckHandler.class);

    @Override
    public void run() {
        // TODO 处理LoginMessage.LGTokenCheck消息
        LoginMessage.LGTokenCheckMessage reqMessage = (LoginMessage.LGTokenCheckMessage) getMessage();

        System.out.println(reqMessage);

        String token = reqMessage.getToken();
        long userid = reqMessage.getUserID();
        String username = reqMessage.getUsername();
        if (userid == 0 || username == null || username.trim().equals("")) {
            log.error("请求参数不正确 userID:" + userid + " username:" + username);
            return;
        }

        GameTcpServer.TmpClientTokenInfo removeTmpClientToken = Main.getGameServer().getGameTcpServer().removeTmpClientToken(token);
        if (removeTmpClientToken == null) {
            log.error("无法找到TmpClientTokenInfo");
            return;
        }

        // 找到请求的用户,并返回结果
        IoSession session = removeTmpClientToken.getSession();
        if (session == null || !session.isConnected()) {
            log.error("Token登录验证后,玩家链接已经断开 session:" + session);
            LoginMessage.ResTokenLoginMessage.Builder resBuilder = LoginMessage.ResTokenLoginMessage.newBuilder();
            resBuilder.setResult(1);
            session.write(resBuilder.build());
            return;
        }

        session.setAttribute(UserManager.USER_ID, userid);
        session.setAttribute(UserManager.USER_NAME, username);

        {
            List<Role> roles = DataManager.getInstance().getRoleDao().selectByUser(userid, username, Main.getServerID());

            // 返回角色列表
            Set<Player> players = new HashSet<>();
            for (Role role : roles) {
                Player p = role.getPlayer();
                if (p != null) {
                    players.add(p);

                    PlayerManager.getInstance().registerPlayer(p);
                }
            }

            LoginMessage.ResTokenLoginMessage.Builder resBuilder = LoginMessage.ResTokenLoginMessage.newBuilder();
            resBuilder.setResult(0);
            for (Player p : players) {
                resBuilder.setResult(1);
                resBuilder.addPlayers(PlayerManager.getInstance().buildPlayerBase(p));
            }
            session.write(resBuilder.build());
        }

    }
}
