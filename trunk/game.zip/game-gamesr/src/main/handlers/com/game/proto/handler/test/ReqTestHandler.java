package com.game.proto.handler.test;

import com.game.engine.io.commmand.TcpHandler;
import com.game.engine.io.mina.utils.SessionUtil;
import com.game.manager.player.PlayerManager;
import com.game.proto.TestMessage;
import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class ReqTestHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(ReqTestHandler.class);

    @Override
    public void run() {
        // TODO 处理TestMessage.ReqTest消息
        TestMessage.ReqTestMessage reqMessage = (TestMessage.ReqTestMessage) getMessage();

        log.info("reqMessage.getUserID() " + reqMessage.getUserID() + " reqMessage.getPlayerName() " + reqMessage.getPlayerName() + " reqMessage.getToken() " + reqMessage.getToken());

        Player p = PlayerManager.getInstance().getOnline().get(reqMessage.getUserID());

        //Player player = (Player) getParameter();
        TestMessage.ResTestMessage.Builder builder4Res = TestMessage.ResTestMessage.newBuilder();
        builder4Res.setToken(reqMessage.getToken());
        builder4Res.setPlayerName(reqMessage.getPlayerName());
        builder4Res.setUserID(reqMessage.getUserID());
        getSession().write(builder4Res.build());

        //SessionUtil.send(player, builder4Res.build());
    }
}
