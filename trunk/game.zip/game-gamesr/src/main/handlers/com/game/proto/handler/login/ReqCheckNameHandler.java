package com.game.proto.handler.login;

import com.game.engine.io.commmand.TcpHandler;
import com.game.manager.player.PlayerManager;
import com.game.proto.LoginMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class ReqCheckNameHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(ReqCheckNameHandler.class);

    @Override
    public void run() {
        // TODO 处理LoginMessage.ReqCheckName消息
        LoginMessage.ReqCheckNameMessage reqMessage = (LoginMessage.ReqCheckNameMessage) getMessage();
        LoginMessage.ResCheckNameMessage.Builder builder4Res = LoginMessage.ResCheckNameMessage.newBuilder();
        
        String name = reqMessage.getName();
        switch (reqMessage.getType()) {
            case 1: // 角色名验证
                int checkNameAll = PlayerManager.getInstance().checkNameAll(name, false);
                builder4Res.setErrCode(checkNameAll);
                break;
            case 2: // 家族名称验证
                break;
            case 3: // 帮会名称验证
                break;
            default:
                builder4Res.setErrCode(1); // 未知的验证类型
                break;
        }
        
        getSession().write(builder4Res.build());
        
    }
}
