package com.game.proto.handler.chat;

import com.game.engine.io.commmand.TcpHandler;
import com.game.manager.map.MapManager;
import com.game.manager.player.PlayerManager;
import com.game.proto.ChatMessage;
import com.game.structs.player.Player;
import com.game.structs.player.PlayerState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Troy.Chen
 * @mail 492794628@qq.com
 * @phone 13882122019
 */
public final class ReqChatHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(ReqChatHandler.class);

    @Override
    public void run() {
        // TODO 处理ChatMessage.ReqChat消息
        ChatMessage.ReqChatMessage reqMessage = (ChatMessage.ReqChatMessage) getMessage();
        //获取自己
        Player sendmePlayer = (Player) getParameter();
        //构建消息
        ChatMessage.ResChatMessage.Builder builder4Res = ChatMessage.ResChatMessage.newBuilder();
        //服务器通知到客户端聊天窗显示的错误消息
        ChatMessage.ResChatErrorMessage.Builder builder4ResError = ChatMessage.ResChatErrorMessage.newBuilder();
        ///服务器响应到客户端 提示信息
        ChatMessage.ResTipsMessage.Builder builder4ResTips = ChatMessage.ResTipsMessage.newBuilder();

        ///禁止聊天状态 todo 禁言判断 需要修改
        if (sendmePlayer.getState() == PlayerState.GATHER) {
            builder4ResError.setErrorMsg("目前处于禁言阶段");
            getSession().write(builder4ResError.build());
        } else {
            //设置消息
            builder4Res.setChatContent(reqMessage.getChatContent());
            builder4Res.setChatType(reqMessage.getChatType());

            builder4Res.setSendFromID(sendmePlayer.getId());
            builder4Res.setSendFromName(sendmePlayer.getName());

            switch (reqMessage.getChatType()) {//聊天类型,私聊,公会，普通，组队，地图，公告，通知
                case 1://私聊
                    long sendtoid = reqMessage.getSendToID();
                    //查找需要私聊的对象
                    Player p = PlayerManager.getInstance().getOnline().get(sendtoid);
                    if (p == null) {
                        builder4ResError.setErrorMsg("未找到你要私聊的人，或者玩家不在线");
                        getSession().write(builder4Res.build());
                    } else {
                        //todo 操作转发

                    }

                    break;
                case 2://公会 
                    if (false) {
                        builder4ResError.setErrorMsg("你尚未加入任何公会");
                        getSession().write(builder4Res.build());
                    } else {
                        //todo 操作转发

                    }
                    break;
                case 3://普通
                    if (false) {
                        builder4ResError.setErrorMsg("普通");
                        getSession().write(builder4Res.build());
                    } else {
                        //todo 操作转发

                    }
                    break;
                case 4://组队
                    if (false) {
                        builder4ResError.setErrorMsg("找不到组队信息");
                        getSession().write(builder4Res.build());
                    } else {
                        //todo 操作转发

                    }
                    break;
                case 5://地图
                    MapManager.getInstance().selectLine(null);

                    break;
                case 6://公告

                    break;
                case 7://通知

                    break;
            }
        }
    }
}
