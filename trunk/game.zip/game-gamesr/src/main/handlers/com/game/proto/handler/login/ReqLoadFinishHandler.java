package com.game.proto.handler.login;

import com.game.engine.io.commmand.TcpHandler;
import com.game.engine.script.IBaseScript;
import com.game.engine.script.manager.ScriptManager;
import com.game.manager.player.PlayerManager;
import com.game.manager.player.script.IPlayerLoginEndScript;
import com.game.manager.player.script.IPlayerLoginScript;
import com.game.proto.LoginMessage;
import com.game.structs.player.Player;
import com.game.structs.player.PlayerState;
import com.game.utils.RandomUtils;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class ReqLoadFinishHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(ReqLoadFinishHandler.class);

    @Override
    public void run() {
        // TODO 处理LoginMessage.ReqLoadFinish消息
        LoginMessage.ReqLoadFinishMessage reqMessage = (LoginMessage.ReqLoadFinishMessage) getMessage();

        int width = reqMessage.getWidth();
        int height = reqMessage.getHeight();

        Long playerid = (Long) getSession().getAttribute(PlayerManager.LOGINPLAYERID);
        if (playerid == null) {
            log.error("无法找到session中的PlayerManager.LOGINPLAYERID属性");
            return;
        }

        Player player = PlayerManager.getInstance().getPlayerFromRegister(playerid);
        if (player == null) {
            log.error("从缓冲区中获得玩家失败:" + playerid);
            return;
        }

        // 执行登录前脚本
        {
            List<IBaseScript> loginScripts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(IPlayerLoginScript.class.getName());
            Iterator<IBaseScript> iterator = loginScripts.iterator();
            while (iterator.hasNext()) {
                ((IPlayerLoginScript) iterator.next()).action(player);
            }
        }

        if (PlayerState.QUIT.compare(player.getState().getValue())) {
            log.error(player.getId() + " " + player.getName() + " quit when load map!");
            return;
        }

        if (PlayerState.RUN.compare(player.getState().getValue()) || PlayerState.SWIM.compare(player.getState().getValue())) {
            // TODO 停止移动 ManagerPool.mapManager.playerStopRun(player);
        }

        // 将玩家添加到在线列表
        PlayerManager.getInstance().getOnline().put(player.getId(), player);

        player.setLoginTime(System.currentTimeMillis());// 写最后登录时间
        player.setLoginRandomTime(System.currentTimeMillis() + RandomUtils.random(90 * 60 * 1000, 120 * 60 * 1000));

        
        {
            // TODO 发送玩家数据给客户端
        }
        
        log.info("玩家" + player.getUserid() + " " + player.getName() + "角色" + player.getId() + "登陆！-->在线:" + PlayerManager.getInstance().getOnline().size());

        // 执行登录结束后脚本
        {
            List<IBaseScript> loginEndScripts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(IPlayerLoginEndScript.class.getName());
            Iterator<IBaseScript> iterator = loginEndScripts.iterator();
            while (iterator.hasNext()) {
                ((IPlayerLoginScript) iterator.next()).action(player);
            }
        }
    }
}
