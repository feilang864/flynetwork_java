package com.game.proto.handler.registerlogin;

import com.game.engine.io.commmand.TcpHandler;
import com.game.gamesr.server.GameServer;
import com.game.proto.RegisterLoginMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 游戏服务器，注册到登录服务器返回。
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class LGRegisterLoginHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(LGRegisterLoginHandler.class);

    @Override
    public void run() {
        // TODO 处理RegisterLoginMessage.LGRegisterLogin消息
        RegisterLoginMessage.LGRegisterLoginMessage reqMessage = (RegisterLoginMessage.LGRegisterLoginMessage) getMessage();

        log.error("游戏服务器" + GameServer.getInstance().getGameTcpServer().getName() + "注册到" + reqMessage.getServerName() + "返回成功！");
    }
}
