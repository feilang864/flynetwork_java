package serverscripts.main;

import com.game.engine.script.BaseScript;
import com.game.engine.script.BaseScriptEntry;
import com.game.engine.script.ScriptUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Administrator
 */
public class MainScript extends BaseScript {

    private static final Logger log = LoggerFactory.getLogger(MainScript.class);

    private static MainScript instance;
    private static long uck_loadtime;

    public static long getUck_loadtime() {
        return uck_loadtime;
    }

    public MainScript() {
        instance = this;
    }

    public static MainScript getInstance() {
        return instance;
    }

    @Override
    public boolean init(int initstate, BaseScriptEntry entry) {
        log.error("MainScript  " + initstate + "   " + entry);
        
        // wan
        ScriptUtil.require(entry, serverscripts.map.UpdatePlayerPositionScript.getInstance(), initstate);
        
        // 服务器启动后,相关定时器
        {
            // 每分钟更新服务器信息定时器
            ScriptUtil.require(entry, serverscripts.timer.UpdateServerInfoTimerEventScript.getInstance(), initstate);
            // 每分钟断开临时客户端链接定时器
            ScriptUtil.require(entry, serverscripts.timer.UpdateTmpClientSessionTimerEventScript.getInstance(), initstate);
            // 每分钟删除超时Token信息定时器
            ScriptUtil.require(entry, serverscripts.timer.UpdateTmpClientTokenSessionTimerEventScript.getInstance(), initstate);
        }
        
        // 创建角色完毕后执行:
        {
            // 初始化角色VIP信息
            ScriptUtil.require(entry, serverscripts.player.createplayerend.InitPlayerVipScript.getInstance(), initstate);
            // 初始化角色SKILL信息
            ScriptUtil.require(entry, serverscripts.player.createplayerend.InitPlayerSkillScript.getInstance(), initstate);
            // 初始化角色Task信息
            ScriptUtil.require(entry, serverscripts.player.createplayerend.InitPlayerTaskScript.getInstance(), initstate);
        }
        
        // 登录选择角色执行:
        {
            // 初始角色BUFF
            ScriptUtil.require(entry, serverscripts.player.selectplayer.InitPlayerBuffScript.getInstance(), initstate);
            // 初始角色Attribute
            ScriptUtil.require(entry, serverscripts.player.selectplayer.InitPlayerAttributeScript.getInstance(), initstate);
        }
        
        return true;
    }

    @Override
    public boolean uninit(int initstate, BaseScriptEntry entry) {
        return true;
    }
}
