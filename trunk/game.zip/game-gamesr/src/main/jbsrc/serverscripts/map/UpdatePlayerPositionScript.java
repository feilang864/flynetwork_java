package serverscripts.map;

import com.game.engine.script.BaseScript;
import com.game.engine.thread.RunningThread;
import com.game.engine.thread.script.IRunningEndScript;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 更新玩家坐标点位置
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class UpdatePlayerPositionScript extends BaseScript implements IRunningEndScript {

    private static final Logger log = LoggerFactory.getLogger(UpdatePlayerPositionScript.class);
    
    private static final UpdatePlayerPositionScript instance = new UpdatePlayerPositionScript();
    
    public static UpdatePlayerPositionScript getInstance() {
        return instance;
    }
    
    @Override
    public void action(RunningThread.RunningInfo runningInfo) {
        log.error("UpdatePlayerPosScript :: " + runningInfo);
        
    }

}
