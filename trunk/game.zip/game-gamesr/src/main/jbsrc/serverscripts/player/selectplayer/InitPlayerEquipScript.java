package serverscripts.player.selectplayer;

import com.game.engine.script.BaseScript;
import com.game.manager.player.script.ISelectPlayerScript;
import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class InitPlayerEquipScript extends BaseScript implements ISelectPlayerScript {
    
    private static final Logger log = LoggerFactory.getLogger(InitPlayerEquipScript.class);

    @Override
    public void action(Player player) {
        log.error("选择角色后:初始化角色BUFF 开始");
        
        // 检查套装强化星级buff
	// ManagerPool.equipManager.stTaoZhuang(player, 1);
        
        log.error("选择角色后:初始化角色BUFF 结束");
    }

}
