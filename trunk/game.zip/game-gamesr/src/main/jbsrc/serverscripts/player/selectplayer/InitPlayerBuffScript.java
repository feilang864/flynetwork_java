package serverscripts.player.selectplayer;

import com.game.engine.script.BaseScript;
import com.game.manager.player.script.ISelectPlayerScript;
import com.game.structs.buff.Buff;
import com.game.structs.player.Player;
import java.util.Iterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class InitPlayerBuffScript extends BaseScript implements ISelectPlayerScript {

    private static final Logger log = LoggerFactory.getLogger(InitPlayerBuffScript.class);
    private static final InitPlayerBuffScript instance = new InitPlayerBuffScript();

    public static InitPlayerBuffScript getInstance() {
        return instance;
    }

    @Override
    public void action(Player player) {
        log.error("选择角色后:初始化角色BUFF 开始");

        // buff初始化
        Iterator<Buff> iter = player.getBuffs().iterator();
        while (iter.hasNext()) {
            // 遍历buff
            Buff buff = (Buff) iter.next();
            if (buff == null) {
                iter.remove();
                continue;
            }
            // 非永久有效
            if (buff.getTotalTime() != -1 && buff.getCount() == 1) {
                // buff过期
                if (buff.getStart() + buff.getTotalTime() < System.currentTimeMillis()) {
                    buff.remove(player);
                    iter.remove();
                    continue;
                }
            }
            try {
                buff.add(player, player);
            } catch (Exception ex) {
                log.error("buff异常", ex);
            }
        }
        
        
//        try {
//	    CountryAwardManager.getInstance().setKingCityBuff(player);// 加王帮buff
//	    CountryAwardManager.getInstance().removeKingCityBuff(player);// 删除王帮buff
//	} catch (Exception ex) {
//	    log.error("buff异常", ex);
//	}
        
        log.error("选择角色后:初始化角色BUFF 结束");
    }

}
