package serverscripts.player.createplayerend;

import com.game.engine.script.BaseScript;
import com.game.manager.player.script.ICreatePlayerEndScript;
import com.game.manager.skill.SkillManager;
import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class InitPlayerSkillScript extends BaseScript implements ICreatePlayerEndScript {

    private static final Logger log = LoggerFactory.getLogger(InitPlayerSkillScript.class);
    
    private static final InitPlayerSkillScript instance = new InitPlayerSkillScript();
    
    public static InitPlayerSkillScript getInstance() {
        return instance;
    }
    
    @Override
    public void action(Player player) {
        log.info("执行角色创建完毕后脚本:初始化Skill信息");
        SkillManager.getInstance().autoStudySkill(player);
    }

}
