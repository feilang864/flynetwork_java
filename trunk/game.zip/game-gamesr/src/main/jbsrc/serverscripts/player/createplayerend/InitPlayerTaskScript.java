package serverscripts.player.createplayerend;

import com.game.engine.script.BaseScript;
import com.game.manager.player.script.ICreatePlayerEndScript;
import com.game.manager.task.TaskManager;
import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class InitPlayerTaskScript extends BaseScript implements ICreatePlayerEndScript {

    private static final Logger log = LoggerFactory.getLogger(InitPlayerTaskScript.class);
    
    private static final InitPlayerTaskScript instance = new InitPlayerTaskScript();
    
    public static InitPlayerTaskScript getInstance() {
        return instance;
    }
    
    @Override
    public void action(Player player) {
        log.info("执行角色创建完毕后脚本:初始化Task信息");

        // TODO 初始化任务
        TaskManager.getInstance().acceptMainTask(player, TaskManager.CREATEPLAYERDEFAULTTASK);// 玩家出生接取主线任务
//	String beforeReceiveAble = JSONserializable.toString(player.getTaskRewardsReceiveAble());
//	Task task = TaskManager.getInstance().getTaskByModelId(player, TaskManager.CREATEPLAYERDEFAULTTASK);
//	if (TimeUtil.getOpenAreaDay() <= Global.NEWBIE_DAYS) {
//	    ManagerPool.buffManager.addBuff(player, player, Global.NEWBIE_BUFF, 0, 0, 0, 0);
//	}
//	try {
//	    if (task != null) {
//		MainTaskLog log = new MainTaskLog(player);
//		log.setRoleId(player.getId());
//		log.setAcceptafterReceiveAble(JSONserializable.toString(player.getTaskRewardsReceiveAble()));
//		log.setAcceptbeforeReceiveAble(beforeReceiveAble);
//		log.setAcceptmodelId(TaskManager.CREATEPLAYERDEFAULTTASK);
//		log.setAccepttaskInfo(JSONserializable.toString(task));
//		log.setAcceptlevel(player.getLevel());
//		log.setAcceptonlinetime(player.getAccunonlinetime()); // TODO
//		log.setUserId(player.getAccountid());
//		LogService.getInstance().execute(log);
//	    }
//	} catch (Exception e) {
//	    log.error("", e);
//	}
    }

}
