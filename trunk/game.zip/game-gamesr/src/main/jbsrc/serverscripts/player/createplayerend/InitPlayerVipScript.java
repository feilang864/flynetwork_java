package serverscripts.player.createplayerend;

import com.game.engine.script.BaseScript;
import com.game.manager.player.script.ICreatePlayerEndScript;
import com.game.structs.player.Player;
import com.game.structs.vip.VipDetailInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class InitPlayerVipScript extends BaseScript implements ICreatePlayerEndScript {

    private static final Logger log = LoggerFactory.getLogger(InitPlayerVipScript.class);
    
    private static final InitPlayerVipScript instance = new InitPlayerVipScript();
    
    public static InitPlayerVipScript getInstance() {
        return instance;
    }
    
    @Override
    public void action(Player player) {
        log.info("执行角色创建完毕后脚本:初始化VIP信息");
        player.setVip(0);
        player.setWebvip(0);
        VipDetailInfo vipDetailInfo = new VipDetailInfo();
        player.getVariables().put(Player.VARIABLE_VIP, vipDetailInfo);
    }

}
