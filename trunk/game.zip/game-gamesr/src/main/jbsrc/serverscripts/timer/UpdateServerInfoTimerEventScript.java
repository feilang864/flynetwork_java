package serverscripts.timer;

import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.script.BaseScript;
import com.game.engine.timer.script.IServerMinuteTimerEventScript;
import com.game.gamesr.main.Main;
import com.game.proto.LoginMessage;
import java.util.Collection;
import java.util.Map;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * GS 请求 LS 更新服务器信息
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class UpdateServerInfoTimerEventScript extends BaseScript implements IServerMinuteTimerEventScript {

    private static final Logger log = LoggerFactory.getLogger(UpdateServerInfoTimerEventScript.class);
    private static final UpdateServerInfoTimerEventScript instance = new UpdateServerInfoTimerEventScript();

    public static UpdateServerInfoTimerEventScript getInstance() {
        return instance;
    }

    @Override
    public void action(int serverId, String serverWeb) {
        log.error("UpdateServerInfoTimerEventScript");
        long begin = System.currentTimeMillis();
        MinaServerConfig minaServerConfig = Main.getGameServer().getGameTcpServer().getMinaServerConfig();
        Map<Integer, IoSession> map = Main.getGameServer().getGameTcpClient().getSession(1); // 取得登录服务器链接的Session
        if (map != null && !map.isEmpty()) {
            LoginMessage.GLUpdateServerInfoMessage.Builder updateServerInfoBuilder = LoginMessage.GLUpdateServerInfoMessage.newBuilder();
            LoginMessage.ServerInfo.Builder serverInfoBuilder = LoginMessage.ServerInfo.newBuilder();
            serverInfoBuilder.setZoneid(minaServerConfig.getZoneid());
            serverInfoBuilder.setZonename(minaServerConfig.getZonename());
            serverInfoBuilder.setName(minaServerConfig.getName());
            serverInfoBuilder.setId(minaServerConfig.getId());
            serverInfoBuilder.setWeb(minaServerConfig.getWeb());
            serverInfoBuilder.setIp(minaServerConfig.getIp());
            serverInfoBuilder.setPort(minaServerConfig.getPort());
            serverInfoBuilder.setState(0); // 查询服务器人数
            serverInfoBuilder.setVersion(minaServerConfig.getVersion());
            
            updateServerInfoBuilder.setServerInfo(serverInfoBuilder.build());
            
            LoginMessage.GLUpdateServerInfoMessage updateServerInfoMessage = updateServerInfoBuilder.build();
            
            Collection<IoSession> sessions = map.values();
            for (IoSession session : sessions) {
                if (session != null && session.isConnected()) {
                    session.write(updateServerInfoMessage);
                }
            }
        }
        long cost = System.currentTimeMillis() - begin;
        if (cost > 1000L) {
            log.error("定时器执行时间过长" + cost + " ms");
        }

    }

}
