package serverscripts.timer;

import com.game.engine.io.mina.utils.SessionUtil;
import com.game.engine.script.BaseScript;
import com.game.engine.timer.script.IServerMinuteTimerEventScript;
import com.game.gamesr.main.Main;
import com.game.gamesr.server.tcp.GameTcpServer;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 删除超时的Session链接.客户端与服务器建立链接后,一直不发送登录消息.这些临时间的Session需要断开
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class UpdateTmpClientSessionTimerEventScript extends BaseScript implements IServerMinuteTimerEventScript {

    private static final Logger log = LoggerFactory.getLogger(UpdateTmpClientSessionTimerEventScript.class);
    
    private static final UpdateTmpClientSessionTimerEventScript instance = new UpdateTmpClientSessionTimerEventScript();

    public static UpdateTmpClientSessionTimerEventScript getInstance() {
        return instance;
    }
    
    @Override
    public void action(int serverId, String serverWeb) {
        log.error("UpdateTmpClientSessionTimerEventScript");
        long begin = System.currentTimeMillis();
        Set<String> removes = new HashSet<>();
        Map<String, GameTcpServer.TmpClientInfo> tmpClientSessions = Main.getGameServer().getGameTcpServer().getTmpClientSessions();
        for (GameTcpServer.TmpClientInfo tmpClientInfo : tmpClientSessions.values()) {
            if (begin - tmpClientInfo.getCtime() > 60000L) {
                removes.add(tmpClientInfo.getIp());
            }
        }
        
        for (String key : removes) {
            GameTcpServer.TmpClientInfo removed = tmpClientSessions.remove(key);
            if (removed != null && removed.getSession() != null) {
                SessionUtil.close(removed.getSession(), "临时链接超时"); 
            }
        }
        
        long cost = System.currentTimeMillis() - begin;
        if (cost > 1000L) {
            log.error("定时器执行时间过长" + cost + " ms");
        }
    }
}
