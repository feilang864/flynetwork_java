package com.game.structs.pool;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public interface MemoryObject {

    public void release();
}
