package com.game.po.player.controller;

import com.game.po.player.Gamemaster;
import com.game.po.player.controller.exceptions.NonexistentEntityException;
import com.game.po.player.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class GamemasterJpaController implements Serializable {

    public GamemasterJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Gamemaster gamemaster) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(gamemaster);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findGamemaster(gamemaster.getId()) != null) {
                throw new PreexistingEntityException("Gamemaster " + gamemaster + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Gamemaster gamemaster) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            gamemaster = em.merge(gamemaster);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                int id = gamemaster.getId();
                if (findGamemaster(id) == null) {
                    throw new NonexistentEntityException("The gamemaster with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(int id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Gamemaster gamemaster;
            try {
                gamemaster = em.getReference(Gamemaster.class, id);
                gamemaster.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The gamemaster with id " + id + " no longer exists.", enfe);
            }
            em.remove(gamemaster);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Gamemaster> findGamemasterEntities() {
        return findGamemasterEntities(true, -1, -1);
    }

    public List<Gamemaster> findGamemasterEntities(int maxResults, int firstResult) {
        return findGamemasterEntities(false, maxResults, firstResult);
    }

    private List<Gamemaster> findGamemasterEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Gamemaster.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Gamemaster findGamemaster(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Gamemaster.class, id);
        } finally {
            em.close();
        }
    }

    public int getGamemasterCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Gamemaster> rt = cq.from(Gamemaster.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    public Gamemaster selectByAccount(String username) {
        EntityManager em = getEntityManager();
        try {
            Query createNamedQuery = em.createNamedQuery("Gamemaster.findByUsername").setParameter("username", username);
            return (Gamemaster) createNamedQuery.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
    }

}
