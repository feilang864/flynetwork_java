package com.game.manager.pet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class PetOptManager {

    private static final Logger log = LoggerFactory.getLogger(PetOptManager.class);

    private static final PetOptManager instance = new PetOptManager();

    public static PetOptManager getInstance() {
        return instance;
    }
    
    private PetOptManager() {
    }
    
    /**
     * 玩家主动攻击
     */
    public static int FIGHTTYPE_PLAYER_ATTACK = 1;
    /**
     * 玩家攻击波及
     */
    public static int FIGHTTYPE_PLAYER_DAMAGE = 2;
    /**
     * 玩家被攻击
     */
    public static int FIGHTTYPE_PLAYER_DEFENCE = 3;
    /**
     * 美人被攻击
     */
    public static int FIGHTTYPE_PET_DEFENCE = 4;
    /**
     * 无战斗状态
     */
    public static int FIGHTTYPE_PET_IDEL = 0;
    /**
     * 合体增加最多的属性条数
     */
    public static int HTADDATTRIBUTECOUNT = 3;
    /**
     * 宠物最高等级7级
     */
    public static int MAXPETLEVEL = 7;
    /**
     * 宠物最高等级能升的等级
     */
    public static int MAXPETCANLEVEL = 4;
    /**
     * 宠物最高数量5个
     */
    public static int MAXPETNUM = 5;

    // private static int maxpets=24;
    // 最大可拥有的数量

}
