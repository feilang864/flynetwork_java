package com.game.structs.buff;

import com.game.engine.object.GameObject;
import com.game.structs.player.Person;
import java.util.HashMap;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public abstract class Buff extends GameObject implements IBuff {

    private static final long serialVersionUID = -7779860908414599813L;
    
    //buff是否有效
    private boolean effective = true;
    //buff类型
    private int actionType;
    //buff模型id
    private int modelId;
    //buff等级
    private int level;
    //替换等级
    private int replaceLevel;
    //叠加层数
    private int overlay;
    //开始时间
    private long start;
    //持续时间 -1永远存在
    private long totalTime;
    //间隔时间
    private int timer;
    //总剩余持续时间 -1永远存在
    private long totalRemainTime;
    //剩余时间
    private int remain;
    //来源
    private long source;
    //来源类型 0-玩家 1-宠物 2-怪物
    private int sourceType;
    //值加成
    private int value;
    //比例加成
    private int percent;
    //参数
    private int parameter;
    //下线是否计时 0-不计时 1-计时
    private int count;
    //技能触发（只对某个技能有效）
    private int skilltrigger;
    //参数数组
    private HashMap<String, String> backups = new HashMap<>();
    
    public boolean isEffective() {
        return effective;
    }

    public void setEffective(boolean effective) {
        this.effective = effective;
    }

    public int getModelId() {
        return modelId;
    }

    public void setModelId(int modelId) {
        this.modelId = modelId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public long getStart() {
        return start;
    }

    public void setStart(long start) {
        this.start = start;
    }

    public long getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(long totalTime) {
        this.totalTime = totalTime;
    }

    public long getTotalRemainTime() {
        return totalRemainTime;
    }

    public void setTotalRemainTime(long totalRemainTime) {
        this.totalRemainTime = totalRemainTime;
    }

    public int getTimer() {
        return timer;
    }

    public void setTimer(int timer) {
        this.timer = timer;
    }

    public long getSource() {
        return source;
    }

    public void setSource(long source) {
        this.source = source;
    }

    public int getSourceType() {
        return sourceType;
    }

    public void setSourceType(int sourceType) {
        this.sourceType = sourceType;
    }

    public int getParameter() {
        return parameter;
    }

    public void setParameter(int parameter) {
        this.parameter = parameter;
    }

    public int getActionType() {
        return actionType;
    }

    public void setActionType(int actionType) {
        this.actionType = actionType;
    }

    public int getRemain() {
        return remain;
    }

    public void setRemain(int remain) {
        this.remain = remain;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getPercent() {
        return percent;
    }

    public void setPercent(int percent) {
        this.percent = percent;
    }

    public int getReplaceLevel() {
        return replaceLevel;
    }

    public void setReplaceLevel(int replaceLevel) {
        this.replaceLevel = replaceLevel;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getOverlay() {
        return overlay;
    }

    public void setOverlay(int overlay) {
        this.overlay = overlay;
    }

    public long countTotalRemainTime(Person source) {
        return getTotalRemainTime();
    }

    public HashMap<String, String> getBackups() {
        return backups;
    }

    public void setBackups(HashMap<String, String> backups) {
        this.backups = backups;
    }

    public int getSkilltrigger() {
        return skilltrigger;
    }

    public void setSkilltrigger(int skilltrigger) {
        this.skilltrigger = skilltrigger;
    }

}
