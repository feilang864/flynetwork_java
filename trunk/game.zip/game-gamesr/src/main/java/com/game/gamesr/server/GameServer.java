package com.game.gamesr.server;

import com.game.engine.io.conf.MinaClientConfig;
import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.thread.ServerThread;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.engine.timer.ServerHeartTimer;
import com.game.engine.utils.Config;
import com.game.gamesr.client.tcp.GameTcpClient;
import com.game.gamesr.main.Main;
import com.game.gamesr.server.tcp.GameTcpServer;
import com.game.manager.player.PlayerManager;
import com.game.service.log.LogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class GameServer implements Runnable {
    
    private static final Logger log = LoggerFactory.getLogger(GameServer.class);

    // 接受客户端的链接
    private final GameTcpServer gameTcpServer;
    
    // 链接LoginServer,PublicServer等
    private final GameTcpClient gameTcpClient;
    
    private final ThreadGroup threadGroup = new ThreadGroup("GameServerMainThread");
    private final ServerThread mainServerThread = new ServerThread(threadGroup, "GameServerMainThread", 1000L); // 1秒的心跳
    
    public GameServer(ThreadPoolExecutorConfig defaultThreadExcutorConfig4TcpServer, ThreadPoolExecutorConfig mapServerThreadExcutorConfig4TcpServer, MinaServerConfig minaServerConfig4TcpServer
        , ThreadPoolExecutorConfig defaultThreadExcutorConfig4TcpClient, MinaClientConfig minaClientConfig4TcpClient) {
        Config.serverID = minaServerConfig4TcpServer.getId(); // 设置ID
        
        this.gameTcpServer = new GameTcpServer(defaultThreadExcutorConfig4TcpServer, mapServerThreadExcutorConfig4TcpServer, minaServerConfig4TcpServer);
        this.gameTcpClient = new GameTcpClient(defaultThreadExcutorConfig4TcpClient, minaClientConfig4TcpClient);
    }
    
    public static GameServer getInstance() {
        return Main.getGameServer();
    }

    @Override
    public void run() {
        log.info("GameServer::gameTcpServer::start!!!");
        new Thread(gameTcpServer).start();
        log.info("GameServer::gameTcpClient::start!!!");
        new Thread(gameTcpClient).start();
        log.info("GameServer::mainServerThread::start!!!");
        mainServerThread.start();
        log.info("GameServer::mainServerThread::ServerHeartTimer::start!!!");
        mainServerThread.addTimerEvent(new ServerHeartTimer(gameTcpServer.getId(), gameTcpServer.getWeb()));
        
        log.info("加载当前区角色的所有名称");
        PlayerManager.getInstance().loadNames();
        
        log.info("启动日志CRUD服务");
        LogService.getInstance().start();
    }

    public GameTcpServer getGameTcpServer() {
        return gameTcpServer;
    }

    public GameTcpClient getGameTcpClient() {
        return gameTcpClient;
    }

}
