package com.game.manager.player;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class UserManager {

    private static final Logger log = LoggerFactory.getLogger(UserManager.class);
    
    private static final UserManager instance = new UserManager();
    
    public static UserManager getInstance() {
        return instance;
    }
    
    private UserManager() {
    }

    public static final String USER_ID = "userId";
    public static final String USER_NAME = "userName";

    private final Map<String, UserState> user_states = new ConcurrentHashMap<>();

    public void addUserState(String username, UserState state) {
        user_states.put(username, state);
    }
    
    public UserState removeUserState(String username) {
        return user_states.remove(username);
    }
    
    public UserState getUserState(String username) {
        return user_states.get(username);
    }

    public static enum UserState {

        /**
         * 1	登陆中
         */
        LOGINING(1),
        /**
         * 2	创建中
         */
        CREATING(2),
        /**
         * 3	选择角色中
         */
        SELECTING(3),
        /**
         * 4	等待退出中
         */
        WAITQUITING(4),
        /**
         * 5	退出中
         */
        QUITING(5),
        /**
         * 6	删除角色中
         */
        DELETEING(6),;

        private final int value;

        UserState(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }

        public boolean compare(int value) {
            return this.value == value;
        }
    }
}
