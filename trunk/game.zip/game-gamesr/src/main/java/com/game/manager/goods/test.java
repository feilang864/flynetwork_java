/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.manager.goods;

/**
 *
 * @author Administrator
 */
public class test {
    
    public static void main(String[] args) {
        System.out.println(System.currentTimeMillis());
        Goods go = new Goods("12313", "12312321");
        go.toString();
        Goods go1 = GoodsManager.getInstance().myClone(go);
        go1.toString();
        
    }
}
