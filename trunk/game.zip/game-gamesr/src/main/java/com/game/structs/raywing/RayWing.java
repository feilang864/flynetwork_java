package com.game.structs.raywing;

import com.game.engine.object.GameObject;

/**
 * 翅膀
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class RayWing extends GameObject {

}
