/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.structs.task;

import com.game.scripts.task.IAccptTask;
import com.game.scripts.task.IActionTask;
import com.game.scripts.task.ICheckTask;
import com.game.scripts.task.IFinshTask;

/**
 * 主线任务 不允许放弃
 *
 * @author Troy.Chen
 */
public class TaskMain implements IAccptTask, IActionTask, ICheckTask, IFinshTask {

    @Override
    public boolean accptTask(TaskParameters taskParameters) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actionTask(TaskParameters taskParameters) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean checkTask(TaskParameters taskParameters) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean finshTask(TaskParameters taskParameters) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
