/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.structs.task;

import com.game.structs.player.Player;

/**
 * 任务参数类型
 *
 * @author Troy.Chen
 */
public class TaskParameters {

    public TaskParameters(Player player, int taskID) {
        this.player = player;
        this.taskID = taskID;
    }

    private Player player;
    private int taskID;
    private String ErrorString;

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public int getTaskID() {
        return taskID;
    }

    public void setTaskID(int taskID) {
        this.taskID = taskID;
    }

    public String getErrorString() {
        return ErrorString;
    }

    public void setErrorString(String ErrorString) {
        this.ErrorString = ErrorString;
    }

}
