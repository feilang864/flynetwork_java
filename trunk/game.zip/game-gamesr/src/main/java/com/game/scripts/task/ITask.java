package com.game.scripts.task;

import com.game.structs.task.TaskParameters;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * 任务接口
 *
 * @author Troy.Chen
 */
public interface ITask {

    /**
     * 接受任务
     *
     * @param taskParameters
     * @return 返回成功，失败 失败查询 TaskParameters.ErrorString
     */
    boolean accptTask(TaskParameters taskParameters);

    /**
     * 完成任务
     *
     * @param taskParameters
     * @return 返回成功，失败 失败查询 TaskParameters.ErrorString
     */
    boolean finshTask(TaskParameters taskParameters);

    /**
     * 处理任务
     *
     * @param taskParameters
     * @return 返回成功，失败 失败查询 TaskParameters.ErrorString
     */
    boolean actionTask(TaskParameters taskParameters);

    /**
     * 检查任务
     *
     * @param taskParameters
     * @return 返回成功，失败 失败查询 TaskParameters.ErrorString
     */
    boolean checkTask(TaskParameters taskParameters);

    /**
     * 放弃任务
     *
     * @param taskParameters
     * @return 返回成功，失败 失败查询 TaskParameters.ErrorString
     */
    boolean giveupTask(TaskParameters taskParameters);

}
