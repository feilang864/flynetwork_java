package com.game.gamesr.client.tcp;

import com.game.engine.io.conf.MinaClientConfig;
import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.io.message.MessagePool;
import com.game.engine.io.mina.Service;
import com.game.engine.io.mina.handler.ClientProtocolHandler;
import com.game.engine.io.mina.impl.MinaClient;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.proto.LoginMessage;
import com.game.proto.RegisterLoginMessage;
import com.game.proto.handler.login.LGTokenCheckHandler;
import com.game.proto.handler.registerlogin.LGRegisterLoginHandler;
import com.google.protobuf.Message;
import java.util.HashMap;
import java.util.Map;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class GameTcpClient extends Service<MessagePool, MinaServerConfig> {

    private static final Logger log = LoggerFactory.getLogger(GameTcpClient.class);

    private final MinaClientConfig minaClientConfig;

    private final MinaClient minaClient;
    
    private final Map<Integer, Map<Integer, IoSession>> sessions = new HashMap<>();
    
    public Map<Integer, IoSession> getSession(int type) {
        return sessions.get(type);
    }
    
    public IoSession getSession(int type, int id) {
        Map<Integer, IoSession> typeSessions = sessions.get(type);
        if(!typeSessions.isEmpty()) {
            return typeSessions.get(id);
        }
        return null;
    }

    public GameTcpClient(ThreadPoolExecutorConfig defaultThreadExcutorConfig, MinaClientConfig minaClientConfig) {
        super(new MessagePool(), defaultThreadExcutorConfig, null);

        this.minaClientConfig = minaClientConfig;

        this.minaClient = new MinaClient(minaClientConfig, new GameTcpClientHandler(messagePool), new GameTcpClientCallback());
    }

    @Override
    protected void initProtos() {
        messagePool.register(
                110201, // id 协议ID
                RegisterLoginMessage.LGRegisterLoginMessage.class,                  // messageClass 协议请求消息类型
                LGRegisterLoginHandler.class,    // handlerClass 协议请求处理类型
                0,                                                                  // threadModel 协议请求线程模型
                RegisterLoginMessage.LGRegisterLoginMessage.newBuilder(),           // builder 协议请求消息构造器
                0                                                                   // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                    //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        
        messagePool.register(
                200105,                                                         // id 协议ID
                LoginMessage.LGTokenCheckMessage.class,                         // messageClass 协议请求消息类型
                LGTokenCheckHandler.class,           // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.LGTokenCheckMessage.newBuilder(),                  // builder 协议请求消息构造器
                0                                                               // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
    }

    @Override
    protected void initMapServers() {
        log.warn("客户端一般不用考初始化地图服务器");
    }

    @Override
    protected void running() {
        log.debug(" run ... ");
        minaClient.run();
    }

    @Override
    protected void onShutdown() {
        log.debug(" stop ... ");
        minaClient.stop();
    }

    @Override
    public String toString() {
        return minaClientConfig.getName();
    }

    public class GameTcpClientHandler extends ClientProtocolHandler {

        private final MessagePool messagePool;

        public GameTcpClientHandler(MessagePool messagePool) {
            this.messagePool = messagePool;
        }

        @Override
        protected MessagePool getMessagePool() {
            return messagePool;
        }

        @Override
        protected void doTranspond(IoSession ioSession, Message message) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        
        // 覆盖,以实现断线重连
        @Override
        public void sessionClosed(IoSession ioSession) {
            
            Integer type = (Integer) ioSession.getAttribute("connect-server-type");
            Integer id = (Integer) ioSession.getAttribute("connect-server-id");
            String ip = (String) ioSession.getAttribute("connect-server-ip");
            Integer port = (Integer) ioSession.getAttribute("connect-server-port");
            
            log.error(String.format("%s type:%d id:%d ip:%s port:%d closed!", ioSession, type, id, ip, port));
            if (type != null && id != null && ip != null && port != null) {
                boolean needReconnect = false;
                switch(type) {
                    case 1:
                        needReconnect = true;
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    default:
                        break;
                }
                if (needReconnect) {
                    while(!minaClient.reconnect(type, id, ip, port)) {
                        log.error(String.format("尝试重连: type:%d id:%d ip:%s port:%d!", type, id, ip, port));
                        try {
                            Thread.sleep(5000L);
                        } catch (InterruptedException ex) {
                        }
                    }
                }
            }
        }

    }

    public class GameTcpClientCallback implements MinaClient.ClientCallbackHanlder {

        @Override
        public void connectComplete() {
            System.out.println("链接完毕");
        }

        @Override
        public void register(int type, int id, String ip, int port, IoSession session) {
            System.out.println("注册完毕,注册");
            
            Map<Integer, IoSession> typeSessions = sessions.get(type);
            if (typeSessions == null) {
                typeSessions = new HashMap<>();
                sessions.put(type, typeSessions);
            }
            typeSessions.put(id, session);
            

            RegisterLoginMessage.GLRegisterLoginMessage.Builder newBuilder = RegisterLoginMessage.GLRegisterLoginMessage.newBuilder();
            newBuilder.setServerId(minaClientConfig.getId());
            newBuilder.setServerName(minaClientConfig.getName());
            RegisterLoginMessage.GLRegisterLoginMessage msg = newBuilder.build();

            session.write(msg);
        }
    }
}
