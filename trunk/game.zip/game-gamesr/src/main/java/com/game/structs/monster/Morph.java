package com.game.structs.monster;

/**
 * 变身信息
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Morph {

    //变身类型
    private int type;
    //变身值
    private int value;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
