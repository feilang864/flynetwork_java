package com.game.structs.player;

import com.game.engine.object.GameObject;
import com.game.structs.map.IMapObject;
import com.game.structs.Position;
import com.game.structs.buff.Buff;
import com.game.structs.cooldown.Cooldown;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public abstract class Person extends GameObject implements IMapObject {

    private static final long serialVersionUID = -7778568015291171928L;
    
    // 类型
    public final static byte PERSON_PLAYER = 1;  // 玩家
    public final static byte PERSON_MONSTER = 2; // 怪物
    public final static byte PERSON_NPC = 2;     // NPC
    public final static byte PERSON_PET = 2;     // 宠物
    
    //创建时间
    protected long createTime = System.currentTimeMillis();
    
    //对象类型
    protected transient byte personType;
    
    //名字
    protected String name;

    //资源
    protected String res;

    //头像
    protected String icon;

    //模板Id
    protected int modelId;
    
    //等级
    protected int level;
    
    //当前生命
    protected int hp;

    //当前魔法
    protected int mp;


    
    
    
    //地图
    protected int mapId;

    //地图模板id
    protected int mapModelId;

    //坐标
    protected Position position;

    //方向
    protected byte direction;


    
    
    
    //BUFF列表
    protected List<Buff> buffs = new ArrayList<>();
    
    //冷却列表
    protected HashMap<String, Cooldown> cooldowns = new HashMap<>();
    
    
    
    

    //移动路径
    protected transient List<Position> roads = new ArrayList<>();
    //移动耗时时间
    protected transient int cost = 0;
    //移动上一步时间
    protected transient long prevStep = 0;
    //移动上次坐标
    protected transient Position lastPosition = new Position();
    //移动上次时间
    protected transient long lastMoveTime;
    
    
    

    //所在线服务器
    protected transient int line;
    //是否死亡
    protected transient boolean die;
    //战斗状态
    protected transient int fightState;
            
            
            
            
            
            
            
            
            
    // getter & setter
    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRes() {
        return res;
    }

    public void setRes(String res) {
        this.res = res;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getMp() {
        return mp;
    }

    public void setMp(int mp) {
        this.mp = mp;
    }

    public int getModelId() {
        return modelId;
    }

    public void setModelId(int modelId) {
        this.modelId = modelId;
    }

    public int getMapModelId() {
        return mapModelId;
    }

    public void setMapModelId(int mapModelId) {
        this.mapModelId = mapModelId;
    }

    public byte getDirection() {
        return direction;
    }

    public void setDirection(byte direction) {
        this.direction = direction;
    }

    public List<Buff> getBuffs() {
        return buffs;
    }

    public void setBuffs(List<Buff> buffs) {
        this.buffs = buffs;
    }

    public HashMap<String, Cooldown> getCooldowns() {
        return cooldowns;
    }

    public void setCooldowns(HashMap<String, Cooldown> cooldowns) {
        this.cooldowns = cooldowns;
    }

    public List<Position> getRoads() {
        return roads;
    }

    public void setRoads(List<Position> roads) {
        this.roads = roads;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public long getPrevStep() {
        return prevStep;
    }

    public void setPrevStep(long prevStep) {
        this.prevStep = prevStep;
    }

    public Position getLastPosition() {
        return lastPosition;
    }

    public void setLastPosition(Position lastPosition) {
        this.lastPosition = lastPosition;
    }

    public long getLastMoveTime() {
        return lastMoveTime;
    }

    public void setLastMoveTime(long lastMoveTime) {
        this.lastMoveTime = lastMoveTime;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public boolean isDie() {
        return die;
    }

    public void setDie(boolean die) {
        this.die = die;
    }

    public int getFightState() {
        return fightState;
    }

    public void setFightState(int fightState) {
        this.fightState = fightState;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public void setPersonType(byte personType) {
        this.personType = personType;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }
    
    // ====================================
    @Override
    public Position getPosition() {
        return position;
    }
    
    @Override
    public int getLine() {
        return line;
    }
    
    @Override
    public int getMapId() {
        return mapId;
    }

    @Override
    public boolean canSee(Player player) {
        return true;
    }
    
    //====================================

    
    
}
