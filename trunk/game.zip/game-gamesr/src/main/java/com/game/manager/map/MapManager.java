package com.game.manager.map;

import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class MapManager {

    private static final Logger log = LoggerFactory.getLogger(MapManager.class);
    
    private static final MapManager instance = new MapManager();
    
    public static MapManager getInstance() {
        return instance;
    }
    
    private MapManager() {
    }

    /**
     * 根据玩家地图自动选择线路
     * @param player 
     */
    public void selectLine(Player player) {
        // TODO 
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
