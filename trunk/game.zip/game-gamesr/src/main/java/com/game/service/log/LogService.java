package com.game.service.log;

import com.game.engine.thread.db.CRUDCommand;
import com.game.engine.thread.db.CRUDThread;
import com.game.manager.data.DataManager;
import com.game.po.log.BaseLog;
import javax.persistence.EntityManager;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class LogService extends CRUDThread<BaseLog> {

    public static final String CRUD = "LOG_CRUD";
    
    private static final LogService instance = new LogService();

    public static LogService getInstance() {
        return instance;
    }

    private LogService() {
        super("日志写入服务");
        CRUDCommand.registerCreateCallBack(LogService.CRUD, LogCRUDCallBack.getInstance());
    }

    public void updateRoleDate(long id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}

class LogCRUDCallBack implements CRUDCommand.ICreateCallback<BaseLog> {

    private static final LogCRUDCallBack instance = new LogCRUDCallBack();

    private static EntityManager logEntityManager;
    
    public static LogCRUDCallBack getInstance() {
        return instance;
    }
    
    @Override
    public void create(BaseLog log) {
        System.out.println("create Log Success" + log);
        if (logEntityManager == null) {
            logEntityManager = DataManager.getInstance().getLogEntityManager();
        }
        logEntityManager.getTransaction().begin();
        logEntityManager.persist(log);
        logEntityManager.getTransaction().commit();
    }

}
