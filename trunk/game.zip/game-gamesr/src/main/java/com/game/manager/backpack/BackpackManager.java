package com.game.manager.backpack;

import com.game.manager.data.DataManager;
import com.game.po.player.Gold;
import com.game.po.player.GoldPK;
import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class BackpackManager {

    private static final Logger log = LoggerFactory.getLogger(BackpackManager.class);
    private static final BackpackManager instance = new BackpackManager();

    public static BackpackManager getInstance() {
        return instance;
    }

    /**
     * 加载角色的元宝数据
     * @param player 
     */
    public void loadGold(Player player) {
        Gold gold = DataManager.getInstance().getGoldDao().findGold(new GoldPK(player.getUsername(), player.getServerid()));
        player.setGold(gold);
    }
    
    private BackpackManager() {
    }
}
