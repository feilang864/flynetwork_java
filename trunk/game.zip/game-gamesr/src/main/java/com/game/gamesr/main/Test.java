package com.game.gamesr.main;

import com.game.engine.thread.RunningThread;
import java.util.Random;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class Test {

    public static void main(String[] args) {
        // 服务器启动线程组
        String servername = "测试RunningThread";
        ThreadGroup thread_group = new ThreadGroup(servername);
        RunningThread wRunningThread = new RunningThread(thread_group, servername, 500L);
        wRunningThread.start();

        Random random = new Random();
        int i = 10000;
        for (int j = 0; j < 500; j++) {

            long playerid = i++;
            float x1 = random.nextFloat() * 200.0f;
            float y1 = random.nextFloat() * 200.0f;

            float x2 = random.nextFloat() * 200.0f;
            float y2 = random.nextFloat() * 200.0f;

            float x = x2 - x1;
            float y = y2 - y1;

            float speed = 6;

            double sqrt = Math.sqrt(x * x + y * y);

            float dir_x = (float) (x / sqrt);
            float dir_y = 0;
            float dir_z = (float) (y / sqrt);

//            System.out.println();
//            System.out.println(dir_x * dir_x + dir_y * dir_y);
//            System.out.println("(" + x1 + "  " + y1 + ")  (" + x2 + "  " + y2 + ")     (" + dir_x + "  " + dir_z + ")");
            wRunningThread.addRuninfo(playerid, x1, y1, x2, y2, speed, dir_x, dir_y, dir_z);
        }

        for (;;) {
            try {
                Thread.sleep(random.nextInt(1000));
            } catch (InterruptedException e) {
            }

            long playerid = i++;
            float x1 = random.nextFloat() * 200.0f;
            float y1 = random.nextFloat() * 200.0f;

            float x2 = random.nextFloat() * 200.0f;
            float y2 = random.nextFloat() * 200.0f;

            float x = x2 - x1;
            float y = y2 - y1;

            float speed = 6;

            double sqrt = Math.sqrt(x * x + y * y);

            float dir_x = (float) (x / sqrt);
            float dir_y = 0;
            float dir_z = (float) (y / sqrt);

            wRunningThread.addRuninfo(playerid, x1, y1, x2, y2, speed, dir_x, dir_y, dir_z);
        }
    }
}
