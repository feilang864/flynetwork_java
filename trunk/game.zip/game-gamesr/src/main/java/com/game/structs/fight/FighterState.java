package com.game.structs.fight;

/**
 * 战斗状态枚举
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public enum FighterState {

    /**
     * 定身
     */
    DINGSHEN(0x00000001),
    /**
     * 禁止生命恢复
     */
    JINZHISHENGMINGHUOFU(0x00000002),
    /**
     * 禁止内力恢复
     */
    JINZHINEILIHUIFU(0x00000004),
    /**
     * 禁止体力恢复
     */
    JINZHITILIHUIFU(0x00000008),
    /**
     * 睡眠
     */
    SHUIMIAN(0x00000010),
    /**
     * 传送戒指
     */
    TRANSMISSIONRING(0x00000020),
    /**
     * 无敌
     */
    WUDI(0x00000040),
    /**
     * 隐身戒指
     */
    STEALTHRING(0x00000080),
    /**
     * 怪物通用特殊表现
     */
    COMMONMONSTERSHOW(0x00000100),
    /**
     * 施毒术 减少血量
     */
    POISONINGHP(0x00000200),
    /**
     * 免费复活
     */
    MIANFEIFUHUO(0x00000400),
    /**
     * 负面状态自动解除
     */
    FUMIANZIDONGJIECHU(0x00000800),
    /**
     * 禁止使用药品
     */
    JINZHISHIYONGYAOPIN(0x00001000),
    /**
     * PK保护
     */
    PKBAOHU(0x00002000),
    /**
     * 火焰戒指（焰天火雨）
     */
    FLAMERING(0x00004000),
    /**
     * 复活戒指
     */
    EASTERRING(0x00008000),
    /**
     * 伤害魔法抵消
     */
    DAMAGEMAGICOFFSET(0x00010000),
    /**
     * 抵消伤害
     */
    OFFSETDAMAGE(0x00020000),
    /**
     * 增加伤害
     */
    INCREASEDDAMAGE(0x00040000),
    /**
     * 触发麻痹
     */
    TRIGGERPARALYSIS(0x00080000),
    /**
     * PK保护
     */
    PKBAOHUFORNIGHT(0x00100000),
    /**
     * 麻痹免疫
     */
    PARALYSISIMMUNE(0x00200000),
    /**
     * 魔法盾
     */
    MOFADUN(0x00400000),
    /**
     * 隐身术 ，集体隐身术 隐身效果
     */
    YINSHEN(0x00800000),
    /**
     * 阴阳法环
     */
    YINYANGFAHUAN(0x01000000),
    /**
     * 妙影无踪 绝对隐身效果
     */
    FULLYINSHEN(0x02000000),
    /**
     * 野蛮撞
     */
    YEMANZHUANG(0x04000000),
    /**
     * 野蛮被撞
     */
    YEMANBEIZHUANG(0x08000000),
    /**
     * 抗拒被推
     */
    KANGJUBEITUI(0x10000000),
    /**
     * 诱惑之光
     */
    TEMPTATIONLIGHT(0x20000000),
    /**
     * 发狂状态
     */
    CRAZESTATE(0x40000000),
    /**
     * 狂暴
     */
    KUANGBAO(0x80000000),;

    private int value;

    FighterState(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public boolean compare(int state) {
        return ((this.value & state) != 0);
    }
}
