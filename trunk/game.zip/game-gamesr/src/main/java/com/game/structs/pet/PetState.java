package com.game.structs.pet;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public enum PetState {

    /**
     * 休息
     */
    IDEL(0),
    /**
     * 战斗
     */
    FIGHT(1),
    /**
     * 跟随
     */
    FLLOW(2),
    /**
     * 死亡
     */
    DIE(3),
    /**
     * 不显示
     */
    UNSHOW(4),
    /**
     * 追击
     */
    PURSUIT(5),
    /**
     * 停止
     */
    STOP(6),;

    private final int state;

    PetState(int value) {
        this.state = value;
    }

    public int getState() {
        return state;
    }
}
