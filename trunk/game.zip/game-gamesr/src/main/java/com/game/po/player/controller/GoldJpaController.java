package com.game.po.player.controller;

import com.game.po.player.Gold;
import com.game.po.player.GoldPK;
import com.game.po.player.controller.exceptions.NonexistentEntityException;
import com.game.po.player.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class GoldJpaController implements Serializable {

    public GoldJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Gold gold) throws PreexistingEntityException, Exception {
        if (gold.getGoldPK() == null) {
            gold.setGoldPK(new GoldPK());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(gold);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findGold(gold.getGoldPK()) != null) {
                throw new PreexistingEntityException("Gold " + gold + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Gold gold) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            gold = em.merge(gold);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                GoldPK id = gold.getGoldPK();
                if (findGold(id) == null) {
                    throw new NonexistentEntityException("The gold with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(GoldPK id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Gold gold;
            try {
                gold = em.getReference(Gold.class, id);
                gold.getGoldPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The gold with id " + id + " no longer exists.", enfe);
            }
            em.remove(gold);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Gold> findGoldEntities() {
        return findGoldEntities(true, -1, -1);
    }

    public List<Gold> findGoldEntities(int maxResults, int firstResult) {
        return findGoldEntities(false, maxResults, firstResult);
    }

    private List<Gold> findGoldEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Gold.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Gold findGold(GoldPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Gold.class, id);
        } finally {
            em.close();
        }
    }

    public int getGoldCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Gold> rt = cq.from(Gold.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
