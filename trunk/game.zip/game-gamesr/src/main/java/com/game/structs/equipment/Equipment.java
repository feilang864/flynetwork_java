package com.game.structs.equipment;

import com.game.engine.object.GameObject;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Equipment extends GameObject {
    
    private static final long serialVersionUID = 1L;

    private int level; // 装备栏位对应装备的等级  时装则表示是否到期（-1是已经到期，不再显示)
    private int star;  //对应星级
    private int hole1; //装备的孔
    private int hole2; //装备的孔
    private int hole3; //装备的孔
    private int hole4; //装备的孔
    private int hole5; //装备的孔

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getStar() {
        return star;
    }

    public void setStar(int star) {
        this.star = star;
    }

    public int getHole1() {
        return hole1;
    }

    public void setHole1(int hole1) {
        this.hole1 = hole1;
    }

    public int getHole2() {
        return hole2;
    }

    public void setHole2(int hole2) {
        this.hole2 = hole2;
    }

    public int getHole3() {
        return hole3;
    }

    public void setHole3(int hole3) {
        this.hole3 = hole3;
    }

    public int getHole4() {
        return hole4;
    }

    public void setHole4(int hole4) {
        this.hole4 = hole4;
    }

    public int getHole5() {
        return hole5;
    }

    public void setHole5(int hole5) {
        this.hole5 = hole5;
    }

    
    
}
