package com.game.manager.player.script;

import com.game.engine.script.IBaseScript;
import com.game.structs.player.Player;

/**
 * 创建角色完毕后执行脚本
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public interface ICreatePlayerEndScript extends IBaseScript {

    void action(Player player);
}
