package com.game.structs.fashion;

import com.game.engine.object.GameObject;

/**
 * 时装
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Fashion extends GameObject {
    
    private static final long serialVersionUID = 1L;

}
