package com.game.po.player;

import com.game.engine.utils.Config;
import com.game.structs.player.Player;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "Role.findByUserId", query = "SELECT o FROM Role o WHERE o.userid = :userid"),
    @NamedQuery(name = "Role.findByUsername", query = "SELECT o FROM Role o WHERE o.username = :username"),
    @NamedQuery(name = "Role.findByUserIdAndUsername", query = "SELECT o FROM Role o WHERE o.userid = :userid and o.username = :username"),
})
public class Role implements Serializable {

    @Id
    private long id = Config.getId();

    //帐号ID
    @Column(nullable = false)
    private long userid;

    //帐号名称
    @Column(nullable = false, length = 64)
    private String username;

    //创建的服务器ID
    @Column(nullable = false)
    private int serverid;
    
    // 服务器名称
    @Column(nullable = false, length = 64)
    private String servername;
    
    // 渠道名称
    @Column(nullable = false, length = 64)
    private String serverweb;
    
    // 登录的服务器IP
    @Column(nullable = false, length = 64)
    private String loginIP;
    
    // 平台参数1
    @Column(length = 255)
    private String agentPlusdata;
    
    // 平台参数2
    @Column(length = 255)
    private String agentColdatas;

    // 玩家id
    @Column(nullable = false)
    private long pid;
    
    //名字
    @Column(nullable = false, length = 64)
    private String name;
    
    //原来名字
    @Column(length = 64)
    private String name2;
    
    //性别
    @Column
    private int sex;
    
    //职业
    @Column
    private int job;
    
    //等级
    @Column
    private int level;
    
    //登录时间
    @Column
    private long logintime;
    
    //版本号
    @Column(length = 64)
    private String version;
    
    //删除状态
    @Column
    private boolean deleted;
    
    //封停状态
    @Column
    private boolean forbided;
    
    //屏幕宽度
    @Column
    private int width;
    
    //屏幕高度
    @Column
    private int height;
    
    // 游戏币
    @Column
    private int money;
    
    //元宝
    @Column
    private int gold;
    
    //禁言结束时间
    @Column
    private long prohibitChatEndTime;
    
    //战斗力
    @Column
    private int fightPower;
    
    //坐骑等级
    @Column
    private int horseLevel;
    
    //翅膀等级
    @Column
    private int raywingLevel;
    
    //在线时间
    @Column
    private long onlineTime;
    
    //地图
    @Column
    private int mapid;
    
    //地图模板id
    private int mapModelId;
    
    //国家/阵营
    @Column
    private int country;

    // 角色信息
    @Lob
    @Basic(fetch = FetchType.LAZY) // 懒加载
    @Column
    private Player player;

    public int getServerid() {
        return serverid;
    }

    public void setServerid(int serverid) {
        this.serverid = serverid;
    }

    public String getServername() {
        return servername;
    }

    public void setServername(String servername) {
        this.servername = servername;
    }

    public String getServerweb() {
        return serverweb;
    }

    public void setServerweb(String serverweb) {
        this.serverweb = serverweb;
    }

    public String getAgentPlusdata() {
        return agentPlusdata;
    }

    public void setAgentPlusdata(String agentPlusdata) {
        this.agentPlusdata = agentPlusdata;
    }

    public String getAgentColdatas() {
        return agentColdatas;
    }

    public void setAgentColdatas(String agentColdatas) {
        this.agentColdatas = agentColdatas;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public long getUserid() {
        return userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public long getPid() {
        return pid;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getJob() {
        return job;
    }

    public void setJob(int job) {
        this.job = job;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public long getLogintime() {
        return logintime;
    }

    public void setLogintime(long logintime) {
        this.logintime = logintime;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean isForbided() {
        return forbided;
    }

    public void setForbided(boolean forbided) {
        this.forbided = forbided;
    }
    
    public String getLoginIP() {
        return loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public long getProhibitChatEndTime() {
        return prohibitChatEndTime;
    }

    public void setProhibitChatEndTime(long prohibitChatEndTime) {
        this.prohibitChatEndTime = prohibitChatEndTime;
    }

    public int getFightPower() {
        return fightPower;
    }

    public void setFightPower(int fightPower) {
        this.fightPower = fightPower;
    }

    public int getHorseLevel() {
        return horseLevel;
    }

    public void setHorseLevel(int horseLevel) {
        this.horseLevel = horseLevel;
    }

    public int getRaywingLevel() {
        return raywingLevel;
    }

    public void setRaywingLevel(int raywingLevel) {
        this.raywingLevel = raywingLevel;
    }

    public long getOnlineTime() {
        return onlineTime;
    }

    public void setOnlineTime(long onlineTime) {
        this.onlineTime = onlineTime;
    }

    public int getMapid() {
        return mapid;
    }

    public void setMapid(int mapid) {
        this.mapid = mapid;
    }

    public int getCountry() {
        return country;
    }

    public void setCountry(int country) {
        this.country = country;
    }

    public int getMapModelId() {
        return mapModelId;
    }

    public void setMapModelId(int mapModelId) {
        this.mapModelId = mapModelId;
    }
    
}
