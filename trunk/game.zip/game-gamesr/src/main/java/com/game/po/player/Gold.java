package com.game.po.player;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
@Entity
public class Gold implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
    protected GoldPK goldPK;
    
    @Column
    private int totalGold;
    
    @Column
    private int costGold;
    
    @Column
    private int gold;
    
    @Basic(optional = false)
    @Column
    private int isinner;
    
    @Column
    private int innerTotalGold;
    
    @Column
    private int innerGold;
    
    @Column
    private int innerCostGold;

    public Gold() {
    }

    public Gold(String username, int serverId) {
        this.goldPK = new GoldPK(username, serverId);
    }
    
    public Gold(GoldPK goldPK) {
        this.goldPK = goldPK;
    }

    public Gold(GoldPK goldPK, int isinner) {
        this.goldPK = goldPK;
        this.isinner = isinner;
    }

    public GoldPK getGoldPK() {
        return goldPK;
    }

    public void setGoldPK(GoldPK goldPK) {
        this.goldPK = goldPK;
    }

    public int getTotalGold() {
        return totalGold;
    }

    public void setTotalGold(int totalGold) {
        this.totalGold = totalGold;
    }

    public int getCostGold() {
        return costGold;
    }

    public void setCostGold(int costGold) {
        this.costGold = costGold;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getIsinner() {
        return isinner;
    }

    public void setIsinner(int isinner) {
        this.isinner = isinner;
    }

    public int getInnerTotalGold() {
        return innerTotalGold;
    }

    public void setInnerTotalGold(int innerTotalGold) {
        this.innerTotalGold = innerTotalGold;
    }

    public int getInnerGold() {
        return innerGold;
    }

    public void setInnerGold(int innerGold) {
        this.innerGold = innerGold;
    }

    public int getInnerCostGold() {
        return innerCostGold;
    }

    public void setInnerCostGold(int innerCostGold) {
        this.innerCostGold = innerCostGold;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + Objects.hashCode(this.goldPK);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Gold other = (Gold) obj;
        if (!Objects.equals(this.goldPK, other.goldPK)) {
            return false;
        }
        return true;
    }

    
}
