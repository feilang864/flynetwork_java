package com.game.po.log;

import com.game.structs.player.Player;
import javax.persistence.Column;
import javax.persistence.Entity;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
@Entity
public class RoleCreateLog extends BaseLog {

    public RoleCreateLog() {
    }

    public RoleCreateLog(Player player) {
        super(player);
        this.sex = player.getSex();
        this.job = player.getJob();
        this.agentPlusdata = player.getAgentPlusdata();
        this.agentColdatas = player.getAgentColdatas();
    }

    @Column
    private int sex;
    
    @Column
    private int job;
    
    @Column(length = 255)
    private String agentPlusdata;
    
    @Column(length = 255)
    private String agentColdatas;

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getJob() {
        return job;
    }

    public void setJob(int job) {
        this.job = job;
    }

    public String getAgentPlusdata() {
        return agentPlusdata;
    }

    public void setAgentPlusdata(String agentPlusdata) {
        this.agentPlusdata = agentPlusdata;
    }

    public String getAgentColdatas() {
        return agentColdatas;
    }

    public void setAgentColdatas(String agentColdatas) {
        this.agentColdatas = agentColdatas;
    }
    
}
