package com.game.structs.pet;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public enum PetJumpState {

    NOMAL,//正常状态
    JUMP,//一跳
    DOUBJUMP;//二跳 
}
