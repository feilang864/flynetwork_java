/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.manager.chat;

/**
 * 聊天管理类
 *
 * @author Troy.Chen
 * @phone 13882122019
 * @emil 492794628@qq.com
 *
 */
public class ChatManager {

    private static ChatManager instance;

    public static ChatManager getInstance() {
        if (instance == null) {
            synchronized (ChatManager.class) {
                if (instance == null) {
                    instance = new ChatManager();
                }
            }
        }
        return instance;
    }
    
    
    public void sendTips()
    {
    
    }
    
    
}
