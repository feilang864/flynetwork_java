package com.game.manager.player.script;

import com.game.engine.script.IBaseScript;
import com.game.structs.player.Player;

/**
 * 客户端加载场景完毕后执行
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public interface IPlayerLoginScript extends IBaseScript {

    public void action(Player player);

}
