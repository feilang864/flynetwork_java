package com.game.po.player;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
@Entity
@Table
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Gamemaster.findAll", query = "SELECT g FROM Gamemaster g"),
    @NamedQuery(name = "Gamemaster.findByUsername", query = "SELECT g FROM Gamemaster g WHERE g.username = :username"),
    @NamedQuery(name = "Gamemaster.findByRolename", query = "SELECT g FROM Gamemaster g WHERE g.rolename = :rolename"),
    @NamedQuery(name = "Gamemaster.findByServerid", query = "SELECT g FROM Gamemaster g WHERE g.serverid = :serverid"),
    @NamedQuery(name = "Gamemaster.findByGmlevel", query = "SELECT g FROM Gamemaster g WHERE g.gmlevel = :gmlevel")})
public class Gamemaster implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column
    private int id;
    
    @Basic(optional = false)
    @Column(length = 64)
    private String username;
    
    @Column(length = 64)
    private String rolename;
    
    @Column
    private int serverid;
    
    @Column
    private int gmlevel;
    
    @Column
    private long addtimes;
    
    @Column(length = 128)
    private String allowip;
    
    @Column
    private long allowtime;
    
    @Column
    private long date;
    
    @Column
    private int isDeleted;
    
    @Column(length = 128)
    private String addtag;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }

    public int getServerid() {
        return serverid;
    }

    public void setServerid(int serverid) {
        this.serverid = serverid;
    }

    public int getGmlevel() {
        return gmlevel;
    }

    public void setGmlevel(int gmlevel) {
        this.gmlevel = gmlevel;
    }

    public long getAddtimes() {
        return addtimes;
    }

    public void setAddtimes(long addtimes) {
        this.addtimes = addtimes;
    }

    public String getAllowip() {
        return allowip;
    }

    public void setAllowip(String allowip) {
        this.allowip = allowip;
    }

    public long getAllowtime() {
        return allowtime;
    }

    public void setAllowtime(long allowtime) {
        this.allowtime = allowtime;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getAddtag() {
        return addtag;
    }

    public void setAddtag(String addtag) {
        this.addtag = addtag;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Gamemaster other = (Gamemaster) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

}
