package com.game.structs.buff;

import com.game.structs.player.Person;

/**
 * buff
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public interface IBuff {

    /**
     * 增加buff
     *
     * @param source 来源
     * @param target 对象
     * @return
     */
    public int add(Person source, Person target);

    /**
     * buff作用
     *
     * @param source 来源
     * @param target 对象
     * @param calnum
     * @return 作用数值 0-失败 1-成功 2-移除 3-涉及别的buff移除，需要终止计算
     */
    public int action(Person source, Person target, int calnum);

    /**
     * 移除buff
     *
     * @param source 来源
     * @return
     */
    public int remove(Person source);
}
