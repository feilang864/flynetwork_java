package com.game.manager.player.script;

import com.game.engine.script.IBaseScript;
import com.game.structs.player.Player;

/**
 * 选择角色完毕后执行脚本
 * @author Vicky
 * @mail  eclipser@163.com
 * @phone 13618074943
 */
public interface ISelectPlayerScript extends IBaseScript {

    public void action(Player player);
}
