package com.game.structs.skill;

import com.game.engine.object.GameObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 技能
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Skill extends GameObject {

    private static final Logger logger = LoggerFactory.getLogger(Skill.class);
    
    private static final long serialVersionUID = -4048773480706290213L;
    
    //技能模板Id
    private int skillModelId;
    //技能等级
    private int skillLevel;
    //技能熟练度
    private int skillneednum;
    //加成过的等级
    private transient int realLevel;

    public int getSkillModelId() {
        return skillModelId;
    }

    public void setSkillModelId(int skillModelId) {
        this.skillModelId = skillModelId;
    }

    public int getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(int skillLevel) {
        this.skillLevel = skillLevel;
    }

    public int getSkillneednum() {
        return skillneednum;
    }

    public void setSkillneednum(int skillneednum) {
        this.skillneednum = skillneednum;
    }

}
