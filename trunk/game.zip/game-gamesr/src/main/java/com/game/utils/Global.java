package com.game.utils;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Global {

    // 默认读取屏蔽字库平台名
    public static final String WORDFILTER_AGENT = "37wan";
    
    // 初始背包数量
    public static final int DEFAULT_BAG_CELLS = 30;
    
    // 最大背包数量
    public static final int DEFAULT_BAG_CELLS_MAX = 125;
    
    // 初始仓库数量
    public static final int DEFAULT_STORE_CELLS = 10;
    
    // 最大仓库数量
    public static final int DEFAULT_STORE_CELLS_MAX = 125;
}
