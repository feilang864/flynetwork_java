package com.game.po.log;

import com.game.gamesr.main.Main;
import com.game.po.player.Role;
import com.game.structs.player.Player;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class BaseLog implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    // 所属用户ID
    @Column
    private long userid;
    
    // 所属用户名称
    @Column
    private String username;
    
    // 创建的服务器ID
    @Column
    private int serverid;

    // 服务器名称
    @Column(length = 64)
    private String servername;
    
    // 渠道名称
    @Column(length = 64)
    private String serverweb;
    
    // 角色ID
    @Column
    private long playerid;
    
    // 角色名称
    @Column(length = 64)
    private String playername;
    
    // 登录的服务器IP
    @Column(length = 64)
    private String loginIP;
    
    // 日志创建的服务器ID
    @Column(nullable = false)
    private int createServerID;
    
    // 日志创建的服务器名称
    @Column(nullable = false, length = 64)
    private String createServerName;
    
    // 日志创建的服务器渠道
    @Column(nullable = false, length = 64)
    private String createServerWeb;
    
    // 创建时间
    @Column(nullable = false)
    private long createTime = System.currentTimeMillis();
    
    public BaseLog() {
    }

    public BaseLog(Player player) {
        // 初始化日志字段信息
        if (player != null) {
            this.userid = player.getUserid();
            this.username = player.getUsername();
            this.serverid = player.getServerid();
            this.servername = player.getServername();
            this.serverweb = player.getServerweb();
            this.loginIP = player.getLoginIP();
        }
        this.createServerID = Main.getServerID();
        this.createServerName = Main.getServerName();
        this.createServerWeb = Main.getServerWeb();
    }

    public BaseLog(Role role) {
        if (role != null) {
            this.userid = role.getUserid();
            this.username = role.getUsername();
            this.serverid = role.getServerid();
            this.servername = role.getServername();
            this.serverweb = role.getServerweb();
            this.loginIP = role.getLoginIP();
        }
        this.createServerID = Main.getServerID();
        this.createServerName = Main.getServerName();
        this.createServerWeb = Main.getServerWeb();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserid() {
        return userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getServerid() {
        return serverid;
    }

    public void setServerid(int serverid) {
        this.serverid = serverid;
    }

    public String getServername() {
        return servername;
    }

    public void setServername(String servername) {
        this.servername = servername;
    }

    public String getServerweb() {
        return serverweb;
    }

    public void setServerweb(String serverweb) {
        this.serverweb = serverweb;
    }

    public String getLoginIP() {
        return loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public long getPlayerid() {
        return playerid;
    }

    public void setPlayerid(long playerid) {
        this.playerid = playerid;
    }

    public String getPlayername() {
        return playername;
    }

    public void setPlayername(String playername) {
        this.playername = playername;
    }

    public int getCreateServerID() {
        return createServerID;
    }

    public void setCreateServerID(int createServerID) {
        this.createServerID = createServerID;
    }

    public String getCreateServerName() {
        return createServerName;
    }

    public void setCreateServerName(String createServerName) {
        this.createServerName = createServerName;
    }

    public String getCreateServerWeb() {
        return createServerWeb;
    }

    public void setCreateServerWeb(String createServerWeb) {
        this.createServerWeb = createServerWeb;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BaseLog other = (BaseLog) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
}
