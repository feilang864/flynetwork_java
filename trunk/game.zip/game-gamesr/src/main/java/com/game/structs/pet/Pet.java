package com.game.structs.pet;

import com.game.engine.utils.Config;
import com.game.structs.Position;
import com.game.manager.pet.PetOptManager;
import com.game.structs.map.IMapObject;
import com.game.structs.map.Jump;
import com.game.structs.player.Person;
import com.game.structs.player.Player;
import com.game.structs.skill.Skill;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Pet extends Person implements IMapObject {
    
    private static final long serialVersionUID = 1L;
    
    public Pet() {
        super();
        this.personType = Person.PERSON_PET;
    }

    // 攻击对象列表
    private transient List<Person> attackTargets = new ArrayList<>();
    // 攻击对象
    private transient Person attTarget;
    // 攻击对象的类型
    private transient int targetType;
    // 宠物状态
    private transient PetState state = PetState.UNSHOW;
    private transient PetJumpState jumpState = PetJumpState.NOMAL;
    private transient PetRunState runState = PetRunState.RUN;
    private transient Jump jump = new Jump();
    private transient Position dest;
    // 默认技能
    private Skill defaultSkill = new Skill();
    // 上一次寻路的时间
    private transient long lastFindRoadsTime = 0;
    // 最后一次攻击或被攻击时间 用于计算战斗状态
    private transient long lastFightTime = 0;
    // 上一次回血时间
    private transient long lastRecoveryTime = 0;
    // 是否强制收回的
    private transient boolean isForceHide = false;
    // 标志列表
    private HashSet<String> tagSet = new HashSet<>();
    // 是否显示
    private boolean show = false;
    // 死亡时间
    private long dieTime = 0l;
    private long ownerId;
    // 出战次数
    private int showCount = 0;
    // 出战时间
    private long showTime = 0l;
    private int attackcount;
    // 被召唤时间
    private long callTime;
    // 怪物模板
    private int monsterModelId;
    // 技能等级
    private int defskilllv;
    // 宠物临时状态 0=没有 1=是否被召唤 2=战斗状态
    private byte tmpstate;
    // 宠物战斗状态时间
    private long fightstateTime;

    public Pet(Player player, int modelid, int lv, int petlv) {
        this.setModelId(modelid);
        this.setId(Config.getId());
        this.ownerId = player.getId();
        this.show = false;
        this.state = PetState.IDEL;
        // Q_petBean model =
        // DataManager.getInstance().q_petContainer.getMap().get(modelid + "_" +
        // lv);
        this.setLevel(petlv);
        if (this.getLevel() > PetOptManager.MAXPETLEVEL) {
            this.setLevel(PetOptManager.MAXPETLEVEL);
        }
        this.defskilllv = lv;
    }

    public List<Person> getAttackTargets() {
        return attackTargets;
    }

    public void setAttackTargets(List<Person> attackTargets) {
        this.attackTargets = attackTargets;
    }

    public Person getAttTarget() {
        return attTarget;
    }

    public void setAttTarget(Person attTarget) {
        this.attTarget = attTarget;
    }

    public int getTargetType() {
        return targetType;
    }

    public void setTargetType(int targetType) {
        this.targetType = targetType;
    }

    public PetState getState() {
        return state;
    }

    public void setState(PetState state) {
        this.state = state;
    }

    public PetJumpState getJumpState() {
        return jumpState;
    }

    public void setJumpState(PetJumpState jumpState) {
        this.jumpState = jumpState;
    }

    public PetRunState getRunState() {
        return runState;
    }

    public void setRunState(PetRunState runState) {
        this.runState = runState;
    }

    public Jump getJump() {
        return jump;
    }

    public void setJump(Jump jump) {
        this.jump = jump;
    }

    public Position getDest() {
        return dest;
    }

    public void setDest(Position dest) {
        this.dest = dest;
    }

    public Skill getDefaultSkill() {
        return defaultSkill;
    }

    public void setDefaultSkill(Skill defaultSkill) {
        this.defaultSkill = defaultSkill;
    }

    public long getLastFindRoadsTime() {
        return lastFindRoadsTime;
    }

    public void setLastFindRoadsTime(long lastFindRoadsTime) {
        this.lastFindRoadsTime = lastFindRoadsTime;
    }

    public long getLastFightTime() {
        return lastFightTime;
    }

    public void setLastFightTime(long lastFightTime) {
        this.lastFightTime = lastFightTime;
    }

    public long getLastRecoveryTime() {
        return lastRecoveryTime;
    }

    public void setLastRecoveryTime(long lastRecoveryTime) {
        this.lastRecoveryTime = lastRecoveryTime;
    }

    public boolean isIsForceHide() {
        return isForceHide;
    }

    public void setIsForceHide(boolean isForceHide) {
        this.isForceHide = isForceHide;
    }

    public HashSet<String> getTagSet() {
        return tagSet;
    }

    public void setTagSet(HashSet<String> tagSet) {
        this.tagSet = tagSet;
    }

    public boolean isShow() {
        return show;
    }

    public void setShow(boolean show) {
        this.show = show;
    }

    public long getDieTime() {
        return dieTime;
    }

    public void setDieTime(long dieTime) {
        this.dieTime = dieTime;
    }

    public long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }

    public int getShowCount() {
        return showCount;
    }

    public void setShowCount(int showCount) {
        this.showCount = showCount;
    }

    public long getShowTime() {
        return showTime;
    }

    public void setShowTime(long showTime) {
        this.showTime = showTime;
    }
    
    public int getAttackcount() {
        return attackcount;
    }

    public void setAttackcount(int attackcount) {
        this.attackcount = attackcount;
    }

    public long getCallTime() {
        return callTime;
    }

    public void setCallTime(long callTime) {
        this.callTime = callTime;
    }

    public int getMonsterModelId() {
        return monsterModelId;
    }

    public void setMonsterModelId(int monsterModelId) {
        this.monsterModelId = monsterModelId;
    }

    public int getDefskilllv() {
        return defskilllv;
    }

    public void setDefskilllv(int defskilllv) {
        this.defskilllv = defskilllv;
    }

    public byte getTmpstate() {
        return tmpstate;
    }

    public void setTmpstate(byte tmpstate) {
        this.tmpstate = tmpstate;
    }

    public long getFightstateTime() {
        return fightstateTime;
    }

    public void setFightstateTime(long fightstateTime) {
        this.fightstateTime = fightstateTime;
    }
    
    

}
