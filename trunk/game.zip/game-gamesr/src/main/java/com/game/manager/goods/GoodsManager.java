/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.manager.goods;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import java.util.HashMap;
import org.apache.log4j.Logger;

/**
 * 物品管理类
 *
 * @author Troy.Chen
 */
public class GoodsManager {

    private final Logger logger = Logger.getLogger(GoodsManager.class);
    private static GoodsManager instance;

    /**
     * 返回物品管理类的实例
     *
     * @return
     */
    public static GoodsManager getInstance() {
        if (instance == null) {
            synchronized (GoodsManager.class) {
                if (instance == null) {
                    instance = new GoodsManager();
                }
            }
        }
        return instance;
    }

    private GoodsManager() {
        logger.info("create goods Manager");
        this.goodsMap = new HashMap<>(2);
        if (!loadData()) {

        }
    }

    public <T> T myClone(T t) {
        String toJSONString = JSON.toJSONString(t, new SerializerFeature[]{SerializerFeature.WriteClassName, SerializerFeature.DisableCircularReferenceDetect});
        return (T) JSON.parseObject(toJSONString, t.getClass());
    }

    /**
     * 加载goods配置数据到内存
     *
     * @return
     */
    public boolean loadData() {
        logger.info("load goods data");

        // todo 加载数据到内存
        if (false) {

            return true;
        } else {

            logger.error("load goods data error");
            return false;
        }
    }

    HashMap<Integer, Goods> goodsMap;

    /**
     * 获取一个物品
     *
     * @param itemid
     * @return
     */
    public Goods getGoods(Integer itemid) {
        return goodsMap.get(itemid);
    }

}
