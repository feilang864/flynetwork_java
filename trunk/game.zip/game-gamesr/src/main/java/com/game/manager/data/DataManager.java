package com.game.manager.data;

import com.game.po.data.Filterword;
import com.game.po.data.RoleRandomName;
import com.game.po.data.controller.FilterwordJpaController;
import com.game.po.data.controller.RoleRandomNameJpaController;
import com.game.po.player.controller.GamemasterJpaController;
import com.game.po.player.controller.GoldJpaController;
import com.game.po.player.controller.RoleJpaController;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class DataManager {

    private static final Logger log = LoggerFactory.getLogger(DataManager.class);
    
    private static final DataManager instance = new DataManager();
    
    
    public static DataManager getInstance() {
        return instance;
    }
    
    private final EntityManagerFactory baseEntityManagerFactory = Persistence.createEntityManagerFactory("pu");
    private final RoleJpaController roleDao = new RoleJpaController(baseEntityManagerFactory);
    private final GoldJpaController goldDao = new GoldJpaController(baseEntityManagerFactory);
    private final GamemasterJpaController gamemasterDao = new GamemasterJpaController(baseEntityManagerFactory);
    
    public RoleJpaController getRoleDao() {
        return roleDao;
    }

    public GoldJpaController getGoldDao() {
        return goldDao;
    }

    public GamemasterJpaController getGamemasterDao() {
        return gamemasterDao;
    }
    
    
    
    
    
    
    
    
    
    //=======================
    
    
    private final EntityManagerFactory dataEntityManagerFactory = Persistence.createEntityManagerFactory("data");
    private final RoleRandomNameJpaController roleRandomNameDao = new RoleRandomNameJpaController(dataEntityManagerFactory);
    private final FilterwordJpaController filterwordDao  = new FilterwordJpaController(dataEntityManagerFactory);
    
    
    private final List<RoleRandomName> roleRandomNameList;
    private final Map<Integer, RoleRandomName> roleRandomNameMap = new HashMap<>();
    
    
    private final List<Filterword> filterwordList;
    private final Map<String, Filterword> filterwordMap = new HashMap<>();
    
    private DataManager() {
        roleRandomNameList = roleRandomNameDao.findRoleRandomNameEntities();
        for (RoleRandomName o : roleRandomNameList) {
            roleRandomNameMap.put(o.getId(), o);
        }
        
        filterwordList = filterwordDao.findFilterwordEntities();
        for (Filterword o : filterwordList) {
            filterwordMap.put(o.getAgents(), o);
        }
        
    }

    public List<RoleRandomName> getRoleRandomNameList() {
        return roleRandomNameList;
    }

    public Map<Integer, RoleRandomName> getRoleRandomNameMap() {
        return roleRandomNameMap;
    }

    public List<Filterword> getFilterwordList() {
        return filterwordList;
    }

    public Map<String, Filterword> getFilterwordMap() {
        return filterwordMap;
    }
   
    
    
    //===========================
    private final EntityManagerFactory logEntityManagerFactory = Persistence.createEntityManagerFactory("log");

    public EntityManager getLogEntityManager() {
        return logEntityManagerFactory.createEntityManager();
    }
    
}
