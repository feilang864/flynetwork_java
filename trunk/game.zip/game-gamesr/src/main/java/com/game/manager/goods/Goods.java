/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.manager.goods;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import org.apache.log4j.Logger;

/**
 *
 * @author Administrator
 */
public class Goods {

    public Goods() {
    }

    private final Logger logger = Logger.getLogger(Goods.class);
    //平台
    private String q_agents;

    //区服
    private String q_zones;

    public String getQ_agents() {
        return q_agents;
    }

    public void setQ_agents(String q_agents) {
        this.q_agents = q_agents;
    }

    public String getQ_zones() {
        return q_zones;
    }

    public void setQ_zones(String q_zones) {
        this.q_zones = q_zones;
    }

    public Goods(String q_agents, String q_zones) {
        this.q_agents = q_agents;
        this.q_zones = q_zones;
    }

    @Override
    public String toString() {
        logger.info(this.getQ_agents() + "   " + q_zones);
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }

}
