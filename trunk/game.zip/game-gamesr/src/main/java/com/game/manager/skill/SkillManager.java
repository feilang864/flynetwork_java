package com.game.manager.skill;

import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class SkillManager {

    private static final Logger log = LoggerFactory.getLogger(SkillManager.class);
    
    private static final SkillManager instance = new SkillManager();
    
    public static SkillManager getInstance() {
        return instance;
    }
    
    private SkillManager() {
    
    }

    /**
     * 初始化Skill信息
     * @param player 
     */
    public void autoStudySkill(Player player) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
