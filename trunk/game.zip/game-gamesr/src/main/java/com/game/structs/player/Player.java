package com.game.structs.player;

import com.game.po.player.Gold;
import com.game.structs.equipment.Equipment;
import com.game.structs.fashion.Fashion;
import com.game.structs.raywing.RayWing;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Player extends Person {

    private static final long serialVersionUID = 1L;
    
    // 所属用户ID
    private long userid;
    
    // 所属用户名称
    private String username;
    
    // 创建的服务器ID
    private int serverid;

    // 服务器名称
    private String servername;
    
    // 渠道名称
    private String serverweb;
    
    // 登录的服务器IP
    private String loginIP;
    
    // 平台参数1
    private String agentPlusdata;
    
    // 平台参数2
    private String agentColdatas;
    
    //版本号
    private String version;
    
    //删除状态
    private boolean deleted;
    
    //封停状态
    private boolean forbided;
    
    //==============================
    
    //角色状体
    private PlayerState state;
    
    //原来名称
    private String name2;

    //职业
    private int job;

    //性别1男2女
    private int sex;

    //国家
    private int country;

    // 0 正常 1 可以删除>1 倒计时秒
    private long deleteAt;

    //星座
    private int constellation;
    
    //未成年状态
    private boolean adult;
    
    // gm状态
    private int gmState;
    
    // 游戏币
    private int money;
    
    // 自动同意加入帮会
    private byte autoArgeeAddGuild;
    
    // 包裹已开格子数
    private int bagCellsNum;
    
    // 仓库已开格子数
    private int storeCellsNum;
    
    // 包裹开格时间统计
    private int bagCellTimeCount;
    
    // 仓库开格时间统计
    private int storeCellTimeCount;

    // VIP等级ID(0-10,0为不是vip)
    private int vip;
    
    // 平台vip
    private int webvip;
    
    // 内部vip
    private int innervip;
    
    //屏幕宽度
    private int width;
    
    //屏幕高度
    private int height;
    
    //禁言结束时间
    private long prohibitChatEndTime;
    
    private List<Equipment> equips = new ArrayList<>();//装备
    private List<RayWing> wings = new ArrayList<>();//翅膀
    private List<Fashion> fashions = new ArrayList<>();//时装
    
    
    // 杂乱信息列表------------已存放信息：vip，
    public static final String VARIABLE_VIP = "vipDetailInfo";
    private Map<String, Object> variables = new HashMap<>();
    
    
    
    
    //======================================
    
    private transient Gold gold;
    
    // GM等级
    private transient int gmlevel;
    
    // 最后存档时间
    private transient long lastSaveTime;
    
    // 登录随机时间
    private transient long loginRandomTime;
    
    // 客户端验证时间
    private transient long clientVerifyTime;
    
    // 玩家删除并且存档的时间（对象废弃时间）
    private transient AtomicLong objDelAndSaveTime = new AtomicLong(0);
    
    
    // ------------------回城点部分begin--------------------//
    // 回城点地图id
    private int backCityMapId;
    // 回城点坐标X
    private int backCityX;
    // 回城点坐标Y
    private int backCityY;
    
    public int getBackCityMapId() {
        return backCityMapId;
    }

    public void setBackCityMapId(int backCityMapId) {
        this.backCityMapId = backCityMapId;
    }

    public int getBackCityX() {
        return backCityX;
    }

    public void setBackCityX(int backCityX) {
        this.backCityX = backCityX;
    }

    public int getBackCityY() {
        return backCityY;
    }

    public void setBackCityY(int backCityY) {
        this.backCityY = backCityY;
    }
    // ------------------回城点部分begin--------------------//
    
    
    
    // --------------------玩家时间----------------------------
    // 累计在线总时间
    private int onlinetime;
    // 今日累计在线时间
    private int onlinetimeday;
    // 当前日期 （标记今日累计在线时间用）
    private int curday;
    // 累计时间-上线时刻-记录
    private int loginlinetime;
    // --------------------玩家时间 end ----------------------------
    
    
    // 登录时间
    private long loginTime;

    public long getUserid() {
        return userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getServername() {
        return servername;
    }

    public void setServername(String servername) {
        this.servername = servername;
    }

    public String getServerweb() {
        return serverweb;
    }

    public void setServerweb(String serverweb) {
        this.serverweb = serverweb;
    }

    public int getServerid() {
        return serverid;
    }

    public void setServerid(int serverid) {
        this.serverid = serverid;
    }

    public String getLoginIP() {
        return loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public String getAgentPlusdata() {
        return agentPlusdata;
    }

    public void setAgentPlusdata(String agentPlusdata) {
        this.agentPlusdata = agentPlusdata;
    }

    public String getAgentColdatas() {
        return agentColdatas;
    }

    public void setAgentColdatas(String agentColdatas) {
        this.agentColdatas = agentColdatas;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean isForbided() {
        return forbided;
    }

    public void setForbided(boolean forbided) {
        this.forbided = forbided;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public long getProhibitChatEndTime() {
        return prohibitChatEndTime;
    }

    public void setProhibitChatEndTime(long prohibitChatEndTime) {
        this.prohibitChatEndTime = prohibitChatEndTime;
    }

    public PlayerState getState() {
        return state;
    }

    public void setState(PlayerState state) {
        this.state = state;
    }
    
    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public int getJob() {
        return job;
    }

    public void setJob(int job) {
        this.job = job;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getCountry() {
        return country;
    }

    public void setCountry(int country) {
        this.country = country;
    }

    public long getDeleteAt() {
        return deleteAt;
    }

    public void setDeleteAt(long deleteAt) {
        this.deleteAt = deleteAt;
    }

    public int getConstellation() {
        return constellation;
    }

    public void setConstellation(int constellation) {
        this.constellation = constellation;
    }

    public boolean isAdult() {
        return adult;
    }

    public void setAdult(boolean adult) {
        this.adult = adult;
    }
    
    public List<Equipment> getEquips() {
        return equips;
    }

    public void setEquips(List<Equipment> equips) {
        this.equips = equips;
    }

    public List<RayWing> getWings() {
        return wings;
    }

    public void setWings(List<RayWing> wings) {
        this.wings = wings;
    }

    public List<Fashion> getFashions() {
        return fashions;
    }

    public void setFashions(List<Fashion> fashions) {
        this.fashions = fashions;
    }

    public Gold getGold() {
        return gold;
    }

    public void setGold(Gold gold) {
        this.gold = gold;
    }

    public int getGmState() {
        return gmState;
    }

    public void setGmState(int gmState) {
        this.gmState = gmState;
    }

    public int getGmlevel() {
        return gmlevel;
    }

    public void setGmlevel(int gmlevel) {
        this.gmlevel = gmlevel;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public byte getAutoArgeeAddGuild() {
        return autoArgeeAddGuild;
    }

    public void setAutoArgeeAddGuild(byte autoArgeeAddGuild) {
        this.autoArgeeAddGuild = autoArgeeAddGuild;
    }

    public int getBagCellsNum() {
        return bagCellsNum;
    }

    public void setBagCellsNum(int bagCellsNum) {
        this.bagCellsNum = bagCellsNum;
    }

    public int getStoreCellsNum() {
        return storeCellsNum;
    }

    public void setStoreCellsNum(int storeCellsNum) {
        this.storeCellsNum = storeCellsNum;
    }

    public int getBagCellTimeCount() {
        return bagCellTimeCount;
    }

    public void setBagCellTimeCount(int bagCellTimeCount) {
        this.bagCellTimeCount = bagCellTimeCount;
    }

    public int getStoreCellTimeCount() {
        return storeCellTimeCount;
    }

    public void setStoreCellTimeCount(int storeCellTimeCount) {
        this.storeCellTimeCount = storeCellTimeCount;
    }

    public int getVip() {
        return vip;
    }

    public void setVip(int vip) {
        this.vip = vip;
    }

    public int getWebvip() {
        return webvip;
    }

    public void setWebvip(int webvip) {
        this.webvip = webvip;
    }

    public int getInnervip() {
        return innervip;
    }

    public void setInnervip(int innervip) {
        this.innervip = innervip;
    }

    public Map<String, Object> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, Object> variables) {
        this.variables = variables;
    }

    public int getOnlinetime() {
        return onlinetime;
    }

    public void setOnlinetime(int onlinetime) {
        this.onlinetime = onlinetime;
    }

    public int getOnlinetimeday() {
        return onlinetimeday;
    }

    public void setOnlinetimeday(int onlinetimeday) {
        this.onlinetimeday = onlinetimeday;
    }

    public int getCurday() {
        return curday;
    }

    public void setCurday(int curday) {
        this.curday = curday;
    }

    public int getLoginlinetime() {
        return loginlinetime;
    }

    public void setLoginlinetime(int loginlinetime) {
        this.loginlinetime = loginlinetime;
    }

    public AtomicLong getObjDelAndSaveTime() {
        return objDelAndSaveTime;
    }

    public void setObjDelAndSaveTime(AtomicLong objDelAndSaveTime) {
        this.objDelAndSaveTime = objDelAndSaveTime;
    }

    public long getLastSaveTime() {
        return lastSaveTime;
    }

    public void setLastSaveTime(long lastSaveTime) {
        this.lastSaveTime = lastSaveTime;
    }

    public long getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(long loginTime) {
        this.loginTime = loginTime;
    }

    public long getLoginRandomTime() {
        return loginRandomTime;
    }

    public void setLoginRandomTime(long loginRandomTime) {
        this.loginRandomTime = loginRandomTime;
    }

    public long getClientVerifyTime() {
        return clientVerifyTime;
    }

    public void setClientVerifyTime(long clientVerifyTime) {
        this.clientVerifyTime = clientVerifyTime;
    }
    
}
