package com.game.structs.monster;

/**
 * 伤害记录
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class MonsterDamage {

    private long roleid;
    private int damage;
    private long time;
    private double damagepercent;

    public long getRoleid() {
        return roleid;
    }

    public void setRoleid(long roleid) {
        this.roleid = roleid;
    }

    public double getDamagepercent() {
        return damagepercent;
    }

    public void setDamagepercent(double damagepercent) {
        this.damagepercent = damagepercent;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
