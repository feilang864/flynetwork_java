package com.game.manager.gm;

import com.game.manager.data.DataManager;
import com.game.po.player.Gamemaster;
import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class GMCommandManager {

    private static final Logger log = LoggerFactory.getLogger(GMCommandManager.class);

    private static final GMCommandManager instance = new GMCommandManager();

    public static GMCommandManager getInstance() {
        return instance;
    }

    private GMCommandManager() {
    }

    public void reloadGMLevel(Player player) {
        try {
            player.setGmlevel(0);
            String username = player.getUsername();
            Gamemaster gm = DataManager.getInstance().getGamemasterDao().selectByAccount(username);
            if (gm == null) {
                if (username.startsWith("#robot")) {
                    gm = DataManager.getInstance().getGamemasterDao().selectByAccount("#robot");
                    if (gm == null) {
                        player.setGmlevel(0);
                        return;
                    }
                } else {
                    player.setGmlevel(0);
                    return;
                }
            }

            player.setGmlevel(gm.getGmlevel());

            String gmIps = gm.getAllowip();         //gm允许登录的IP群
            String playerip = player.getLoginIP();  //获取玩家登录IP
            if ((gm.getRolename() != null && !gm.getRolename().equals("") && !gm.getRolename().equals(player.getName())) && (!username.startsWith("#robot"))) {//判断此此玩家是否在线(包含了账号是否存在)
                player.setGmlevel(0);
            } else if (gm.getServerid() != player.getServerid()) {//判断区服是否匹配
                player.setGmlevel(0);
            } else if (gmIps != null && !gmIps.equals("") && !ipMatch(gmIps, playerip)) {//判断IP是否匹配
                player.setGmlevel(0);
            } else {
                //判断是否过期
            }
        } catch (Exception e) {
            log.error("重载GM等级出错!", e);
            player.setGmlevel(0);
        }
    }

    /**
     * 匹配IP
     *
     * @param gmIps
     * @param playerip
     * @return
     */
    public static Boolean ipMatch(String gmIps, String playerip) {
        String[] gmIpArray = gmIps.split(";");//将gm IP群分割成一组组IP
        for (String ip : gmIpArray) {
            String[] gmIP = ip.trim().split("\\.");
            String[] playerIP = playerip.trim().split("\\.");
            for (int j = 0; j < 4; j++) {
                if (gmIP[j].equals("*")) {//属于某一个IP组，如192.168.*.*，成功
                    return true;
                } else if (!gmIP[j].equals(playerIP[j])) {//当前级不匹配，失败，跳出
                    break;
                } else if (j == 3) {//最后一级匹配，成功
                    return true;
                } else {//不是最后一级匹配，看下一级是否匹配
                    // continue;
                }
            }
        }
        return false;
    }
}
