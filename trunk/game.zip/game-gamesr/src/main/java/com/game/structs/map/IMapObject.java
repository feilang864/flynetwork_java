package com.game.structs.map;

import com.game.structs.player.Player;
import com.game.structs.Position;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public interface IMapObject {

    public long getId();

    public int getLine();

    public int getMapId();

    public Position getPosition();

    public boolean canSee(Player player);
}
