package com.game.po.data.controller;

import com.game.po.data.RoleRandomName;
import com.game.po.data.controller.exceptions.NonexistentEntityException;
import com.game.po.data.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class RoleRandomNameJpaController implements Serializable {

    public RoleRandomNameJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(RoleRandomName roleRandomName) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(roleRandomName);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findRoleRandomName(roleRandomName.getId()) != null) {
                throw new PreexistingEntityException("RoleRandomName " + roleRandomName + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(RoleRandomName roleRandomName) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            roleRandomName = em.merge(roleRandomName);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                int id = roleRandomName.getId();
                if (findRoleRandomName(id) == null) {
                    throw new NonexistentEntityException("The roleRandomName with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(int id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            RoleRandomName roleRandomName;
            try {
                roleRandomName = em.getReference(RoleRandomName.class, id);
                roleRandomName.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The roleRandomName with id " + id + " no longer exists.", enfe);
            }
            em.remove(roleRandomName);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<RoleRandomName> findRoleRandomNameEntities() {
        return findRoleRandomNameEntities(true, -1, -1);
    }

    public List<RoleRandomName> findRoleRandomNameEntities(int maxResults, int firstResult) {
        return findRoleRandomNameEntities(false, maxResults, firstResult);
    }

    private List<RoleRandomName> findRoleRandomNameEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(RoleRandomName.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public RoleRandomName findRoleRandomName(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(RoleRandomName.class, id);
        } finally {
            em.close();
        }
    }

    public int getRoleRandomNameCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<RoleRandomName> rt = cq.from(RoleRandomName.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
