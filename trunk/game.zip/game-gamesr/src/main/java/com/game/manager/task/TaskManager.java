package com.game.manager.task;

import com.game.structs.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class TaskManager {

    private static final Logger log = LoggerFactory.getLogger(TaskManager.class);
    
    
    private static final TaskManager instance = new TaskManager();
    
    //人物出生默认学会的任务
    public final static int CREATEPLAYERDEFAULTTASK = 10000;
    
    
    public static TaskManager getInstance() {
        return instance;
    }

    /**
     * 接收主线任务
     * @param player
     * @param CREATEPLAYERDEFAULTTASK 
     */
    public void acceptMainTask(Player player, int CREATEPLAYERDEFAULTTASK) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
