package com.game.structs.vip;

import java.io.Serializable;

/**
 * VIP信息
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class VipDetailInfo implements Serializable {
    
}
