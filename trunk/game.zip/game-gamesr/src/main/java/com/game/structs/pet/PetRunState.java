package com.game.structs.pet;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public enum PetRunState {
	RUN,//跑步
	SWIM;//游泳 
}

