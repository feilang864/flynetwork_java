package com.game.structs.monster;

/**
 * 怪物AI
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class MonsterAi {

    /**
     * 类型
     */
    private int aiType;
    /**
     * 间隔(可以是时间，血量等)
     */
    private int interval;
    /**
     * 几率
     */
    private int rnd;
    /**
     * 说话
     */
    private String say;
    /**
     * 预警特效
     */
    private int warnId;
    /**
     * 预警特效时间
     */
    private int warnTime;
    /**
     * 触发技能
     */
    private String skillId;
    /**
     * 作用对象
     */
    private int target;

    /**
     * 类型
     *
     * @return the aiType
     */
    public int getAiType() {
        return aiType;
    }

    /**
     * 类型
     *
     * @param aiType the aiType to set
     */
    public void setAiType(int aiType) {
        this.aiType = aiType;
    }

    /**
     * 间隔(可以是时间，血量等)
     *
     * @return the interval
     */
    public int getInterval() {
        return interval;
    }

    /**
     * 间隔(可以是时间，血量等)
     *
     * @param interval the interval to set
     */
    public void setInterval(int interval) {
        this.interval = interval;
    }

    /**
     * 几率
     *
     * @return the rnd
     */
    public int getRnd() {
        return rnd;
    }

    /**
     * 几率
     *
     * @param rnd the rnd to set
     */
    public void setRnd(int rnd) {
        this.rnd = rnd;
    }

    /**
     * 说话
     *
     * @return the say
     */
    public String getSay() {
        return say;
    }

    /**
     * 说话
     *
     * @param say the say to set
     */
    public void setSay(String say) {
        this.say = say;
    }

    /**
     * 预警特效
     *
     * @return the warnId
     */
    public int getWarnId() {
        return warnId;
    }

    /**
     * 预警特效
     *
     * @param warnId the warnId to set
     */
    public void setWarnId(int warnId) {
        this.warnId = warnId;
    }

    /**
     * 预警特效时间
     *
     * @return the warnTime
     */
    public int getWarnTime() {
        return warnTime;
    }

    /**
     * 预警特效时间
     *
     * @param warnTime the warnTime to set
     */
    public void setWarnTime(int warnTime) {
        this.warnTime = warnTime;
    }

    /**
     * 触发技能
     *
     * @return the skillId
     */
    public String getSkillId() {
        return skillId;
    }

    /**
     * 触发技能
     *
     * @param skillId the skillId to set
     */
    public void setSkillId(String skillId) {
        this.skillId = skillId;
    }

    /**
     * 作用对象
     *
     * @return the target
     */
    public int getTarget() {
        return target;
    }

    /**
     * 作用对象
     *
     * @param target the target to set
     */
    public void setTarget(int target) {
        this.target = target;
    }
}
