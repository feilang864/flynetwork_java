package com.game.manager.player;

import com.game.engine.cache.impl.MemoryCache;
import com.game.engine.script.IBaseScript;
import com.game.engine.script.manager.ScriptManager;
import com.game.engine.utils.JsonUtil;
import com.game.gamesr.main.Main;
import com.game.manager.data.DataManager;
import com.game.manager.player.script.ICreatePlayerEndScript;
import com.game.po.player.Role;
import com.game.proto.LoginMessage;
import com.game.structs.Position;
import com.game.structs.player.Player;
import com.game.utils.Global;
import com.game.utils.RandomUtils;
import com.game.utils.WordFilter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class PlayerManager {

    private static final Logger log = LoggerFactory.getLogger(PlayerManager.class);

    private static final PlayerManager instance = new PlayerManager();
    
    public static final String LOGINPLAYERID = "LOGINPLAYERID"; // 登录选择的角色ID

    public static final int MAXCANCREATE = 3; // 一个帐号允许创建的人物数量上线

    public static final int BIRTHMAP = 101;   // 玩家初始地图

    public static PlayerManager getInstance() {
        return instance;
    }

    private PlayerManager() {
    }

    // 玩家数据缓存
    private final MemoryCache<Long, Player> players = new MemoryCache<>();

    // 账号对应玩家列表
    private final Map<String, List<Player>> userPlayers = new ConcurrentHashMap<>();

    // 玩家在线列表（key为角色编号）
    private final Map<Long, Player> online = new ConcurrentHashMap<>();

    // 账号在线列表（key为账号名称）
    private final Map<String, Player> user = new HashMap<>();

    /**
     * 创建角色
     *
     * @param name 名称
     * @param icon
     * @param sex
     * @param job
     * @return
     */
    public Player createPlayer(String name, int icon, int sex, int job) {
        Player player = new Player();
        player.setMapId(PlayerManager.BIRTHMAP);
        player.setMapModelId(PlayerManager.BIRTHMAP);

        // 设置出生点坐标
//	Grid[][] grids = ManagerPool.mapManager.getMapBlocks(player.getMapModelId());
//	Integer[] gridpos = birth.get(RandomUtils.random(birth.size()));
//	log.error(player, "birth.size=" + birth.size() + ",posx=" + gridpos[0] + ",posy=" + gridpos[1]);
//	Grid grid = MapUtils.getGrid(gridpos[0], gridpos[1], grids);
//	player.setPosition(grid.getCenter());
        {
            // TODO 临时坐标点
            Position tmpPosition = new Position((short) 0, (short) 0);
            player.setPosition(tmpPosition);
        }

        // 设置回城坐标点
        player.setBackCityMapId(player.getMapModelId());
        player.setBackCityX(player.getPosition().getX());
        player.setBackCityY(player.getPosition().getY());

        player.setSex(sex);
        player.setJob(job);
        player.setLevel(1);
        player.setIcon(String.valueOf(icon));
        player.setName(name);
        player.setMoney(0);
        player.setAutoArgeeAddGuild((byte) 1);// 创建玩家角色后默认自动加入帮会
        player.setCountry(0); // 后期设置国家,阵营
        player.setBagCellsNum(Global.DEFAULT_BAG_CELLS);
        player.setStoreCellsNum(Global.DEFAULT_STORE_CELLS);
        player.setBagCellTimeCount(0);
        player.setStoreCellTimeCount(0);
        player.setLevel(1);

        List<IBaseScript> evts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(ICreatePlayerEndScript.class.getName());
        for (IBaseScript script : evts) {
            try {
                // 初始化VIP,SKILL,公测活动信息,任务
                ((ICreatePlayerEndScript) script).action(player);
            } catch (Exception ex) {
                log.error("执行" + script.getName() + "脚本异常", ex);
            }
        }
        return player;
    }

    public void insertPlayer(Player player) throws Exception {
        Role role = new Role();
        role.setUserid(player.getUserid());
        role.setUsername(player.getUsername());
        role.setServerid(player.getServerid());
        role.setServername(player.getServername());
        role.setServerweb(player.getServerweb());
        role.setLoginIP(player.getLoginIP());
        role.setPid(player.getId());
        role.setName(player.getName());

        role.setLevel(player.getLevel());
        role.setSex(player.getSex());
        role.setJob(player.getJob());
        role.setVersion(player.getVersion());
        role.setDeleted(player.isDeleted());
        role.setForbided(player.isForbided());
        role.setCountry(player.getCountry());
        role.setWidth(player.getWidth());
        role.setHeight(player.getHeight());
        role.setMoney(player.getMoney());
	//role.setBindGold(player.getBindGold());
        //role.setBagCellsNum(player.getBagCellsNum());
        //role.setStoreCellsNum(player.getStoreCellsNum());
        role.setProhibitChatEndTime(player.getProhibitChatEndTime());
	//role.setStartProhibitChatTime(player.getStartProhibitChatTime());
        //role.setAddBlackTime(player.getAddBlackTime());
        //role.setAddBlackCount(player.getAddBlackCount());
        //role.setExp(player.getExp());
        role.setOnlineTime(player.getOnlinetime());
        role.setMapid(player.getMapId());
        role.setMapModelId(player.getMapModelId());
	//role.setX(player.getPosition().getX());
        //role.setY(player.getPosition().getY());
        //role.setHp(player.getHp());
        //role.setMp(player.getMp());
        role.setAgentPlusdata(player.getAgentPlusdata());
        role.setAgentColdatas(player.getAgentColdatas());
	//role.setLogin_agent(player.getLogin_agent());
        //role.setLogin_agent_ad(player.getLogin_agent_ad());
        //role.setLogin_agent_regtime(player.getLogin_agent_regtime());
        //role.setLogin_hfagent(player.getLogin_hfagent());
        role.setLogintime(System.currentTimeMillis());

        String toJSONStringWriteClassName = JsonUtil.toJSONStringWriteClassName(player);
        Player parseObject = JsonUtil.parseObject(toJSONStringWriteClassName, Player.class);
        
        role.setPlayer(player);

        DataManager.getInstance().getRoleDao().create(role);
    }

    // 玩家名字
    private final HashSet<String> names = new HashSet<>();

    /**
     * 加载所有名字
     */
    public void loadNames() {
        try {
            List<String> namelist = DataManager.getInstance().getRoleDao().selectNames();
            Iterator<String> iter = namelist.iterator();
            synchronized (names) {
                while (iter.hasNext()) {
                    String name = (String) iter.next();
                    names.add(name);
                }
            }
        } catch (Exception e) {
            log.error("加载全服玩家名字失败!", e);
        }
    }
    
    public int checkNameAll(String name, boolean addToCache) {
        if (name == null || name.length() < 2 || name.length() > 6) {
            // 重名提示
            log.debug("玩家名字非法长度：" + name);
            return 3;
        }

        if (name.startsWith("#") || WordFilter.getInstance().hashNoLimitedWords(name)) { // 处理时间过长!
            // 非法提示
            log.debug("玩家名字非法字符：" + name);
            return 4;
        }

        if (WordFilter.getInstance().hashBadWords(name)) {
            // 非法提示
            log.debug("玩家名字非法字符：" + name);
            return 4;
        }

        log.info("重名检测" + name);
        name = "[" + Main.getServerID() + "区]" + name;
        boolean repeat = PlayerManager.getInstance().checkName(name, addToCache);
        if (repeat) {
            // 重名提示
            log.debug("玩家名字重名：" + name);
            return 7;
        }
        return 0;
    }

    /**
     * 检查名称是否正确
     *
     * @param name
     * @param addToCache
     * @return
     */
    public boolean checkName(String name, boolean addToCache) {
        synchronized (names) {
            if (names.contains(name)) {
                return true;
            }
            if (addToCache) {
                names.add(name);
            }
            return false;
        }
    }

    /**
     * 名字检查重复
     *
     * @param name 名字
     * @return true 重名 false 不
     */
    public boolean removeName(String name) {
        synchronized (names) {
            return names.remove(name);
        }
    }

    /**
     * 注册玩家(到缓冲区)
     * @param player
     */
    public void registerPlayer(Player player) {
        if (player.getObjDelAndSaveTime() == null) {
            player.setObjDelAndSaveTime(new AtomicLong(0));
        }
        if (player.getObjDelAndSaveTime().get() == 0) {
            players.put(player.getId(), player);
        }
    }
    
    /**
     * 缓冲区中获得玩家数据
     * @param playerid
     * @return 
     */
    public Player getPlayerFromRegister(long playerid) {
        return players.get(playerid);
    }
    
    /**
     * 构建角色基础信息.用于角色列表显示
     * @param player
     * @return 
     */
    public LoginMessage.PlayerBase buildPlayerBase(Player player) {
        LoginMessage.PlayerBase.Builder playerBaseBuilder = LoginMessage.PlayerBase.newBuilder();
        playerBaseBuilder.setUserid(player.getUserid());
        // 所属用户名称
        playerBaseBuilder.setUsername(player.getUsername());
        // 创建的服务器ID
        playerBaseBuilder.setServerid(player.getServerid());
        // 服务器名称
        playerBaseBuilder.setServername(player.getServername());
        // 渠道名称
        playerBaseBuilder.setServerweb(player.getServerweb());
        // 平台参数1
        if (player.getAgentPlusdata()!= null && player.getAgentPlusdata().length() > 0) playerBaseBuilder.setAgentPlusdata(player.getAgentPlusdata());
        // 平台参数2
        if (player.getAgentColdatas()!= null && player.getAgentColdatas().length() > 0) playerBaseBuilder.setAgentColdatas(player.getAgentColdatas());
        //角色状体
        playerBaseBuilder.setState(player.getState().getValue());
        //唯一标识
        playerBaseBuilder.setId(player.getId());
        //名字
        playerBaseBuilder.setName(player.getName());
        //原来名称
        if (player.getName2() != null && player.getName2().length() > 0) playerBaseBuilder.setName2(player.getName2());
        //头像
        playerBaseBuilder.setIcon(Integer.parseInt(player.getIcon())); // 使用int
        //职业
        playerBaseBuilder.setJob(player.getJob());
        //性别1男2女
        playerBaseBuilder.setSex(player.getSex());
        //国家/阵营
        if (player.getCountry() != 0) playerBaseBuilder.setCountry(player.getCountry());
        //等级
        playerBaseBuilder.setLevel(player.getLevel());
        //地图
        playerBaseBuilder.setMapId(player.getMapId());
        //地图模板id
        playerBaseBuilder.setMapModelId(player.getMapModelId());
        // 0 正常 1 可以删除>1 倒计时秒
        if (player.getDeleteAt() != 0) playerBaseBuilder.setDeleteAt(player.getDeleteAt());
        //星座
        playerBaseBuilder.setConstellation(player.getConstellation());
        // gm状态
        if (player.getGmState() != 0) playerBaseBuilder.setGmState(player.getGmState());
        // VIP等级ID(0-10,0为不是vip)
        if (player.getVip() != 0) playerBaseBuilder.setVip(player.getVip());
        // 平台vip
        if (player.getWebvip() != 0) playerBaseBuilder.setWebvip(player.getWebvip());
        // 内部vip
        if (player.getInnervip() != 0) playerBaseBuilder.setInnervip(player.getInnervip());
        // 装备
        // TODO repeated Equipment equips();
        return playerBaseBuilder.build();
    }

    public void savePlayer(Player player, boolean boNeedSave) {
        if (boNeedSave || System.currentTimeMillis() > player.getLastSaveTime()) {
	    long nexttime = (online.size() / 200);
	    if (nexttime > 5) {
		nexttime = 5;
	    }
	    nexttime = (nexttime * 60 * 1000) + (10 * 60 * 1000) + RandomUtils.random(5 * 60 * 1000);
	    player.setLastSaveTime(System.currentTimeMillis() + nexttime);
	    player.setVersion(Main.getVersion());
            
	    if (player.getObjDelAndSaveTime().get() == 0) {
		players.put(player.getId(), player);
	    }
	}
    }

    public Map<Long, Player> getOnline() {
        return online;
    }
    

}
