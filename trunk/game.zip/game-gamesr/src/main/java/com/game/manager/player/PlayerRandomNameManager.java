package com.game.manager.player;

import com.game.utils.RandomUtils;
import com.game.manager.data.DataManager;
import com.game.po.data.RoleRandomName;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class PlayerRandomNameManager {

    private static final PlayerRandomNameManager instance = new PlayerRandomNameManager();

    public static PlayerRandomNameManager getInstance() {
        return instance;
    }
    
    private PlayerRandomNameManager() {
    }

    /**
     * 随机角色名称
     * @param isMale
     * @return 
     */
    public String randomRoleName(boolean isMale) {
        List<RoleRandomName> list = DataManager.getInstance().getRoleRandomNameList();
        List<String> firstName = new ArrayList<>();
        List<String> lastName = new ArrayList<>();
        for (RoleRandomName roleRandomName : list) {
            if (roleRandomName.getType() == 1) {
                firstName.add(roleRandomName.getValue());
            } else if (roleRandomName.getType() == 2 && isMale) {
                lastName.add(roleRandomName.getValue());
            } else if (roleRandomName.getType() == 3 && !isMale) {
                lastName.add(roleRandomName.getValue());
            }
        }
        int firstindex = RandomUtils.random(firstName.size());
        int lastindex = RandomUtils.random(lastName.size());
        return firstName.get(firstindex) + lastName.get(lastindex);
    }
}
