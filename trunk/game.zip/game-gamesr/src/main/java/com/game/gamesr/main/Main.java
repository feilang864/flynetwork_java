package com.game.gamesr.main;


import com.game.engine.io.conf.MinaClientConfig;
import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.gamesr.server.GameServer;
import java.io.File;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class Main {
    
    private static final Logger log = LoggerFactory.getLogger(Main.class);
    private static GameServer gameServer;

    public static GameServer getGameServer() {
        return gameServer;
    }
    
    public static int getServerID() {
        return gameServer.getGameTcpServer().getId();
    }
    
    public static String getServerWeb() {
        return gameServer.getGameTcpServer().getWeb();
    }
    
    public static String getServerName() {
        return gameServer.getGameTcpServer().getName();
    }
    
    public static String getVersion() {
        return gameServer.getGameTcpServer().getVersion();
    }
    
    public static void main(String[] args) {
        String tmp = "D:\\game\\game-gamesr\\target\\classes";
        
        Serializer serializer = new Persister();

        ThreadPoolExecutorConfig defaultThreadExcutorConfig4TcpServer = null;
        ThreadPoolExecutorConfig mapServerThreadPoolExecutorConfig4TcpServer = null;
        MinaServerConfig minaServerConfig4TcpServer = null;

        {

            String defaultThreadExcutorConfigPath4TcpServer = "GameTcpServer\\defaultThreadPoolExecutorConfig.xml";
            String mapServerThreadPoolExecutorConfigPath4TcpServer = "GameTcpServer\\mapServerThreadPoolExecutorConfig.xml";
            String minaServerConfigPath4TcpServer = "GameTcpServer\\minaServerConfig.xml";

            if (!new File(defaultThreadExcutorConfigPath4TcpServer).exists()) {
                defaultThreadExcutorConfigPath4TcpServer = tmp + "\\" + defaultThreadExcutorConfigPath4TcpServer;
                if (!new File(defaultThreadExcutorConfigPath4TcpServer).exists()) {
                    log.error("无法找到文件" + defaultThreadExcutorConfigPath4TcpServer);
                    System.exit(1);
                }
                try {
                    defaultThreadExcutorConfig4TcpServer = serializer.read(ThreadPoolExecutorConfig.class, new File(defaultThreadExcutorConfigPath4TcpServer));
                } catch (Exception ex) {
                    log.error("文件" + defaultThreadExcutorConfigPath4TcpServer + "配置有误", ex);
                    System.exit(1);
                }
            }
            
            if (!new File(mapServerThreadPoolExecutorConfigPath4TcpServer).exists()) {
                mapServerThreadPoolExecutorConfigPath4TcpServer = tmp + "\\" + mapServerThreadPoolExecutorConfigPath4TcpServer;
                if (!new File(mapServerThreadPoolExecutorConfigPath4TcpServer).exists()) {
                    log.error("无法找到文件" + mapServerThreadPoolExecutorConfigPath4TcpServer);
                    System.exit(1);
                }
                try {
                    mapServerThreadPoolExecutorConfig4TcpServer = serializer.read(ThreadPoolExecutorConfig.class, new File(mapServerThreadPoolExecutorConfigPath4TcpServer));
                } catch (Exception ex) {
                    log.error("文件" + mapServerThreadPoolExecutorConfigPath4TcpServer + "配置有误", ex);
                    System.exit(1);
                }
            }

            if (!new File(minaServerConfigPath4TcpServer).exists()) {
                minaServerConfigPath4TcpServer = tmp + "\\" + minaServerConfigPath4TcpServer;
                if (!new File(minaServerConfigPath4TcpServer).exists()) {
                    log.error("无法找到文件" + minaServerConfigPath4TcpServer);
                    System.exit(1);
                }
                try {
                    minaServerConfig4TcpServer = serializer.read(MinaServerConfig.class, new File(minaServerConfigPath4TcpServer));
                } catch (Exception ex) {
                    log.error("文件" + minaServerConfigPath4TcpServer + "配置有误", ex);
                    System.exit(1);
                }
            }
        }

        ThreadPoolExecutorConfig defaultThreadExcutorConfig4TcpClient = null;
        MinaClientConfig minaClientConfig4TcpClient = null;
        {

            String defaultThreadExcutorConfigPath4TcpClient = "GameTcpClient\\defaultThreadPoolExecutorConfig.xml";
            String minaClientConfigPath4TcpClient = "GameTcpClient\\minaClientConfig.xml";

            if (!new File(defaultThreadExcutorConfigPath4TcpClient).exists()) {
                defaultThreadExcutorConfigPath4TcpClient = tmp + "\\" + defaultThreadExcutorConfigPath4TcpClient;
                if (!new File(defaultThreadExcutorConfigPath4TcpClient).exists()) {
                    log.error("无法找到文件" + defaultThreadExcutorConfigPath4TcpClient);
                    System.exit(1);
                }
                try {
                    defaultThreadExcutorConfig4TcpClient = serializer.read(ThreadPoolExecutorConfig.class, new File(defaultThreadExcutorConfigPath4TcpClient));
                } catch (Exception ex) {
                    log.error("文件" + defaultThreadExcutorConfigPath4TcpClient + "配置有误", ex);
                    System.exit(1);
                }
            }

            if (!new File(minaClientConfigPath4TcpClient).exists()) {
                minaClientConfigPath4TcpClient = tmp + "\\" + minaClientConfigPath4TcpClient;
                if (!new File(minaClientConfigPath4TcpClient).exists()) {
                    log.error("无法找到文件" + minaClientConfigPath4TcpClient);
                    System.exit(1);
                }
                try {
                    minaClientConfig4TcpClient = serializer.read(MinaClientConfig.class, new File(minaClientConfigPath4TcpClient));
                } catch (Exception ex) {
                    log.error("文件" + minaClientConfigPath4TcpClient + "配置有误", ex);
                    System.exit(1);
                }
            }
        }
        gameServer = new GameServer(defaultThreadExcutorConfig4TcpServer, mapServerThreadPoolExecutorConfig4TcpServer, minaServerConfig4TcpServer
                , defaultThreadExcutorConfig4TcpClient, minaClientConfig4TcpClient);
        new Thread(gameServer).start();
    }
}
