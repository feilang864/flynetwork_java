package com.game.po.data.controller;

import com.game.po.data.Filterword;
import com.game.po.data.controller.exceptions.NonexistentEntityException;
import com.game.po.data.controller.exceptions.PreexistingEntityException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class FilterwordJpaController implements Serializable {

    public FilterwordJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Filterword filterword) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(filterword);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findFilterword(filterword.getAgents()) != null) {
                throw new PreexistingEntityException("Filterword " + filterword + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Filterword filterword) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            filterword = em.merge(filterword);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = filterword.getAgents();
                if (findFilterword(id) == null) {
                    throw new NonexistentEntityException("The filterword with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Filterword filterword;
            try {
                filterword = em.getReference(Filterword.class, id);
                filterword.getAgents();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The filterword with id " + id + " no longer exists.", enfe);
            }
            em.remove(filterword);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Filterword> findFilterwordEntities() {
        return findFilterwordEntities(true, -1, -1);
    }

    public List<Filterword> findFilterwordEntities(int maxResults, int firstResult) {
        return findFilterwordEntities(false, maxResults, firstResult);
    }

    private List<Filterword> findFilterwordEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Filterword.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Filterword findFilterword(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Filterword.class, id);
        } finally {
            em.close();
        }
    }

    public int getFilterwordCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Filterword> rt = cq.from(Filterword.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
