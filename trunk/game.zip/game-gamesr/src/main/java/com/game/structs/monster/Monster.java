package com.game.structs.monster;

import com.game.structs.Position;
import com.game.structs.map.IMapObject;
import com.game.structs.player.Person;
import com.game.structs.player.Player;
import com.game.structs.skill.Skill;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Monster extends Person implements IMapObject {

    private Logger log = LoggerFactory.getLogger(Monster.class);

    public Monster() {
        super();
        this.personType = Person.PERSON_MONSTER;
    }
    private static final long serialVersionUID = -2328772357502414458L;
    //分布Id
    private int distributeId;
    //分布方式 1-定点分布 2-区域分布
    private int distributeType;
    //死亡次数
    private int dieCount = 0;
    //出生点
    private Position birthPos;
    //复活剩余时间
    private int revive;
    //仇恨列表
    private List<Hatred> hatreds = new ArrayList<>();
    //伤害列表
    private HashMap<Long, Integer> damages = new HashMap<>();
    //伤害排行列表
    private HashMap<Long, MonsterDamage> bossdamage = new HashMap<>();
    //怪物状态
    private int state;
    //怪物使用技能
    protected Skill defaultSkill = new Skill();
    //怪物使用技能
    protected Skill useSkill = new Skill();
    //怪物类型
    private int monsterType;
    //怪物变身状态
    private HashMap<Integer, Morph> morph = new HashMap<>();
    //攻击目标
    private Person target;
    //最后一次被攻击时间（boss用）
    private long lastAttackTime;
    //死亡时间
    private long dieTime;
    //血量比率
    private int hppercentage;
    //下一个技能
    private String nextskillid;
    private Person killer;
    //归属权
    private Person owner;
    //归属权是否固定
    private boolean unAlterable;
    private long ownerGuild;
    private String killername;
    private long belongToMonsterId;//从属于主怪id
    //归属权时间
    private long ownerTime;
    protected Person attackTarget;
    protected Person defaultAttackTarget;
    //临时参数列表
    private HashMap<String, Object> parameters = new HashMap<>();
    //是否显示
    private boolean show = true;
    //显示set
    private HashSet<Long> showSet = new HashSet<>();
    //隐藏set
    private HashSet<Long> hideSet = new HashSet<>();
    //技能信息
    private List<Skill> skills = new ArrayList<>();
    //字符串value
    private String strvalue;
    //友好状态
    private int friend;
    //友好参数
    private String friendPara;
    //巡逻路径
    private List<Position> xunluo = new ArrayList<>();
    //消失时间
    private long disappearTime;
    //宠物模板ID(从宠物变为怪物时的模板ID)
    private int petModelId;
    //宠物等级(从宠物变为怪物时的等级)
    private int petLv;
    //召唤为宠物的技能等级
    private int petskilllv;
    //上次回血时间
    private long lastRecoveryTime;
    //怪物AI
    private HashMap<String, MonsterAi> ailist = new HashMap<>();
    //怪物当前在使用的技能
    private List<MonsterAi> curuselist = new ArrayList<>();
    private HashMap<Long, String> killernameList = new HashMap<>();
    //Boss的点名目标
    private Player sayAttacker = null;
    private Position sayPos = null;
    //怪物上一次攻击人的时间
    private long lastAttackPlayerTime;
    //怪物身上的杂乱信息
    private HashMap<String, Object> variables = new HashMap<>();
    //是否有修改过刷新时间
    private int isChangReviveTime = 0;
    private String changReviveTime = "";
    private int checkMin = -1;
    //boss的刷新时间
    private int bossReviveTime = 0;

    public Logger getLog() {
        return log;
    }

    public void setLog(Logger log) {
        this.log = log;
    }

    public int getDistributeId() {
        return distributeId;
    }

    public void setDistributeId(int distributeId) {
        this.distributeId = distributeId;
    }

    public int getDistributeType() {
        return distributeType;
    }

    public void setDistributeType(int distributeType) {
        this.distributeType = distributeType;
    }

    public int getDieCount() {
        return dieCount;
    }

    public void setDieCount(int dieCount) {
        this.dieCount = dieCount;
    }

    public Position getBirthPos() {
        return birthPos;
    }

    public void setBirthPos(Position birthPos) {
        this.birthPos = birthPos;
    }

    public int getRevive() {
        return revive;
    }

    public void setRevive(int revive) {
        this.revive = revive;
    }

    public List<Hatred> getHatreds() {
        return hatreds;
    }

    public void setHatreds(List<Hatred> hatreds) {
        this.hatreds = hatreds;
    }

    public HashMap<Long, Integer> getDamages() {
        return damages;
    }

    public void setDamages(HashMap<Long, Integer> damages) {
        this.damages = damages;
    }

    public HashMap<Long, MonsterDamage> getBossdamage() {
        return bossdamage;
    }

    public void setBossdamage(HashMap<Long, MonsterDamage> bossdamage) {
        this.bossdamage = bossdamage;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public Skill getDefaultSkill() {
        return defaultSkill;
    }

    public void setDefaultSkill(Skill defaultSkill) {
        this.defaultSkill = defaultSkill;
    }

    public Skill getUseSkill() {
        return useSkill;
    }

    public void setUseSkill(Skill useSkill) {
        this.useSkill = useSkill;
    }

    public int getMonsterType() {
        return monsterType;
    }

    public void setMonsterType(int monsterType) {
        this.monsterType = monsterType;
    }

    public HashMap<Integer, Morph> getMorph() {
        return morph;
    }

    public void setMorph(HashMap<Integer, Morph> morph) {
        this.morph = morph;
    }

    public Person getTarget() {
        return target;
    }

    public void setTarget(Person target) {
        this.target = target;
    }

    public long getLastAttackTime() {
        return lastAttackTime;
    }

    public void setLastAttackTime(long lastAttackTime) {
        this.lastAttackTime = lastAttackTime;
    }

    public long getDieTime() {
        return dieTime;
    }

    public void setDieTime(long dieTime) {
        this.dieTime = dieTime;
    }

    public int getHppercentage() {
        return hppercentage;
    }

    public void setHppercentage(int hppercentage) {
        this.hppercentage = hppercentage;
    }

    public String getNextskillid() {
        return nextskillid;
    }

    public void setNextskillid(String nextskillid) {
        this.nextskillid = nextskillid;
    }

    public Person getKiller() {
        return killer;
    }

    public void setKiller(Person killer) {
        this.killer = killer;
    }

    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }

    public boolean isUnAlterable() {
        return unAlterable;
    }

    public void setUnAlterable(boolean unAlterable) {
        this.unAlterable = unAlterable;
    }

    public long getOwnerGuild() {
        return ownerGuild;
    }

    public void setOwnerGuild(long ownerGuild) {
        this.ownerGuild = ownerGuild;
    }

    public String getKillername() {
        return killername;
    }

    public void setKillername(String killername) {
        this.killername = killername;
    }

    public long getBelongToMonsterId() {
        return belongToMonsterId;
    }

    public void setBelongToMonsterId(long belongToMonsterId) {
        this.belongToMonsterId = belongToMonsterId;
    }

    public long getOwnerTime() {
        return ownerTime;
    }

    public void setOwnerTime(long ownerTime) {
        this.ownerTime = ownerTime;
    }

    public Person getAttackTarget() {
        return attackTarget;
    }

    public void setAttackTarget(Person attackTarget) {
        this.attackTarget = attackTarget;
    }

    public Person getDefaultAttackTarget() {
        return defaultAttackTarget;
    }

    public void setDefaultAttackTarget(Person defaultAttackTarget) {
        this.defaultAttackTarget = defaultAttackTarget;
    }

    public HashMap<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(HashMap<String, Object> parameters) {
        this.parameters = parameters;
    }

    public boolean isShow() {
        return show;
    }

    public void setShow(boolean show) {
        this.show = show;
    }

    public HashSet<Long> getShowSet() {
        return showSet;
    }

    public void setShowSet(HashSet<Long> showSet) {
        this.showSet = showSet;
    }

    public HashSet<Long> getHideSet() {
        return hideSet;
    }

    public void setHideSet(HashSet<Long> hideSet) {
        this.hideSet = hideSet;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    public String getStrvalue() {
        return strvalue;
    }

    public void setStrvalue(String strvalue) {
        this.strvalue = strvalue;
    }

    public int getFriend() {
        return friend;
    }

    public void setFriend(int friend) {
        this.friend = friend;
    }

    public String getFriendPara() {
        return friendPara;
    }

    public void setFriendPara(String friendPara) {
        this.friendPara = friendPara;
    }

    public List<Position> getXunluo() {
        return xunluo;
    }

    public void setXunluo(List<Position> xunluo) {
        this.xunluo = xunluo;
    }

    public long getDisappearTime() {
        return disappearTime;
    }

    public void setDisappearTime(long disappearTime) {
        this.disappearTime = disappearTime;
    }

    public int getPetModelId() {
        return petModelId;
    }

    public void setPetModelId(int petModelId) {
        this.petModelId = petModelId;
    }

    public int getPetLv() {
        return petLv;
    }

    public void setPetLv(int petLv) {
        this.petLv = petLv;
    }

    public int getPetskilllv() {
        return petskilllv;
    }

    public void setPetskilllv(int petskilllv) {
        this.petskilllv = petskilllv;
    }

    public long getLastRecoveryTime() {
        return lastRecoveryTime;
    }

    public void setLastRecoveryTime(long lastRecoveryTime) {
        this.lastRecoveryTime = lastRecoveryTime;
    }

    public HashMap<String, MonsterAi> getAilist() {
        return ailist;
    }

    public void setAilist(HashMap<String, MonsterAi> ailist) {
        this.ailist = ailist;
    }

    public List<MonsterAi> getCuruselist() {
        return curuselist;
    }

    public void setCuruselist(List<MonsterAi> curuselist) {
        this.curuselist = curuselist;
    }

    public HashMap<Long, String> getKillernameList() {
        return killernameList;
    }

    public void setKillernameList(HashMap<Long, String> killernameList) {
        this.killernameList = killernameList;
    }

    public Player getSayAttacker() {
        return sayAttacker;
    }

    public void setSayAttacker(Player sayAttacker) {
        this.sayAttacker = sayAttacker;
    }

    public Position getSayPos() {
        return sayPos;
    }

    public void setSayPos(Position sayPos) {
        this.sayPos = sayPos;
    }

    public long getLastAttackPlayerTime() {
        return lastAttackPlayerTime;
    }

    public void setLastAttackPlayerTime(long lastAttackPlayerTime) {
        this.lastAttackPlayerTime = lastAttackPlayerTime;
    }

    public HashMap<String, Object> getVariables() {
        return variables;
    }

    public void setVariables(HashMap<String, Object> variables) {
        this.variables = variables;
    }

    public int getIsChangReviveTime() {
        return isChangReviveTime;
    }

    public void setIsChangReviveTime(int isChangReviveTime) {
        this.isChangReviveTime = isChangReviveTime;
    }

    public String getChangReviveTime() {
        return changReviveTime;
    }

    public void setChangReviveTime(String changReviveTime) {
        this.changReviveTime = changReviveTime;
    }

    public int getCheckMin() {
        return checkMin;
    }

    public void setCheckMin(int checkMin) {
        this.checkMin = checkMin;
    }

    public int getBossReviveTime() {
        return bossReviveTime;
    }

    public void setBossReviveTime(int bossReviveTime) {
        this.bossReviveTime = bossReviveTime;
    }

}
