package com.game.scripts.task;

import com.game.structs.task.TaskParameters;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Troy.Chen
 */
public interface IFinshTask {

    /**
     * 完成任务
     *
     * @param taskParameters
     * @return 返回成功，失败 失败查询 TaskParameters.ErrorString
     */
    boolean finshTask(TaskParameters taskParameters);
}
