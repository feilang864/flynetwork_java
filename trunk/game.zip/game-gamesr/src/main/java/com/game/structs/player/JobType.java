package com.game.structs.player;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public enum JobType {

    /**
     * 没有职业
     */
    NO_JOB(0),
    
    /**
     * 战士
     */
    WARR_JOB(1),
    
    /**
     * 法师
     */
    MAGE_JOB(2),
    
    /**
     * 猎人
     */
    HUNT_JOB(3);
    
    private final int job;

    JobType(int job) {
        this.job = job;
    }

    public int getJob() {
        return job;
    }

    
}
