package com.game.gamesr.structs;

/**
 * 坐标
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Position {

    private short x;

    private short y;

    public Position() {
    }

    public Position(short x, short y) {
        this.x = x;
        this.y = y;
    }

    public short getX() {
        return x;
    }

    public void setX(short x) {
        this.x = x;
    }

    public short getY() {
        return y;
    }

    public void setY(short y) {
        this.y = y;
    }

    public boolean equal(Position pos) {
        return this.x == pos.getX() && this.y == pos.getY();
    }

    @Override
    public String toString() {
        return "[x:" + x + ",y:" + y + "]";
    }
}
