package com.game.gamesr.server.tcp;

import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.io.message.MessagePool;
import com.game.engine.io.mina.Service;
import com.game.engine.io.mina.handler.ServerProtocolHandler;
import com.game.engine.io.mina.impl.MinaServer;
import com.game.engine.io.mina.utils.SessionUtil;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.proto.LoginMessage;
import com.game.proto.TestMessage;
import com.game.proto.handler.login.ReqCheckNameHandler;
import com.game.proto.handler.login.ReqCreateCharacterHandler;
import com.game.proto.handler.login.ReqLoadFinishHandler;
import com.game.proto.handler.login.ReqSelectPlayerHandler;
import com.game.proto.handler.login.ReqTokenLoginHandler;
import com.game.proto.handler.test.ReqTestHandler;
import com.google.protobuf.Message;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class GameTcpServer extends Service<MessagePool, MinaServerConfig> {

    private static final Logger log = LoggerFactory.getLogger(GameTcpServer.class);

    private final MinaServer minaServer;

    private final MinaServerConfig minaServerConfig;

    /**
     * 临时客户端链接信息
     */
    public static final class TmpClientInfo {

        private final String ip;
        private final IoSession session;
        private final long ctime;

        public TmpClientInfo(String ip, IoSession session) {
            this.ip = ip;
            this.session = session;
            this.ctime = System.currentTimeMillis();
        }

        public String getIp() {
            return ip;
        }

        public IoSession getSession() {
            return session;
        }

        public long getCtime() {
            return ctime;
        }

    }

    public static final class TmpClientTokenInfo {

        private final String token;
        private final IoSession session;
        private final long ctime;

        public TmpClientTokenInfo(String token, IoSession session) {
            this.token = token;
            this.session = session;
            this.ctime = System.currentTimeMillis();
        }

        public String getToken() {
            return token;
        }

        public IoSession getSession() {
            return session;
        }

        public long getCtime() {
            return ctime;
        }

    }

    // 保存临时客户端信息
    private final Map<String /*IP*/, TmpClientInfo> tmpClientSessions = new ConcurrentHashMap<>();

    // 保存临时的Token与客户端信息
    private final Map<String /*token*/, TmpClientTokenInfo> tmpClientTokenSessions = new ConcurrentHashMap<>();

    public Map<String, TmpClientInfo> getTmpClientSessions() {
        return tmpClientSessions;
    }

    public void putTmpClient(String ip, IoSession session) {
        tmpClientSessions.put(ip, new TmpClientInfo(ip, session));
    }

    public TmpClientInfo removeTmpClient(String ip) {
        return tmpClientSessions.remove(ip);
    }

    public Map<String, TmpClientTokenInfo> getTmpClientTokenSessions() {
        return tmpClientTokenSessions;
    }

    public void putTmpClientToken(String token, IoSession session) {
        tmpClientTokenSessions.put(token, new TmpClientTokenInfo(token, session));
    }

    public TmpClientTokenInfo removeTmpClientToken(String token) {
        return tmpClientTokenSessions.remove(token);
    }

    public GameTcpServer(ThreadPoolExecutorConfig defaultThreadExcutorConfig, ThreadPoolExecutorConfig mapServerThreadExcutorConfig, MinaServerConfig minaServerConfig) {
        super(new MessagePool(), defaultThreadExcutorConfig, mapServerThreadExcutorConfig);
        this.minaServerConfig = minaServerConfig;

        minaServer = new MinaServer(minaServerConfig, new GameTcpServerHandler(messagePool));
    }

    @Override
    protected void initProtos() {
        // TODO 
        // 请求Token登录
        messagePool.register(
                200201,                                                         // id 协议ID
                LoginMessage.ReqTokenLoginMessage.class,                        // messageClass 协议请求消息类型
                ReqTokenLoginHandler.class,                                     // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.ReqTokenLoginMessage.newBuilder(),                 // builder 协议请求消息构造器
                0                                                               // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        
        // 请求选择角色
        messagePool.register(
                100204,                                                         // id 协议ID
                LoginMessage.ReqSelectPlayerMessage.class,                      // messageClass 协议请求消息类型
                ReqSelectPlayerHandler.class,                                   // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.ReqSelectPlayerMessage.newBuilder(),               // builder 协议请求消息构造器
                0                                                               // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        
        // 请求创建角色
        messagePool.register(
                100205,                                                         // id 协议ID
                LoginMessage.ReqCheckNameMessage.class,                         // messageClass 协议请求消息类型
                ReqCheckNameHandler.class,                                      // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.ReqCheckNameMessage.newBuilder(),                  // builder 协议请求消息构造器
                0                                                               // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        
        // 请求创建角色
        messagePool.register(
                100206,                                                         // id 协议ID
                LoginMessage.ReqCreateCharacterMessage.class,                   // messageClass 协议请求消息类型
                ReqCreateCharacterHandler.class,                                // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.ReqCreateCharacterMessage.newBuilder(),            // builder 协议请求消息构造器
                0                                                               // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        
        // 请求进入场景
        messagePool.register(
                100207,                                                         // id 协议ID
                LoginMessage.ReqLoadFinishMessage.class,                         // messageClass 协议请求消息类型
                ReqLoadFinishHandler.class,                                      // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.ReqLoadFinishMessage.newBuilder(),                  // builder 协议请求消息构造器
                0                                                               // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        
        // 请求进入场景
        messagePool.register(
                TestMessage.Protos_Test.ReqTest_VALUE,                                                         // id 协议ID
                TestMessage.ReqTestMessage.class,                         // messageClass 协议请求消息类型
                ReqTestHandler.class,                                      // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                TestMessage.ReqTestMessage.newBuilder(),                  // builder 协议请求消息构造器
                0                                                               // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
    }

    @Override
    protected void initMapServers() {
        // TODO 
    }

    @Override
    protected void running() {
        log.debug(" run ... ");
        minaServer.run();
    }

    @Override
    protected void onShutdown() {
        log.debug(" stop ... ");
        minaServer.stop();
    }

    @Override
    public String toString() {
        return minaServerConfig.getName();
    }

    public String getName() {
        return minaServerConfig.getName();
    }

    public int getId() {
        return minaServerConfig.getId();
    }

    public String getWeb() {
        return minaServerConfig.getWeb();
    }
    
    public String getVersion() {
        return minaServerConfig.getVersion();
    }

    public MinaServerConfig getMinaServerConfig() {
        return minaServerConfig;
    }

    class GameTcpServerHandler extends ServerProtocolHandler {

        private final Logger log = LoggerFactory.getLogger(GameTcpServerHandler.class);

        private final MessagePool messagePool;

        @Override
        public void sessionOpened(IoSession session) {
            super.sessionOpened(session);
            String ip = SessionUtil.getIp(session);
            if (ip == null) {
                log.error("新建立的链接,居然无法获得IP!!!" + session);
                return;
            }
            TmpClientInfo oldTmpClientInfo = tmpClientSessions.get(ip);
            if (oldTmpClientInfo != null && oldTmpClientInfo.getSession() != null && oldTmpClientInfo.getSession().isConnected()) {
                SessionUtil.close(session, "链接已经存在");
                return;
            }
            putTmpClient(ip, session); // 添加到临时客户端
        }

        public GameTcpServerHandler(MessagePool messagePool) {
            this.messagePool = messagePool;
        }

        @Override
        protected void doTranspond(IoSession ioSession, Message message) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        protected MessagePool getMessagePool() {
            return messagePool;
        }

    }
}
