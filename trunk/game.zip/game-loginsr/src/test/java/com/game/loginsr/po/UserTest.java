/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.game.loginsr.po;

import com.game.engine.utils.Config;
import com.game.loginsr.po.controller.UserJpaController;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Vicky
 */
public class UserTest {
    
    private EntityManagerFactory emf;
    private EntityManager em;
    
    public UserTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("pu");
        em = emf.createEntityManager();
    }
    
    @After
    public void tearDown() {
    }
    
    @Test
    public void createTest() {
        Config.serverID = 10001;
        User u = new User();
        u.setCreatetime(System.currentTimeMillis());
        u.setGameID("1");
        u.setIsForbid(0);
        u.setLastlogintime(System.currentTimeMillis());
        u.setMac64("mac64");
        u.setUsername("jack");
        u.setPassword("123456");
        u.setVersion("1.0");
        u.setPlatform("uc");
        
        em.persist(u);
    }
//    
//    @Test
//    public void updateTest() {
//        User u = em.find(User.class, 1L);
//        User.LoginInfo loginInfo = new User.LoginInfo();
//        loginInfo.setGameID("1");
//        loginInfo.setIp("192.168.1.1");
//        loginInfo.setJob(1);
//        loginInfo.setLoginTime(System.currentTimeMillis());
//        loginInfo.setLv(77);
//        loginInfo.setPlayerName("zhangsan");
//        loginInfo.setRace(1);
//        loginInfo.setSex(1);
//        if (u.getLoginInfos() == null) {
//            User.LoginInfos loginInfos = new User.LoginInfos();
//            u.setLoginInfos(loginInfos);
//        }
//        u.getLoginInfos().addLastLogin(loginInfo);
//        
//        em.merge(u);
//    }
//    
//    @Test
//    public void readTest() {
//        User u = em.find(User.class, 1L);
//        
//        for (User.LoginInfo loginInfo : u.getLoginInfos().getLastLogin5()) {
//            System.out.println(loginInfo);
//        }
//    }
    
    @Test
    public void userJpaControllerTest() {
        UserJpaController userJpaController = new UserJpaController(emf);
        User findUserByUsername = userJpaController.findUserByUsername("jack");
        System.out.println(findUserByUsername);
    }
    
}
