package serverscripts.timer;

import com.game.engine.script.BaseScript;
import com.game.engine.timer.script.IServerMinuteTimerEventScript;
import com.game.loginsr.manager.TokenManager;
import com.game.loginsr.token.Token;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class UpdateTokenCacheTimerEventScript extends BaseScript implements IServerMinuteTimerEventScript {

    private static final Logger log = LoggerFactory.getLogger(UpdateTokenCacheTimerEventScript.class);
    
    private static final UpdateTokenCacheTimerEventScript instance = new UpdateTokenCacheTimerEventScript();
    
    public static UpdateTokenCacheTimerEventScript getInstance() {
        return instance;
    }
    
    @Override
    public void action(int serverId, String serverWeb) {
        log.error("UpdateTokenCacheTimerEventScript");
        long begin = System.currentTimeMillis();
        long interval = 300000L; // 5分钟超时时间
        
        Map<String, Token> cache4Token = TokenManager.getInstance().getToken4Cache();
        
        Set<String> deletes = new HashSet<>();
        Set<String> keySet = cache4Token.keySet();
        Token token = null;
        for (String key : keySet) {
            token = cache4Token.get(key);
            if (token != null && begin - token.getCreateTime() > interval) {
                deletes.add(key);
            }
        }
        
        for (String key : deletes) {
            TokenManager.getInstance().remoteToken(key);
        }
    }

}
