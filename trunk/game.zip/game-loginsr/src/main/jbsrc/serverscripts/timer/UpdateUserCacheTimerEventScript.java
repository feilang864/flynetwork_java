package serverscripts.timer;

import com.game.engine.script.BaseScript;
import com.game.engine.timer.script.IServerMinuteTimerEventScript;
import com.game.loginsr.data.DataManager;
import com.game.loginsr.manager.UserManager;
import com.game.loginsr.po.User;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class UpdateUserCacheTimerEventScript extends BaseScript implements IServerMinuteTimerEventScript {

    private static final Logger log = LoggerFactory.getLogger(UpdateUserCacheTimerEventScript.class);
    private static final UpdateUserCacheTimerEventScript instance = new UpdateUserCacheTimerEventScript();

    public static UpdateUserCacheTimerEventScript getInstance() {
        return instance;
    }

    @Override
    public void action(int serverId, String serverWeb) {
        log.error("UpdateServerInfoTimerEventScript");
        long begin = System.currentTimeMillis();
        System.out.println("检测cache4User!");

        Map<String, User> cache4User = UserManager.getInstance().getCache4User();

        int size = cache4User.size();
        long interval = 3600000L; // 1小时
        if (size > 10000) { // 缓存清理时间根据具体缓存数量决定
            interval = 300000L; // 5分钟
        } else if (size > 5000) {
            interval = 600000L; // 10分钟
        } else if (size > 2000) {
            interval = 1800000L; // 30分钟
        }

        Set<String> updates = new HashSet<>();
        Set<String> keySet = cache4User.keySet();
        User user = null;
        for (String key : keySet) {
            user = cache4User.get(key);
            if (user != null && begin - user.getLastlogintime() > interval) {
                updates.add(key);
            }
        }

        int needupdate = updates.size();
        int created = 0;
        int updated = 0;
        for (String key : updates) {
            user = cache4User.get(key);
            if (user != null) {
                try {
                    if (user.getId() == 0) {
                        DataManager.getInstance().getUserJpaController().create(user);
                        created++;
                    } else {
                        DataManager.getInstance().getUserJpaController().edit(user);
                        updated++;
                    }
                    cache4User.remove(key);
                } catch (Exception ex) {
                    log.error("处理cache4User异常!!!", ex);
                }
            }
        }

        long cost = System.currentTimeMillis() - begin;
        log.error(String.format("处理cache4User:%d条 需要update:%d条,实际update:%d条,写入:%d条. 耗时%dms", size, needupdate, updated, created, cost));
        if (cost > 60000) {
            log.error("处理cache4User耗时超过1分钟!!!" + cost + "ms");
        }

    }

}
