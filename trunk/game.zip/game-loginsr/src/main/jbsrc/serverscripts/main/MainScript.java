package serverscripts.main;

import com.game.engine.script.BaseScript;
import com.game.engine.script.BaseScriptEntry;
import com.game.engine.script.ScriptUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import serverscripts.timer.UpdateTokenCacheTimerEventScript;
import serverscripts.timer.UpdateUserCacheTimerEventScript;

/**
 *
 * @author Administrator
 */
public class MainScript extends BaseScript { 

    private static final Logger log = LoggerFactory.getLogger(MainScript.class);

    private static MainScript instance;
    private static long uck_loadtime;

    public static long getUck_loadtime() {
        return uck_loadtime;
    }

    public MainScript() {
        instance = this;
    }

    public static MainScript getInstance() {
        return instance;
    }

    @Override
    public boolean init(int initstate, BaseScriptEntry entry) {
        log.error("MainScript  " + initstate + "   " + entry);
        ScriptUtil.require(entry, UpdateUserCacheTimerEventScript.getInstance(), initstate);
        ScriptUtil.require(entry, UpdateTokenCacheTimerEventScript.getInstance(), initstate);
        
        return true;
    }

    @Override
    public boolean uninit(int initstate, BaseScriptEntry entry) {
        return true;
    }
}
