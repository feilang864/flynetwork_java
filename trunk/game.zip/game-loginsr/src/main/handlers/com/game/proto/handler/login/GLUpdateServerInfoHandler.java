package com.game.proto.handler.login;

import com.game.engine.io.commmand.TcpHandler;
import com.game.loginsr.main.Main;
import com.game.loginsr.vo.ServerInfo;
import com.game.proto.LoginMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class GLUpdateServerInfoHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(GLUpdateServerInfoHandler.class);

    @Override
    public void run() {
        // TODO 处理LoginMessage.GLUpdateServerInfo消息
        LoginMessage.GLUpdateServerInfoMessage reqMessage = (LoginMessage.GLUpdateServerInfoMessage) getMessage();

        LoginMessage.ServerInfo serverInfoMessage = reqMessage.getServerInfo();
        ServerInfo serverInfo = new ServerInfo();
        serverInfo.setZoneid(serverInfoMessage.getZoneid());
        serverInfo.setZonename(serverInfoMessage.getZonename());
        serverInfo.setName(serverInfoMessage.getName());
        serverInfo.setId(serverInfoMessage.getId());
        serverInfo.setWeb(serverInfoMessage.getWeb());
        serverInfo.setIp(serverInfoMessage.getIp());
        serverInfo.setPort(serverInfoMessage.getPort());
        serverInfo.setState(serverInfoMessage.getState());
        serverInfo.setVersion(serverInfoMessage.getVersion());
        Main.getLoginServer().getLoginTcpServer().updateServerInfo(serverInfo);
    }
}
