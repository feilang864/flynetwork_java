package com.game.proto.handler.registerlogin;

import com.game.engine.io.commmand.TcpHandler;
import com.game.loginsr.server.LoginServer;
import com.game.loginsr.server.tcp.LoginTcpServer;
import com.game.proto.RegisterLoginMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public final class GLRegisterLoginHandler extends TcpHandler {

    private static final Logger log = LoggerFactory.getLogger(GLRegisterLoginHandler.class);

    @Override
    public void run() {
        // TODO 处理RegisterLoginMessage.GLRegisterLogin消息
        RegisterLoginMessage.GLRegisterLoginMessage reqMessage = (RegisterLoginMessage.GLRegisterLoginMessage) getMessage();
        RegisterLoginMessage.LGRegisterLoginMessage.Builder builder4Res = RegisterLoginMessage.LGRegisterLoginMessage.newBuilder();

        LoginTcpServer loginTcpServer = LoginServer.getInstance().getLoginTcpServer();
        int serverId = reqMessage.getServerId();
        getSession().setAttribute(LoginTcpServer.GS_CONN_ID, serverId);
        loginTcpServer.putGameSession(serverId, getSession());
        log.info("游戏服务器" + reqMessage.getServerName() + "注册到" + loginTcpServer.getName() + "成功！");

        builder4Res.setServerId(loginTcpServer.getId());
        builder4Res.setServerName(loginTcpServer.getName());

        RegisterLoginMessage.LGRegisterLoginMessage returnmessage = builder4Res.build();
        getSession().write(returnmessage);
    }
}
