package com.game.loginsr.vo;

/**
 * 服务器信息
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class ServerInfo {

    // 大区
    private int zoneid;
    // 大区名称
    private String zonename;
    // 服务器名称
    private String name;
    // 服务器ID
    private int id;
    // 渠道
    private String web;
    // 地址
    private String ip;
    // 端口
    private int port;
    // 状态
    private int state;
    // 版本号
    private String version;

    public int getZoneid() {
        return zoneid;
    }

    public void setZoneid(int zoneid) {
        this.zoneid = zoneid;
    }

    public String getZonename() {
        return zonename;
    }

    public void setZonename(String zonename) {
        this.zonename = zonename;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
