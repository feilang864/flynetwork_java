package com.game.loginsr.manager;

import com.game.engine.io.mina.code.HttpResponseMessage;
import com.game.engine.io.mina.utils.SessionUtil;
import com.game.loginsr.data.DataManager;
import com.game.loginsr.main.Main;
import com.game.loginsr.po.User;
import com.game.loginsr.token.Token;
import com.game.loginsr.vo.ServerInfo;
import com.game.proto.LoginMessage;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class UserManager {

    private static final Logger log = LoggerFactory.getLogger(UserManager.class);
    
    private final Map<String, User> cache4User = new HashMap<>();

    private static final UserManager instance = new UserManager();

    public static UserManager getInstance() {
        return instance;
    }
    
    public static final String USER_ID = "userId";
    public static final String USER_NAME = "userName";

    private final Object syncObj = new Object();

    public void login(HttpResponseMessage httpResponseMessage, IoSession session, String username, String password, String mac64, String version, String platform) {
        long begin = System.currentTimeMillis();
        
        String ip = SessionUtil.getIp(session);
        // 非局域网环境需要验证登录密码 IP未取到 或者 IP取到了但不是内网IP
        if (ip == null || (!ip.startsWith("192.168.") && !ip.startsWith("127.0.0.1") && !username.startsWith("#robot"))) {
            LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
            builder.setCode(10);
            httpResponseMessage.appendBody(builder.build().toByteArray()); // 请求地址不正确
            return;
        }

        User user = null;
        synchronized (syncObj) { // 需要保证线程安全
            user = getUserFromCache(username);
            if (user == null) {
                log.info(String.format("User:%s缓存不存在!", username));
                user = DataManager.getInstance().getUserFromDB(username);
                if (user == null) {
                    log.info(String.format("User:%s数据库中不存在!", username));
                    user = new User();

                    user.setUsername(username);
                    user.setPassword(password);
                    user.setCreatetime(System.currentTimeMillis());
                    user.setLastlogintime(System.currentTimeMillis());
                    user.setIsForbid(0);
                    user.setMac64(mac64);
                    user.setGameID("");
                    user.setVersion(version);
                    user.setPlatform(platform);
                    user.setIp(ip);
                    if (!DataManager.getInstance().addUserToDB(username, user)) {
                        log.error("数据库中写入User" + username + "失败!");
                        LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
                        builder.setCode(11);
                        httpResponseMessage.appendBody(builder.build().toByteArray()); // 帐号创建失败
                        return;
                    }
                } else {
                }
                addUserToCache(username, user);
            }

            if (!user.getPassword().equals(password)) {
                LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
                builder.setCode(12);
                httpResponseMessage.appendBody(builder.build().toByteArray()); // 密码不正确
                return;
            }
        }

        if (user.getIsForbid() != 0) {
            LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
            builder.setCode(13);
            httpResponseMessage.appendBody(builder.build().toByteArray()); // 帐号被冻结
            return;
        }
        
        {
            // 更新登录信息
            user.setLastlogintime(System.currentTimeMillis());
            user.setIsForbid(0);
            user.setMac64(mac64);
            user.setGameID("");
            user.setVersion(version);
            user.setPlatform(platform);
            user.setIp(ip);
            // 由定时器Update
        }
        
        {
            // 保存用户基础信息到SESSION中
            session.setAttribute(USER_ID, user.getId());
            session.setAttribute(USER_NAME, user.getUsername());
        }
        
        Token token = TokenManager.getInstance().genToken(user.getId(), user.getUsername());
        
//        {
//            // 预加载角色信息,加载玩家上一次登录的游戏服务器的角色
//            User.LoginInfo lastLoginInfo = user.getLoginInfos().getLastLogin5().peek();
//            if (lastLoginInfo != null) {
//                IoSession gameSession = Main.getLoginServer().getLoginTcpServer().getGameSession(lastLoginInfo.getGameID());
//                if (gameSession != null && gameSession.isConnected()) {
//                    // TODO 
//                    LoginMessage.LGLoadPlayerMessage.Builder builder = LoginMessage.LGLoadPlayerMessage.newBuilder();
//                    builder.setToken("");
//                    builder.setUserID(user.getId());
//                    builder.setPlayerName(lastLoginInfo.getPlayerName());
//                }
//            }
//        }
        
        LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
        builder.setCode(0);
        builder.setToken(token.getToken());
        builder.setUserID(user.getId());
        
        {
            LoginMessage.ServerInfo.Builder serverInfoBuilder = LoginMessage.ServerInfo.newBuilder();
            
            Collection<ServerInfo> serverInfos = Main.getLoginServer().getLoginTcpServer().getServerInfos().values();
            for (ServerInfo serverInfo : serverInfos) {
                serverInfoBuilder.setZoneid(serverInfo.getZoneid());
                serverInfoBuilder.setZonename(serverInfo.getZonename());
                serverInfoBuilder.setName(serverInfo.getName());
                serverInfoBuilder.setId(serverInfo.getId());
                serverInfoBuilder.setIp(serverInfo.getIp());
                serverInfoBuilder.setPort(serverInfo.getPort());
                serverInfoBuilder.setState(serverInfo.getState());
                serverInfoBuilder.setVersion(serverInfo.getVersion());
                serverInfoBuilder.setWeb(serverInfo.getWeb());
                
                builder.addServerlist(serverInfoBuilder.build());
            }
            byte[] toByteArray = builder.build().toByteArray();
            for (byte b : toByteArray) {
                System.out.println(b);
            }
            httpResponseMessage.appendBody(toByteArray);
        }
        
        long cost = System.currentTimeMillis() - begin;
        if (cost > 2000L) {
            log.warn("登录时间超过2秒!" + cost);
            if (cost > 5000L) {
                log.error("登录时间超过5秒!" + cost);
            }
        }

    }
    
    
    
    
    
    
    
    
    
    
    
    

    public Map<String, User> getCache4User() {
        return cache4User;
    }
    
    /**
     * 缓冲区查找用户
     * @param username 用户名称
     * @return 
     */
    public User getUserFromCache(String username) {
        return cache4User.get(username);
    }
    
    /**
     * 将用户数据添加到缓存
     * @param username
     * @param user
     * @return 
     */
    public boolean addUserToCache(String username, User user) {
        if (cache4User.containsKey(username)) {
            return false;
        }
        cache4User.put(username, user);
        return true;
    }
}
