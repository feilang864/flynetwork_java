package com.game.loginsr.manager;

import com.game.loginsr.token.Token;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class TokenManager {

    private static final TokenManager instance = new TokenManager();
    
    private final Map<String, Token> token4cache = new HashMap<>();
    
    public static TokenManager getInstance() {
        return instance;
    }
    
    public Token genToken(long userID, String username) {
        Token token = new Token(UUID.randomUUID().toString(), userID, username);
        token4cache.put(token.getToken(), token);
        return token;
    }
    
    public boolean checkToken(String token, long userID, String username) {
        Token t = token4cache.get(token);
        if (t == null) {
            return false;
        }
        
        if (t.getUserID() != userID) {
            return false;
        }
        
        if (System.currentTimeMillis() - t.getCreateTime() > 300000L) {
            return false;
        }
        
        if (!t.getUsername().equals(username)) {
            return false;
        }
        return true;
    }

    public Map<String, Token> getToken4Cache() {
        return token4cache;
    }
    
    
    public void remoteToken(String key) {
        token4cache.remove(key);
    }
}
