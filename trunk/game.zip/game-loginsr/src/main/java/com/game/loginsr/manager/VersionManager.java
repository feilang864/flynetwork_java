package com.game.loginsr.manager;

/**
 * 版本管理器
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class VersionManager {

    private static final VersionManager instance = new VersionManager();
    
    public static VersionManager getInstance() {
        return instance;
    }
    
    /**
     * 客户端版本验证
     * @param version
     * @return 1 通过验证
     */
    public int checkVersion(String version) {
        // TODO 客户端版本验证
        return 1;
    }
}
