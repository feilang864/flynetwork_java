package com.game.loginsr.main;


import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.loginsr.server.LoginServer;
import java.io.File;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class Main {

    private static final Logger log = LoggerFactory.getLogger(Main.class);
    
    private static LoginServer loginServer;

    public static LoginServer getLoginServer() {
        return loginServer;
    }

    public static void main(String[] args) {
        String tmp = "D:\\game\\game-loginsr\\target\\classes";
        Serializer serializer = new Persister();

        ThreadPoolExecutorConfig defaultThreadExcutorConfig4HttpServer = null;
        MinaServerConfig minaServerConfig4HttpServer = null;

        {

            String defaultThreadExcutorConfigPath4HttpServer = "LoginHttpServer\\defaultThreadPoolExecutorConfig.xml";
            String minaServerConfigPath4HttpServer = "LoginHttpServer/minaServerConfig.xml";

            if (!new File(defaultThreadExcutorConfigPath4HttpServer).exists()) {
                defaultThreadExcutorConfigPath4HttpServer = tmp + "\\" + defaultThreadExcutorConfigPath4HttpServer;
                if (!new File(defaultThreadExcutorConfigPath4HttpServer).exists()) {
                    log.error("无法找到文件" + defaultThreadExcutorConfigPath4HttpServer);
                    System.exit(1);
                }
                try {
                    defaultThreadExcutorConfig4HttpServer = serializer.read(ThreadPoolExecutorConfig.class, new File(defaultThreadExcutorConfigPath4HttpServer));
                } catch (Exception ex) {
                    log.error("文件" + defaultThreadExcutorConfigPath4HttpServer + "配置有误", ex);
                    System.exit(1);
                }
            }

            if (!new File(minaServerConfigPath4HttpServer).exists()) {
                minaServerConfigPath4HttpServer = tmp + "\\" + minaServerConfigPath4HttpServer;
                if (!new File(minaServerConfigPath4HttpServer).exists()) {
                    log.error("无法找到文件" + minaServerConfigPath4HttpServer);
                    System.exit(1);
                }
                try {
                    minaServerConfig4HttpServer = serializer.read(MinaServerConfig.class, new File(minaServerConfigPath4HttpServer));
                } catch (Exception ex) {
                    log.error("文件" + minaServerConfigPath4HttpServer + "配置有误", ex);
                    System.exit(1);
                }
            }
        }

        ThreadPoolExecutorConfig defaultThreadExcutorConfig4TcpServer = null;
        MinaServerConfig minaServerConfig4TcpServer = null;

        {

            String defaultThreadExcutorConfigPath4TcpServer = "LoginTcpServer\\defaultThreadPoolExecutorConfig.xml";
            String minaServerConfigPath4TcpServer = "LoginTcpServer/minaServerConfig.xml";

            if (!new File(defaultThreadExcutorConfigPath4TcpServer).exists()) {
                defaultThreadExcutorConfigPath4TcpServer = tmp + "\\" + defaultThreadExcutorConfigPath4TcpServer;
                if (!new File(defaultThreadExcutorConfigPath4TcpServer).exists()) {
                    log.error("无法找到文件" + defaultThreadExcutorConfigPath4TcpServer);
                    System.exit(1);
                }
                try {
                    defaultThreadExcutorConfig4TcpServer = serializer.read(ThreadPoolExecutorConfig.class, new File(defaultThreadExcutorConfigPath4TcpServer));
                } catch (Exception ex) {
                    log.error("文件" + defaultThreadExcutorConfigPath4TcpServer + "配置有误", ex);
                    System.exit(1);
                }
            }

            if (!new File(minaServerConfigPath4TcpServer).exists()) {
                minaServerConfigPath4TcpServer = tmp + "\\" + minaServerConfigPath4TcpServer;
                if (!new File(minaServerConfigPath4TcpServer).exists()) {
                    log.error("无法找到文件" + minaServerConfigPath4TcpServer);
                    System.exit(1);
                }
                try {
                    minaServerConfig4TcpServer = serializer.read(MinaServerConfig.class, new File(minaServerConfigPath4TcpServer));
                } catch (Exception ex) {
                    log.error("文件" + minaServerConfigPath4TcpServer + "配置有误", ex);
                    System.exit(1);
                }
            }
        }

        loginServer = new LoginServer(defaultThreadExcutorConfig4HttpServer, minaServerConfig4HttpServer
                , defaultThreadExcutorConfig4TcpServer, minaServerConfig4TcpServer);
        new Thread(loginServer).start();
    }
}
