package com.game.loginsr.server.tcp;

import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.io.message.MessagePool;
import com.game.engine.io.mina.Service;
import com.game.engine.io.mina.handler.ServerProtocolHandler;
import com.game.engine.io.mina.impl.MinaServer;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.loginsr.vo.ServerInfo;
import com.game.proto.LoginMessage;
import com.game.proto.LoginMessage.GLTokenCheckMessage;
import com.game.proto.LoginMessage.GLUpdateServerInfoMessage;
import com.game.proto.RegisterLoginMessage;
import com.game.proto.RegisterLoginMessage.GLRegisterLoginMessage;
import com.game.proto.handler.login.GLTokenCheckHandler;
import com.game.proto.handler.login.GLUpdateServerInfoHandler;
import com.game.proto.handler.registerlogin.GLRegisterLoginHandler;
import com.google.protobuf.Message;
import java.util.HashMap;
import java.util.Map;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class LoginTcpServer extends Service<MessagePool, MinaServerConfig> {

    private static final Logger log = LoggerFactory.getLogger(LoginTcpServer.class);
    
    private final MinaServer minaServer;
    
    private final MinaServerConfig minaServerConfig;
    
    
    public static final String GS_CONN_ID = "GS_CONN_ID";
    // 服务器列表信息
    private final Map<String, ServerInfo> serverInfos = new HashMap<>();
    
    public Map<String, ServerInfo> getServerInfos() {
        return serverInfos;
    }
    
    public void updateServerInfo(ServerInfo serverInfo) {
        String key = serverInfo.getWeb() + "_" + serverInfo.getId();
        serverInfos.remove(key);
        serverInfos.put(key, serverInfo);
    }

    // 链接成功的游戏客户端
    private final Map<Integer, IoSession> gameSessions = new HashMap<>();
    
    public void putGameSession(int key, IoSession session) {
        gameSessions.remove(key);
        gameSessions.put(key, session);
    }
    
    public IoSession getGameSession(int id) {
        return gameSessions.get(id);
    }
    
    public LoginTcpServer(ThreadPoolExecutorConfig defaultThreadExcutorConfig, ThreadPoolExecutorConfig mapServerThreadExcutorConfig
        , MinaServerConfig minaServerConfig) {
        super(new MessagePool(), defaultThreadExcutorConfig, mapServerThreadExcutorConfig);
        this.minaServerConfig = minaServerConfig;
        
        minaServer = new MinaServer(minaServerConfig, new LoginTcpServerHandler(messagePool));
    }

    @Override
    protected void initProtos() {

        messagePool.register(
                110101,                                                         // id 协议ID
                GLRegisterLoginMessage.class,              // messageClass 协议请求消息类型
                GLRegisterLoginHandler.class,// handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                RegisterLoginMessage.GLRegisterLoginMessage.newBuilder(),       // builder 协议请求消息构造器
                //RegisterLoginMessage.LGRegisterLoginMessage.class,              // 协议响应消息类型
                //RegisterLoginMessage.LGRegisterLoginMessage.newBuilder(),       // builder4Res  协议响应消息构造器
                0                                                            // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        messagePool.register(
                200101,                                                         // id 协议ID
                GLUpdateServerInfoMessage.class,                   // messageClass 协议请求消息类型
                GLUpdateServerInfoHandler.class,     // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.GLUpdateServerInfoMessage.newBuilder(),            // builder 协议请求消息构造器
                //null,                                                           // 协议响应消息类型
                //null,                                                           // builder4Res  协议响应消息构造器
                0                                                            // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
        
        messagePool.register(
                200104,                                                         // id 协议ID
                GLTokenCheckMessage.class,                         // messageClass 协议请求消息类型
                GLTokenCheckHandler.class,           // handlerClass 协议请求处理类型
                0,                                                              // threadModel 协议请求线程模型
                LoginMessage.GLTokenCheckMessage.newBuilder(),                  // builder 协议请求消息构造器
                //LoginMessage.LGTokenCheckMessage.class,                         // 协议响应消息类型
                //LoginMessage.LGTokenCheckMessage.newBuilder(),                  // builder4Res  协议响应消息构造器
                0                                                            // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                                                                //               一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
        );
    }

    @Override
    protected void initMapServers() {
        log.warn(minaServerConfig.getName() + " 是 LoginTcpServer 无需初始化地图服务器");
    }

    @Override
    protected void running() {
        log.debug(" run ... ");
        minaServer.run();
    }

    @Override
    protected void onShutdown() {
        log.debug(" stop ... ");
        minaServer.stop();
    }
    @Override
    public String toString() {
        return minaServerConfig.getName();
    }

    public int getId() {
        return minaServerConfig.getId();
    }
    
    public String getName() {
        return minaServerConfig.getName();
    }
    
    public String getWeb() {
        return minaServerConfig.getWeb();
    }
    
    public class LoginTcpServerHandler extends ServerProtocolHandler {

        private final Logger log = LoggerFactory.getLogger(LoginTcpServerHandler.class);

        private final MessagePool messagePool;

        public LoginTcpServerHandler(MessagePool messagePool) {
            this.messagePool = messagePool;
        }

        @Override
        public void sessionClosed(IoSession ioSession) {
            Integer gsconnid = (Integer) ioSession.getAttribute(GS_CONN_ID);
            if (gsconnid != null) {
                gameSessions.remove(gsconnid);
                log.error("游戏服务器:" + gsconnid + "断开链接");
            }
        }

        @Override
        protected void doTranspond(IoSession ioSession, Message message) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        protected MessagePool getMessagePool() {
            return messagePool;
        }

    }
}

