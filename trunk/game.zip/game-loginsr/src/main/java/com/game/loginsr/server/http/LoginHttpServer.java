package com.game.loginsr.server.http;

import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.io.message.HttpMessagePool;
import com.game.engine.io.mina.Service;
import com.game.engine.io.mina.handler.HttpServerProtocolHandler;
import com.game.engine.io.mina.impl.MinaHttpServer;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.loginsr.server.http.handler.LoginHttpReqHandler;
import com.game.loginsr.server.http.handler.UnknowHttpReqHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class LoginHttpServer extends Service<HttpMessagePool, MinaServerConfig> {
    
    private static final Logger log = LoggerFactory.getLogger(LoginHttpServer.class);
    
    private final MinaHttpServer minaHttpServer;
    private final MinaServerConfig minaServerConfig;
    
    public LoginHttpServer(ThreadPoolExecutorConfig defaultThreadExcutorConfig
            , ThreadPoolExecutorConfig mapServerThreadExcutorConfig
            , MinaServerConfig minaServerConfig) {
        super(new HttpMessagePool(), defaultThreadExcutorConfig, mapServerThreadExcutorConfig);
        this.minaServerConfig = minaServerConfig;
        this.minaHttpServer = new MinaHttpServer(minaServerConfig, new LoginHttpServerHandler(messagePool));
    }

    @Override
    protected void initProtos() {
        messagePool.register("", UnknowHttpReqHandler.class, 0);
        messagePool.register("login", LoginHttpReqHandler.class, 0);
    }

    @Override
    protected void initMapServers() {
        log.warn(minaServerConfig.getName() + " 是 HTTPSERVER 无需初始化地图服务器");
    }

    @Override
    protected void running() {
        log.debug(" run ... ");
        minaHttpServer.run();
    }

    @Override
    protected void onShutdown() {
        log.debug(" stop ... ");
        minaHttpServer.stop();
    }

    @Override
    public String toString() {
        return minaServerConfig.getName();
    }
}

class LoginHttpServerHandler extends HttpServerProtocolHandler {

    private static final Logger log = LoggerFactory.getLogger(LoginHttpServerHandler.class);
    
    private final HttpMessagePool messagePool;
    
    public LoginHttpServerHandler(HttpMessagePool messagePool) {
        this.messagePool = messagePool;
    }

    @Override
    protected HttpMessagePool getMessagePool() {
        return messagePool;
    }


}