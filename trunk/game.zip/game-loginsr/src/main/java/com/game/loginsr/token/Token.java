package com.game.loginsr.token;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class Token {

    private final String token;
    
    private final long userID;
    
    private final String username;
    
    private final long createTime = System.currentTimeMillis();

    public Token(String token, long userID, String username) {
        this.token = token;
        this.userID = userID;
        this.username = username;
    }

    public String getToken() {
        return token;
    }

    public long getUserID() {
        return userID;
    }

    public String getUsername() {
        return username;
    }

    public long getCreateTime() {
        return createTime;
    }
    
    
}
