package com.game.loginsr.data;

import com.game.engine.timer.TimerEvent;
import com.game.loginsr.po.User;
import com.game.loginsr.po.controller.UserJpaController;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class DataManager{
    
    private static final Logger log = LoggerFactory.getLogger(DataManager.class);
    
    
    private final EntityManagerFactory emf;

    // db controller
    private final UserJpaController userJpaController ;
    
    private static final DataManager instance = new DataManager();
    

    public static DataManager getInstance() {
        return instance;
    }

    private DataManager() {
        emf = Persistence.createEntityManagerFactory("pu");
     
        userJpaController = new UserJpaController(emf);
    }
    
    public UserJpaController getUserJpaController() {
        return userJpaController;
    }

    /**
     * 数据库中查找用户
     * @param username
     * @return 
     */
    public User getUserFromDB(String username) {
        return userJpaController.findUserByUsername(username);
    }
    
    
    public boolean addUserToDB(String username, User user) {
        if (user.getId() != 0) {
            log.error(username + "已经在数据库中创建了");
            return false;
        }
        try {
            userJpaController.create(user);
        } catch(Exception ex) {
            log.error("创建用户:" + username + " 失败!");
            return false;
        }
        return true;
    }
    
}
