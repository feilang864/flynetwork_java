package com.game.loginsr.server;

import com.game.loginsr.main.Main;
import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.thread.ServerThread;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.engine.timer.ServerHeartTimer;
import com.game.engine.utils.Config;
import com.game.loginsr.server.http.LoginHttpServer;
import com.game.loginsr.server.tcp.LoginTcpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class LoginServer implements Runnable {
    
    private static final Logger log = LoggerFactory.getLogger(LoginServer.class);

    private final LoginHttpServer loginHttpServer;
    private final LoginTcpServer loginTcpServer;
    
    private final ThreadGroup threadGroup = new ThreadGroup("LoginServerMainThread");
    private final ServerThread mainServerThread = new ServerThread(threadGroup, "LoginServerMainThread", 1000L); // 1秒的心跳
    
    public LoginServer(
              ThreadPoolExecutorConfig defaultThreadExcutorConfig4HttpServer , MinaServerConfig minaServerConfig4HttpServer
            , ThreadPoolExecutorConfig defaultThreadExcutorConfig4TcpServer, MinaServerConfig minaServerConfig4TcpServer) {
        
        Config.serverID = minaServerConfig4TcpServer.getId(); // 设置SERVERID
        
        loginHttpServer = new LoginHttpServer(defaultThreadExcutorConfig4HttpServer, null, minaServerConfig4HttpServer);
        
        loginTcpServer = new LoginTcpServer(defaultThreadExcutorConfig4TcpServer, null, minaServerConfig4TcpServer);
    }
    
    public static LoginServer getInstance() {
        return Main.getLoginServer();
    }

    @Override
    public void run() {
        log.info("LoginServer::LoginHttpServer::start!!!");
        new Thread(loginHttpServer).start();
        log.info("LoginServer::loginTcpServer::start!!!");
        new Thread(loginTcpServer).start();
        log.info("LoginServer::DataServer::start!!!");
        
        log.info("LoginServer::mainServerThread::start!!!");
        mainServerThread.start();
        log.info("LoginServer::mainServerThread::ServerHeartTimer::start!!!");
        mainServerThread.addTimerEvent(new ServerHeartTimer(loginTcpServer.getId(), loginTcpServer.getWeb()));
        
    }
    
    public LoginHttpServer getLoginHttpServer() {
        return loginHttpServer;
    }

    public LoginTcpServer getLoginTcpServer() {
        return loginTcpServer;
    }
    
}
