package com.game.loginsr.server.http.handler;

import com.game.engine.io.commmand.HttpHandler;
import com.game.engine.io.mina.code.HttpResponseMessage;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class UnknowHttpReqHandler extends HttpHandler {

    @Override
    protected HttpResponseMessage errResponseMessage() {
        return null;
    }

    @Override
    public void run() {
        try {
            setParameter(new HttpResponseMessage());

            getParameter().appendBody("404");
        } finally {
            response();
        }

    }

}

