package com.game.loginsr.po;

import com.game.engine.utils.Config;
import java.io.Serializable;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "User.findAll", query = "SELECT u FROM User u"),
    @NamedQuery(name = "User.findById", query = "SELECT u FROM User u WHERE u.id = :id"),
    @NamedQuery(name = "User.findByUsername", query = "SELECT u FROM User u WHERE u.username = :username")})
public class User implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    /**
     * 用户名
     */
    @Column(length = 64, nullable = true)
    private String username;

    /**
     * 用户密码
     */
    @Column(length = 64, nullable = true)
    private String password;

    /**
     * 创建时间*
     */
    @Column
    private long createtime;

    /**
     * 注册平台*
     */
    @Column(length = 128)
    private String platform;

    /**登陆IP**/
    @Column(length = 64)
    private String ip;
    
    /**
     * 是否禁用. 1表示禁用*
     */
    @Column
    private int isForbid;

    /**
     * 最后一次登录时间*
     */
    @Column
    private long lastlogintime;

    /**
     * 最后一次登录的游戏服务器*
     */
    @Column(length = 64)
    private String gameID;

    /**
     * 游戏客户端版号*
     */
    @Column(length = 64)
    private String version;

    /**
     * 设备编号(手机串号)*
     */
    @Column(length = 128)
    private String mac64;

    /**
     * 记录最后5次登录信息*
     */
    @Lob
    @Basic(fetch = FetchType.EAGER)
    @Column
    private LoginInfos loginInfos = new LoginInfos();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getCreatetime() {
        return createtime;
    }

    public void setCreatetime(long createtime) {
        this.createtime = createtime;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getIsForbid() {
        return isForbid;
    }

    public void setIsForbid(int isForbid) {
        this.isForbid = isForbid;
    }

    public long getLastlogintime() {
        return lastlogintime;
    }

    public void setLastlogintime(long lastlogintime) {
        this.lastlogintime = lastlogintime;
    }

    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getMac64() {
        return mac64;
    }

    public void setMac64(String mac64) {
        this.mac64 = mac64;
    }

    public LoginInfos getLoginInfos() {
        return loginInfos;
    }

    public void setLoginInfos(LoginInfos loginInfos) {
        this.loginInfos = loginInfos;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    
    
    public static final class LoginInfos implements Serializable {
        
        
        private Queue<LoginInfo> lastLogin5 = new LinkedBlockingQueue<>();

        public Queue<LoginInfo> getLastLogin5() {
            return lastLogin5;
        }

        public void setLastLogin5(Queue<LoginInfo> lastLogin5) {
            this.lastLogin5 = lastLogin5;
        }
        
        public void addLastLogin(LoginInfo loginInfo) {
            if (lastLogin5.add(loginInfo)) {
                if (lastLogin5.size() > 5) {
                    lastLogin5.poll();
                }
            }
        }
        
    }

    /**
     * 记录登录信息
     */
    public static final class LoginInfo implements Serializable {

        /**
         * 登录时间*
         */
        private long loginTime;
        /**
         * 登录的游戏服务器*
         */
        private int gameID;
        /**
         * 选择的角色名称*
         */
        private String playerName;
        /**
         * 选择的性别*
         */
        private int sex;
        /**
         * 选择的种族*
         */
        private int race;
        /**
         * 选择的等级*
         */
        private int lv;
        /**
         * 选择的职业*
         */
        private int job;
        /**
         * IP地址*
         */
        private String ip;

        public long getLoginTime() {
            return loginTime;
        }

        public void setLoginTime(long loginTime) {
            this.loginTime = loginTime;
        }

        public int getGameID() {
            return gameID;
        }

        public void setGameID(int gameID) {
            this.gameID = gameID;
        }

        public String getPlayerName() {
            return playerName;
        }

        public void setPlayerName(String playerName) {
            this.playerName = playerName;
        }

        public int getSex() {
            return sex;
        }

        public void setSex(int sex) {
            this.sex = sex;
        }

        public int getRace() {
            return race;
        }

        public void setRace(int race) {
            this.race = race;
        }

        public int getLv() {
            return lv;
        }

        public void setLv(int lv) {
            this.lv = lv;
        }

        public int getJob() {
            return job;
        }

        public void setJob(int job) {
            this.job = job;
        }

        public String getIp() {
            return ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }
    }
}
