package com.game.loginsr.server.http.handler;

import com.game.engine.io.commmand.HttpHandler;
import com.game.engine.io.mina.code.HttpResponseMessage;
import com.game.loginsr.manager.UserManager;
import com.game.loginsr.manager.VersionManager;
import com.game.proto.LoginMessage;
/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class LoginHttpReqHandler extends HttpHandler {

    @Override
    protected HttpResponseMessage errResponseMessage() {
        return null;
    }

    @Override
    public void run() {
        try {
            setParameter(new HttpResponseMessage());

            String version = getMessage().getParameter("version");
            String username = getMessage().getParameter("username");
            String password = getMessage().getParameter("password");
            String mac64 = getMessage().getParameter("mac64");
            String platform = getMessage().getParameter("platform");
            
            if (version == null || username == null || password == null || mac64 == null || platform == null) {
                LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
                builder.setCode(1);
                getParameter().appendBody(builder.build().toByteArray()); // 请求数据不完整
                return;
            }
            
            if (version.trim().equals("") || username.trim().equals("") || password .trim().equals("") 
                    || mac64.trim().equals("") || platform.trim().equals("")) {
                
                LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
                builder.setCode(1);
                getParameter().appendBody(builder.build().toByteArray()); // 请求数据不完整
                return;
            }

            if (VersionManager.getInstance().checkVersion(version) != 1) {
                LoginMessage.ResServerInfosMessage.Builder builder = LoginMessage.ResServerInfosMessage.newBuilder();
                builder.setCode(20);
                getParameter().appendBody(builder.build().toByteArray()); // 请求数据不完整
                return;
            }

            UserManager.getInstance().login(getParameter(), getSession(), username, password, mac64, version, platform);
        } finally {
            response();
        }
    }
}