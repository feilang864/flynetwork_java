package com.game.engine.timer.qz;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class At0ClockEvent extends SchedulerEvent {

    private static final Logger log = LoggerFactory.getLogger(At0ClockEvent.class);
    
    @Override
    public void run() {
        log.info("At0ClockEvent run...");
        
        log.info("At0ClockEvent end...");
    }

}
