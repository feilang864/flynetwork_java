package com.game.engine.thread;

import com.game.engine.io.commmand.IHandler;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 处理如,排行榜,巅峰对决等,玩家的操作可能影响到其他玩家数据的时候,需要使用单独的模块
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 * @param <T>
 */
public class SyncThreadExecutor<T extends IHandler> extends Thread implements Executor {

    //日志
    private static final Logger log = LoggerFactory.getLogger(SyncThreadExecutor.class);

    // 消息队列
    private final LinkedBlockingQueue<T> queue = new LinkedBlockingQueue<>();

    // 最多允许缓存的请求
    private final int MAX_SIZE = 300;
    
    private final String threadName;

    private boolean stop;
    
    public SyncThreadExecutor(String threadName) {
        super(threadName);
        this.threadName = threadName;
    }


    public void stop(boolean flag) {
        stop = flag;
        try {
            synchronized (this) {
                notify();
            }
        } catch (Exception e) {
            log.error("数据库读取操作线程 " + threadName + " stop Exception:", e);
        }
    }

    @Override
    public void run() {
        stop = false;

        while (!stop) {
            T handler = queue.poll();
            if (handler == null) {
                try {
                    synchronized (this) {
                        wait();
                    }
                } catch (InterruptedException e) {
                    log.error("ModelHandlerThread " + threadName + " Wait Exception:", e);
                }
            } else {
                if (queue.size() <= MAX_SIZE) {
                    // TODO 执行
                    handler.run();
                } else {
                    // TODO 直接将缓存区的数据,写入文本中,然后清空缓存.
                    throw new RuntimeException("ModelHandlerThread " + threadName + " 缓存数" + queue.size() + "超过了" + MAX_SIZE + "的上限了:");
                }
            }
        }
    }

    /**
     * 添加需要处理的数据
     */
    @Override
    public void execute(Runnable command) {
        try {
            this.queue.add((T) command);
            synchronized (this) {
                notify();
            }
        } catch (Exception e) {
            log.error("模块操作线程" + threadName + " Notify Exception:", e);
        }
    }

}
