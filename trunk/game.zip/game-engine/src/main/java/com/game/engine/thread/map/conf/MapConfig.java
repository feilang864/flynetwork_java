package com.game.engine.thread.map.conf;

/**
 * 单个地图线程配置
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class MapConfig {

    // 服务器ID
    private int serverId;
    // 线路
    private int lineId;
    // 地图唯一ID
    private long mapId;
    // 地图模版ID,对应策划配置
    private int mapModelId;

    public int getServerId() {
        return this.serverId;
    }

    public void setServerId(int serverId) {
        this.serverId = serverId;
    }

    public int getLineId() {
        return this.lineId;
    }

    public void setLineId(int lineId) {
        this.lineId = lineId;
    }

    public long getMapId() {
        return this.mapId;
    }

    public void setMapId(long mapId) {
        this.mapId = mapId;
    }

    public int getMapModelId() {
        return this.mapModelId;
    }

    public void setMapModelId(int mapModelId) {
        this.mapModelId = mapModelId;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + (int) (this.mapId ^ (this.mapId >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MapConfig other = (MapConfig) obj;
        if (this.mapId != other.mapId) {
            return false;
        }
        return true;
    }

}
