package com.game.engine.thread.map.conf;

import java.util.ArrayList;
import java.util.List;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 * 多个地图线程配置
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
@Root
public class MapConfigs {

    @ElementList
    private List<MapConfig> MapConfigs = new ArrayList<>();

    public List<MapConfig> getMapConfigs() {
        return MapConfigs;
    }

    public void setMapConfigs(List<MapConfig> MapConfigs) {
        this.MapConfigs = MapConfigs;
    }

}
