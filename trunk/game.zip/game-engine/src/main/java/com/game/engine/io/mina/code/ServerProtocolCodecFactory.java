package com.game.engine.io.mina.code;

import com.game.engine.io.conf.BaseServerConfig;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @param <T>
 */
public class ServerProtocolCodecFactory<T extends BaseServerConfig> implements ProtocolCodecFactory {
    
    private final T config;
    
    public ServerProtocolCodecFactory(T config) {
        this.config = config;
    }

    @Override
    public ProtocolEncoder getEncoder(IoSession is) throws Exception {
        return new ServerProtocolEncoder<>(config);
    }

    @Override
    public ProtocolDecoder getDecoder(IoSession is) throws Exception {
        return new ServerProtocolDecoder<>(config);
    }
}