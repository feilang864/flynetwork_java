package com.game.engine.io.commmand;

import com.game.engine.io.mina.code.HttpRequestMessage;
import com.game.engine.io.mina.code.HttpResponseMessage;
import org.apache.mina.core.future.IoFutureListener;
import org.apache.mina.core.session.IoSession;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public abstract class HttpHandler implements IHandler {
    private HttpResponseMessage   parameter;
    
    private IoSession             session;    // 消息来源
    private HttpRequestMessage    message;      // 请求消息
    private int                   content;      // 对应http:/127.0.0.1:8080/login 中的login
    
    private long createTime;

    @Override
    public Object clone()
            throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public IoSession getSession() {
        return session;
    }

    @Override
    public void setSession(IoSession session) {
        this.session = session;
    }
    
    @Override
    public HttpRequestMessage getMessage() { // HttpRequestMessage
        return (HttpRequestMessage) this.message;
    }

    @Override
    public void setMessage(Object message) {
        if (message instanceof HttpRequestMessage) {
            this.message = (HttpRequestMessage) message;
        }
    }

    @Override
    public HttpResponseMessage getParameter() {
        return this.parameter;
    }

    @Override
    public void setParameter(Object parameter) {
        if (parameter instanceof HttpResponseMessage) {
            this.parameter = (HttpResponseMessage) parameter;
        }
    }

    @Override
    public long getCreateTime() {
        return this.createTime;
    }

    @Override
    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    @Override
    public int getMapThreadQueue() {
        return this.content;
    }

    @Override
    public void setMapThreadQueue(int mapThreadQueue) {
        this.content = mapThreadQueue;
    }

    /**
     * 没有返回值的情况下处理
     * @return 
     */
    protected abstract HttpResponseMessage errResponseMessage();

    public void response() {
        // HttpResponseMessage response = new HttpResponseMessage();
        // response.setContentType("text/plain");
        // response.setResponseCode(HttpResponseMessage.HTTP_STATUS_SUCCESS);
        // response.appendBody("CONNECTED");

        // msg.setResponseCode(HttpResponseMessage.HTTP_STATUS_SUCCESS);
        // byte[] b = new byte[ta.buffer.limit()];
        // ta.buffer.rewind().get(b);
        // msg.appendBody(b);
        // System.out.println("####################");
        // System.out.println("  GET_TILE RESPONSE SENT - ATTACHMENT GOOD DIAMOND.SI="+d.si+
        // ", "+new
        // java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss.SSS").format(new
        // java.util.Date()));
        // System.out.println("#################### - status="+ta.state+", index="+message.getIndex());
        // // Unknown request
        // response = new HttpResponseMessage();
        // response.setResponseCode(HttpResponseMessage.HTTP_STATUS_NOT_FOUND);
        // response.appendBody(String.format(
        // "<html><body><h1>UNKNOWN REQUEST %d</h1></body></html>",
        // HttpResponseMessage.HTTP_STATUS_NOT_FOUND));
        if (parameter != null) {
            session.write(parameter).addListener(IoFutureListener.CLOSE);
        } else {
            session.write(errResponseMessage()).addListener(IoFutureListener.CLOSE);
        }
    }
}
