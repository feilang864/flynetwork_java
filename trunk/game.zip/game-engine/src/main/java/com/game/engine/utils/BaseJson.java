package com.game.engine.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.parser.Feature;
import com.alibaba.fastjson.serializer.SerializerFeature;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class BaseJson {

    public static String toJSONString(Object paramObject) {
        return JSON.toJSONString(paramObject, new SerializerFeature[]{SerializerFeature.DisableCircularReferenceDetect});
    }

    public static String toJSONStringWriteClassName(Object paramObject) {
        return JSON.toJSONString(paramObject, new SerializerFeature[]{SerializerFeature.WriteClassName, SerializerFeature.DisableCircularReferenceDetect});
    }

    public static String toJSONStringWithDateFormat(long paramLong) {
        Date localDate = new Date(paramLong);
        return toJSONStringWithDateFormat(localDate);
    }

    public static String toJSONStringWithDateFormat(long paramLong, String paramString) {
        Date localDate = new Date(paramLong);
        return toJSONStringWithDateFormat(localDate, paramString);
    }

    public static String toJSONStringWithDateFormat(Date paramDate) {
        return JSON.toJSONStringWithDateFormat(paramDate, "yyyy-MM-dd HH:mm:ss", new SerializerFeature[]{SerializerFeature.WriteDateUseDateFormat});
    }

    public static String toJSONStringWithDateFormat(Date paramDate, String paramString) {
        return JSON.toJSONStringWithDateFormat(paramDate, paramString, new SerializerFeature[]{SerializerFeature.WriteDateUseDateFormat});
    }

    public static Object parse(String paramString) {
        return JSON.parse(paramString);
    }

    public static Object parseObject(String paramString, Class paramClass) {
        return JSON.parseObject(paramString, paramClass);
    }

    public static Object parseObject(String paramString, TypeReference paramTypeReference) {
        return JSON.parseObject(paramString, paramTypeReference, new Feature[0]);
    }

    public static List parseArray(String paramString, Class paramClass) {
        return JSON.parseArray(paramString, paramClass);
    }

    public static List parseArray(String paramString, Type[] paramArrayOfType) {
        return JSON.parseArray(paramString, paramArrayOfType);
    }
}
