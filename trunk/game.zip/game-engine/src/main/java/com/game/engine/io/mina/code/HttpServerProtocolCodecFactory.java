package com.game.engine.io.mina.code;

import org.apache.mina.filter.codec.demux.DemuxingProtocolCodecFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class HttpServerProtocolCodecFactory extends
        DemuxingProtocolCodecFactory {

    public HttpServerProtocolCodecFactory() {
        super.addMessageDecoder(HttpRequestDecoder.class);
        super.addMessageEncoder(HttpResponseMessage.class, HttpResponseEncoder.class);
    }

}
