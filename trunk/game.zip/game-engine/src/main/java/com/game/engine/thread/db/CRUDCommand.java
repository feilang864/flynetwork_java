package com.game.engine.thread.db;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 * @param <T>
 */
public class CRUDCommand<T> implements Runnable {
    
    private static final Logger log = LoggerFactory.getLogger(CRUDCommand.class);

    public enum CRUD {

        CREAT, READ, UPDATE, DELETE
    }

    public interface ICreateCallback<T> {

        void create(T po);

//        void createFailCallBack(Object result);
    }

    public interface IReadCallback<T> {

        void read(T po);

//        void readFailCallBack(Object result);
    }

    public interface IUpdateCallback<T> {

        void update(T po);

//        void updateFailCallBack(Object result);
    }

    public interface IDeleteCallback<T> {

        void delete(T po);

//        void deleteFailCallBack(Object result);
    }

    // 具体操作
    private CRUD crud;
    // 实体对象
    private T po;

    private transient static Map<String, ICreateCallback> createCallBacks = new HashMap<>();

    public transient static IReadCallback readCallBack;

    public transient static IUpdateCallback updateCallBack;

    public transient static IDeleteCallback deleteCallBack;
    
    public static void registerCreateCallBack(String name, ICreateCallback createCallBack) {
        createCallBacks.put(name, createCallBack);
    }
    
    private String name;

    public CRUDCommand() {
    }

    public CRUDCommand(String name, CRUD crud, T po/*, ICreateCallback createCallBack, IReadCallback readCallBack, IUpdateCallback updateCallBack, IDeleteCallback deleteCallBack*/) {
        this.name = name;
        this.crud = crud;
        this.po = po;
//        this.createCallBack = createCallBack;
//        this.readCallBack = readCallBack;
//        this.updateCallBack = updateCallBack;
//        this.deleteCallBack = deleteCallBack;
    }

    @Override
    public void run() {
        switch (crud) {
            case CREAT:
                // TODO 具体操作
                if (createCallBacks.get(name) != null) {
                    createCallBacks.get(name).create(po);
                }
                break;
            case READ:
                // TODO 具体操作
                if (readCallBack != null) {
                    readCallBack.read(po);
                }
                break;
            case UPDATE:
                // TODO 具体操作
                if (updateCallBack != null) {
                    updateCallBack.update(po);
                }
                break;
            case DELETE:
                // TODO 具体操作
                if (deleteCallBack != null) {
                    deleteCallBack.delete(po);
                }
                break;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public CRUD getCrud() {
        return crud;
    }

    public void setCrud(CRUD crud) {
        this.crud = crud;
    }

    public T getPo() {
        return po;
    }

    public void setPo(T po) {
        this.po = po;
    }

//    public ICreateCallback getCreateCallBack() {
//        return createCallBack;
//    }
//
//    public void setCreateCallBack(ICreateCallback createCallBack) {
//        this.createCallBack = createCallBack;
//    }
    
    protected CRUDCommand<T> jsonClone() throws CloneNotSupportedException {
        // 浅拷贝
        // return super.clone();
        
        // 使用fastjson实现深拷贝
        String toJSONString = JSON.toJSONString(CRUDCommand.this, new SerializerFeature[] { SerializerFeature.WriteClassName, SerializerFeature.DisableCircularReferenceDetect });
        System.out.println(toJSONString);
        return JSON.parseObject(toJSONString, this.getClass());
    }

}
