package com.game.engine.script;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLClassLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class BaseScriptClassLoader extends ClassLoader {
    
    private static final Logger log = LoggerFactory.getLogger(BaseScriptClassLoader.class);

    BaseScriptClassLoader(URLClassLoader paramURLClassLoader) {
    }

    /**
     * 加载脚本类
     * @param scriptEntryClassName 如:serverscripts.activities.ActivitieValueScript
     * @param scriptEntryClassPath 如:bin\server\serverscripts\activities\ActivitieValueScript.class
     * @return 
     */
    public Class loadScriptClass(String scriptEntryClassName, String scriptEntryClassPath) {
        try {
            Class clazz = null;
            String className = scriptEntryClassName; // serverscripts.activities.ActivitieValueScript
            try {
                clazz = super.findLoadedClass(className); // 已经加载的类中查找类
            } catch (Exception ex) {
            }
            if (clazz == null) {
                try {
                    clazz = super.findSystemClass(className); // 从系统环境中查找类
                } catch (ClassNotFoundException ex) {
                }
            }
            if (clazz == null) {
                try {
                    clazz = super.findClass(className); // 查找类
                } catch (ClassNotFoundException ex) {
                }
            }
            byte[] content = readScriptEntryClassContent(scriptEntryClassPath); // bin/server/serverscripts/activities/ActivitieValueScript.class  --> 返回.class文件的内容
            if (clazz != null) {
                log.info(String.format("class 已经存在: (%s): %s", clazz.getClassLoader().toString(), scriptEntryClassName));
            }
            Class defineClass = super.defineClass(scriptEntryClassName, content, 0, content.length); // 通过二进制内容,生成类
            if (defineClass != null) {
                log.info(String.format("class 加载成功 (%s): %s", defineClass.getClassLoader().toString(), scriptEntryClassName));
                super.resolveClass(defineClass); // 分解类
            }
            return defineClass;
        } catch (IOException ex) {
            log.error(String.format("class load error!", new Object[0]), ex);
        }
        return null;
    }
    
    /**
     * 读取class文件的内容
     * @param scriptEntryClassPath
     * @return
     * @throws IOException 
     */
    private byte[] readScriptEntryClassContent(String scriptEntryClassPath) throws IOException {
        int i = 0;
        String scriptEntryClassPathStr = scriptEntryClassPath; // bin/server/serverscripts/activities/ActivitieValueScript.class
        FileInputStream fis = null;
        ByteArrayOutputStream baos = null;
        try {
            byte[] buf = new byte[4096];
            fis = new FileInputStream(scriptEntryClassPathStr);
            baos = new ByteArrayOutputStream();
            
            for (;;) {
                int n = fis.read(buf);
                if (n > 0) {
                    baos.write(buf, 0, n);
                } else {
                    break;
                }
            }
//            int j = 0;
//            while (0 < (j = fis.read(buf))) {
//                baos.write(buf, 0, j);
//            }
            return baos.toByteArray(); // 读取.class文件的内容
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException ex) {
            }
            try {
                if (baos != null) {
                    baos.close();
                }
            } catch (IOException ex) {
            }
        }
    }
}
