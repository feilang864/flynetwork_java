package com.game.engine.script;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class quickScriptObj {

    private final BaseScriptEntry baseScriptEntry;
    public String evtname;
    public String className;
    public IBaseScript script;
    public long scriptID;

    quickScriptObj(BaseScriptEntry baseScriptEntry) {
        this.baseScriptEntry = baseScriptEntry;
    }

    public IBaseScript getCheckScript() {
        if (this.baseScriptEntry != null) {
            this.baseScriptEntry.getUpdateFirstEvt(this);
        }
        return this.script;
    }
}
