package com.game.engine.cache.struct;

import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class OrderedQueuePool<K, V> {

    private final ConcurrentHashMap<K, TasksQueue<V>> map = new ConcurrentHashMap();

    public TasksQueue<V> getTasksQueue(K key) {
        synchronized (this.map) {
            TasksQueue<V> queue = (TasksQueue) this.map.get(key);
            if (queue == null) {
                queue = new TasksQueue();
                this.map.put(key, queue);
            }
            return queue;
        }
    }

    public ConcurrentHashMap<K, TasksQueue<V>> getTasksQueues() {
        return this.map;
    }

    public void removeTasksQueue(K key) {
        this.map.remove(key);
    }
}
