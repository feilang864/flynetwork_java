package com.game.engine.script.manager;

import com.game.engine.script.BaseScriptEntry;
import com.game.engine.script.ScriptUtil;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 脚本管理器.单例
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class ScriptManager {

    private static final Logger log = LoggerFactory.getLogger(ScriptManager.class);
    
    public static final int SERVER_LOAD = 0;
    public static final int SERVER_RELOAD = 10;
    
    private static final ScriptManager instance = new ScriptManager();
    
    private final BaseScriptEntry baseScriptEntry;	//基础脚本类
    
    private ScriptManager() {
        baseScriptEntry = ScriptUtil.createScriptEntry("MainScript", "serverscripts/main/MainScript.java", "serverscripts.main.MainScript", "jbsrc", "bin/server", SERVER_LOAD, null);
        if (baseScriptEntry != null) {
	}else{
            log.error("脚本加载异常，终止服务器启动");
            System.exit(0);
        }
    }
    
    public static ScriptManager getInstance() {
	return instance;
    }
    
    public Map<String, String> reload() {
	Map<String, String> rethash = ScriptUtil.reloadScriptEntry("MainScript", SERVER_RELOAD);
	return rethash;
    }
    
    //===============
    
    
    
    public BaseScriptEntry getBaseScriptEntry() {
	return baseScriptEntry;
    }
    
    
//    public static void main(String[] args) {
//        ScriptManager scriptManager = ScriptManager.getInstance();
//        List<IBaseScript> evts = scriptManager.getBaseScriptEntry().getEvts(IServerSecondEventTimerScript.class.getName());
//        if (evts != null) {
//            for (IBaseScript evt : evts) {
//                ((IServerSecondEventTimerScript)evt).action(1, null);
//            }
//        }
//        Scanner sc = new Scanner(System.in);
//        if (sc.nextLine().equals("reload")) {
//            scriptManager.reload();
//        }
//        
//        evts = scriptManager.getBaseScriptEntry().getEvts(IServerSecondEventTimerScript.class.getName());
//        if (evts != null) {
//            for (IBaseScript evt : evts) {
//                ((IServerSecondEventTimerScript)evt).action(1, null);
//            }
//        }
//    }
}
