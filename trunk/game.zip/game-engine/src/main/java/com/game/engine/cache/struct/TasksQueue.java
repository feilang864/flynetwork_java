package com.game.engine.cache.struct;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
import java.util.ArrayDeque;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TasksQueue<T> {

    private final Lock lock = new ReentrantLock();
    private final ArrayDeque<T> tasksQueue = new ArrayDeque();
    
    private boolean processingCompleted = true;

    public T poll() {
        try {
            this.lock.lock();
            return this.tasksQueue.poll();
        } finally {
            this.lock.unlock();
        }
    }

    public boolean add(T value) {
        try {
            this.lock.lock();
            return this.tasksQueue.add(value);
        } finally {
            this.lock.unlock();
        }
    }

    public void clear() {
        try {
            this.lock.lock();
            this.tasksQueue.clear();
        } finally {
            this.lock.unlock();
        }
    }

    public int size() {
        return this.tasksQueue.size();
    }

    public boolean isProcessingCompleted() {
        return this.processingCompleted;
    }

    public void setProcessingCompleted(boolean processingCompleted) {
        this.processingCompleted = processingCompleted;
    }
}
