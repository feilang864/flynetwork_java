package com.game.engine.script;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 * @author Vicky
 */
public class ScriptUtil {

    private static final Logger log = LoggerFactory.getLogger(ScriptUtil.class);
    
    private static final Map<String, BaseScriptEntry> baseScriptEntrys = new ConcurrentHashMap<>();


    /**
     * 创建一个基础脚本实体
     * @param scriptEntryName               基础脚本实体名称                      "MainScript"
     * @param scriptEntrySource             基础脚本实体java源文件相对路径          "jbsrc/serverscripts/main/MainScript.java"
     * @param scriptEntryClassName          基础脚本实体完整类名                   "serverscripts.main.MainScript"
     * @param scriptEntrySrc                基础脚本实体java源文件相对"根"路径      "jbsrc"
     * @param scriptEntryCompileTo          基础脚本实体编译后.class文件存放地址    "bin/server"
     * @param scriptEntryCompileType        基础脚本实体编译类型                   SERVER_LOAD
     * @param scriptEntryCompileClassLoader 基础脚本实体编译使用的ClassLoader      null
     * @return 
     */
    public static BaseScriptEntry createScriptEntry(
            String scriptEntryName,                     // "MainScript"
            String scriptEntrySource,                   // "jbsrc/serverscripts/main/MainScript.java"
            String scriptEntryClassName,                // "serverscripts.main.MainScript"
            String scriptEntrySrc,                      // "jbsrc"
            String scriptEntryCompileTo,                // "bin/server"
            int scriptEntryCompileType,                 // SERVER_LOAD
            ClassLoader scriptEntryCompileClassLoader   // null
    ) {
        String userdir = System.getProperty("user.dir") + "\\src\\main"; // E:\NetBeansProjects\m1
        // String projectPath = PathUtils.getProjectPath(); // E:\NetBeansProjects\m1\target\classes
        if (!new File(scriptEntrySrc).exists()) {
            scriptEntrySrc = userdir + "\\" + scriptEntrySrc;
        }

        if (!new File(scriptEntrySource).exists()) {
            scriptEntrySource = scriptEntrySrc + "\\" + scriptEntrySource;
        }
        
        
        BaseScriptEntry baseScriptEntry;
        if (baseScriptEntrys.containsKey(scriptEntryName)) {
            baseScriptEntry = baseScriptEntrys.get(scriptEntryName);
            if (baseScriptEntry != null) {
                Map localHashMap1 = baseScriptEntry.loadScript(scriptEntryCompileClassLoader, scriptEntryCompileType, scriptEntrySource, scriptEntryClassName, scriptEntrySrc, scriptEntryCompileTo);
                if (localHashMap1.get("code").equals("0")) {
                    log.info(String.format("script(%s) init ok (code:%s):%s", scriptEntryClassName, localHashMap1.get("code"), localHashMap1.get("msg")));
                } else {
                    log.info(String.format("script(%s) init error (code:%s):%s", scriptEntryClassName, localHashMap1.get("code"), localHashMap1.get("msg")));
                    baseScriptEntry = null;
                    return baseScriptEntry;
                }
            }
        } else {
            try {
                baseScriptEntry = new BaseScriptEntry(scriptEntryName, scriptEntrySource, scriptEntryClassName, scriptEntrySrc, scriptEntryCompileTo, scriptEntryCompileType, scriptEntryCompileClassLoader); // 初始化BaseScriptEntry
            } catch (Exception ex) {
                log.error(String.format("script(%s) init error", scriptEntryClassName), ex);
                baseScriptEntry = null;
                return baseScriptEntry;
            }
            if (baseScriptEntry != null) {
                Map result = baseScriptEntry.loadScript(scriptEntryCompileType); // code = 0, msg = ""
                if (result.get("code").equals("0")) {
                    log.info(String.format("脚本(%s) 初始化完毕 (code:%s) : %s", scriptEntryClassName, result.get("code"), result.get("msg")));
                    baseScriptEntrys.put(scriptEntryName, baseScriptEntry);
                } else {
                    log.error(String.format("脚本(%s) 初始化错误 (code:%s):%s", scriptEntryClassName, result.get("code"), result.get("msg")));
                    baseScriptEntry = null;
                    return baseScriptEntry;
                }
            }
        }
        return baseScriptEntry;
    }

    public static BaseScriptEntry findScriptEntry(String scriptEntryName) {
        return baseScriptEntrys.get(scriptEntryName);
    }

    public static BaseScriptEntry removeScriptEntry(String scriptEntryName) {
        return removeScriptEntry(scriptEntryName, false, 0);
    }

    public static BaseScriptEntry removeScriptEntry(String scriptEntryName, boolean isClear, int scriptEntryCompileType) {
        BaseScriptEntry localBaseScriptEntry = null;
        if (baseScriptEntrys.containsKey(scriptEntryName)) {
            localBaseScriptEntry = baseScriptEntrys.get(scriptEntryName);
            baseScriptEntrys.remove(scriptEntryName);
            if (isClear) {
                localBaseScriptEntry.clear(scriptEntryCompileType);
            }
        }
        return localBaseScriptEntry;
    }

    public static Map reloadScriptEntry(String scriptEntryName, int scriptEntryCompileType) {
        Map result = null;
        BaseScriptEntry baseScriptEntry = baseScriptEntrys.get(scriptEntryName);
        if (baseScriptEntry != null) {
            result = baseScriptEntry.loadScript(scriptEntryCompileType);
            if (result.get("code").equals("0")) {
                log.info(String.format("脚本(%s) 重新加载 成功 (%s):%s", baseScriptEntry.getName(), result.get("code"), result.get("msg")));
            } else {
                log.error(String.format("脚本(%s) 重新加载 失败 (%s):%s", baseScriptEntry.getName(), result.get("code"), result.get("msg")));
            }
        }
        return result;
    }

    public static boolean require(BaseScriptEntry baseScriptEntry, IBaseScript baseScript, int scriptEntryCompileType) {
        if ((baseScriptEntry != null) && (baseScript != null)) {
            return baseScriptEntry.require(baseScript, scriptEntryCompileType);
        }
        return false;
    }

    public static boolean require_once(BaseScriptEntry baseScriptEntry, IBaseScript baseScript, int scriptEntryCompileType) {
        if (baseScriptEntry != null && baseScript != null) {
            return baseScriptEntry.require_once(baseScript, scriptEntryCompileType);
        }
        return false;
    }

    public static boolean clear_require(BaseScriptEntry baseScriptEntry, int scriptEntryCompileType) {
        if (baseScriptEntry != null) {
            return baseScriptEntry.clear_require(scriptEntryCompileType);
        }
        return false;
    }

}
