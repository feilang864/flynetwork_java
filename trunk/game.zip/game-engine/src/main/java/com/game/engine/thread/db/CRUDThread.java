package com.game.engine.thread.db;

import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 用于处理数据库CRUD的单独线程.可以使用回调
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 * @param <T> 数据类型,应该是PO
 */
public class CRUDThread<T> extends Thread implements Executor {

    // 日志
    private static final Logger log = LoggerFactory.getLogger(CRUDThread.class);

    // 最大缓存
    private static final int MAX_SIZE = 3000;

    //命令执行队列
    private final LinkedBlockingQueue<CRUDCommand<T>> queue = new LinkedBlockingQueue<>();

    //线程名称
    private final String threadName;

    //运行标志
    private boolean stop;

    public CRUDThread(String threadName) {
        super(threadName);
        this.threadName = threadName;
    }

    @Override
    public void run() {
        stop = false;

        while (!stop) {
            CRUDCommand<T> command = queue.poll();
            if (command == null) {
                try {
                    synchronized (this) {
                        wait();
                    }
                } catch (InterruptedException e) {
                    log.error("CURDThread " + threadName + " Wait Exception:", e);
                }
            } else {
                if (queue.size() <= MAX_SIZE) {
                    command.run();
                } else {
                    // TODO 直接将缓存区的数据,写入文本中,然后清空缓存.
                    throw new RuntimeException("CURDThread " + threadName + " 缓存数" + queue.size() + "超过了" + MAX_SIZE + "的上限了:");
                }
            }
        }
    }

    public void stop(boolean flag) {
        stop = flag;
        try {
            synchronized (this) {
                notify();
            }
        } catch (Exception e) {
            log.error("数据库读取操作线程 " + threadName + " stop Exception:", e);
        }
    }

    @Override
    public void execute(Runnable command) {
        try {
            CRUDCommand<T> jsonClone = ((CRUDCommand<T>) command).jsonClone();
            queue.add(jsonClone);

            synchronized (this) {
                notify();
            }
        } catch (Exception e) {
            log.error("数据库读取操作线程" + threadName + " add Exception:", e);
        }
    }

//    public static void main(String[] args) {
//        class Player {
//
//            private String name;
//            private int lv;
//
//            public String getName() {
//                return name;
//            }
//
//            public void setName(String name) {
//                this.name = name;
//            }
//
//            public int getLv() {
//                return lv;
//            }
//
//            public void setLv(int lv) {
//                this.lv = lv;
//            }
//        }
//
//        class User {
//
//            private String username;
//            private String password;
//            private int age;
//            private Player player;
//
//            public String getUsername() {
//                return username;
//            }
//
//            public void setUsername(String username) {
//                this.username = username;
//            }
//
//            public String getPassword() {
//                return password;
//            }
//
//            public void setPassword(String password) {
//                this.password = password;
//            }
//
//            public int getAge() {
//                return age;
//            }
//
//            public void setAge(int age) {
//                this.age = age;
//            }
//
//            public Player getPlayer() {
//                return player;
//            }
//
//            public void setPlayer(Player player) {
//                this.player = player;
//            }
//
//            protected Object myClone() {
//                String toJSONString = JSON.toJSONString(this, new SerializerFeature[]{SerializerFeature.WriteClassName, SerializerFeature.DisableCircularReferenceDetect});
//                return JSON.parseObject(toJSONString, this.getClass());
//            }
//        }
//
//        CRUDCommand.ICreateCallBack crateCallBack = new CRUDCommand.ICreateCallBack() {
//            @Override
//            public void createSuccessCallBack(Object result) {
//                System.out.println("create User Success" + result);
//            }
//            @Override
//            public void createFailCallBack(Object result) {
//                System.out.println("create User Fail" + result);
//            }
//        };
//        
//        CRUDCommand.ICreateCallBack crateCallBack2 = new CRUDCommand.ICreateCallBack() {
//            @Override
//            public void createSuccessCallBack(Object result) {
//                System.out.println("create Player Success" + result);
//            }
//            @Override
//            public void createFailCallBack(Object result) {
//                System.out.println("create Player Fail" + result);
//            }
//        };
//
//        CRUDThread<User> crudThread = new CRUDThread<User>("CRUDUSER");
//        crudThread.start();
//
//        for (int i = 0; i < 10; i++) {
//
//            Player p = new Player();
//            p.setName("jack");
//            p.setLv(77);
//
//            User u = new User();
//            u.setUsername("289997171");
//            u.setPassword("123456");
//            u.setAge(27);
//            u.setPlayer(p);
//
//            CRUDCommand.registerCreateCallBack("CRUD_USER", crateCallBack);
//            CRUDCommand.registerCreateCallBack("CRUD_PLAYER", crateCallBack2);
//            
//            CRUDCommand<User> command = new CRUDCommand<>(
//                    "CRUD_USER",
//                    CRUDCommand.CRUD.CREAT,
//                    u
//            );
//            
//            CRUDCommand<Player> command2 = new CRUDCommand<>(
//                    "CRUD_PLAYER",
//                    CRUDCommand.CRUD.CREAT,
//                    p
//            );
//            crudThread.execute(command);
//            crudThread.execute(command2);
//        }
//    }
}
