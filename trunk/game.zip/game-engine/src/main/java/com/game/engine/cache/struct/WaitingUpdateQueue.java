package com.game.engine.cache.struct;

import java.io.Serializable;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.apache.mina.util.ConcurrentHashSet;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 * @param <V>
 */
public class WaitingUpdateQueue<V>
        implements Serializable {

    private static final long serialVersionUID = -6020192336030291965L;
    private final ConcurrentLinkedQueue<V> queue = new ConcurrentLinkedQueue();
    private final ConcurrentHashSet<V> set = new ConcurrentHashSet();

    public void add(V value) {
        if (!this.set.contains(value)) {
            this.set.add(value);

            this.queue.add(value);
        }
    }

    public V poll() {
        V value = this.queue.poll();
        if (value != null) {
            this.set.remove(value);
        }
        return value;
    }

    public boolean contains(V value) {
        return this.set.contains(value);
    }

    public void remove(V value) {
        this.set.remove(value);
        this.queue.remove(value);
    }
}
