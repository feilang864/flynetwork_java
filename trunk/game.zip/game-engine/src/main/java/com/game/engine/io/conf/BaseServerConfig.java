package com.game.engine.io.conf;

import java.util.Objects;
import org.simpleframework.xml.Element;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public abstract class BaseServerConfig {

    // 这3个是必须设置的
    // 服务器标识
    @Element(required = true)
    protected int id;
    
    // 服务器名称
    @Element(required = true)
    protected String name;
    
    // 服务器渠道
    @Element(required = true)
    protected String web;
    
    
    // ========================================================
    
    // 配置允许读取数据包的最大长度
    @Element(required = false)
    protected int maxReadSize = 10240; // 10K
    
    // 配置允许写入数据包的最大长度
    @Element(required = false)
    protected int maxWriteSize = 1048576; // 1024 * 1024
    
    // 配置允许最大尝试次数
    @Element(required = false)
    protected int maxTryCount = 30;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWeb() {
        return this.web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public int getMaxReadSize() {
        return maxReadSize;
    }

    @Deprecated
    public void setMaxReadSize(int maxReadSize) {
        this.maxReadSize = maxReadSize;
    }

    public int getMaxWriteSize() {
        return maxWriteSize;
    }

    @Deprecated
    public void setMaxWriteSize(int maxWriteSize) {
        this.maxWriteSize = maxWriteSize;
    }

    public int getMaxTryCount() {
        return maxTryCount;
    }

    @Deprecated
    public void setMaxTryCount(int maxTryCount) {
        this.maxTryCount = maxTryCount;
    }

    // eq id + web
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + this.id;
        hash = 41 * hash + Objects.hashCode(this.web);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BaseServerConfig other = (BaseServerConfig) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.web, other.web)) {
            return false;
        }
        return true;
    }
    
    
}
