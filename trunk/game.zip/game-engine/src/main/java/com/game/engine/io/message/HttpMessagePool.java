package com.game.engine.io.message;

import com.game.engine.io.commmand.IHandler;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class HttpMessagePool implements IMessagePool<String> {
    
    private static final Logger log = LoggerFactory.getLogger(HttpMessagePool.class);

    private final Map<String, HttpMessageBean> messagebeans = new HashMap<>();
    
    private final Map<Integer, Executor> syncHandlers = new HashMap<>();
    
    /**
     * 注册线程模型
     * @param threadModel 线程模型ID
     * @param executor 线程模型处理器
     */
    @Override
    public void register(int threadModel, Executor executor) {
        if (executor instanceof Thread) {
            if (!((Thread)executor).isAlive()) {
                ((Thread)executor).start();
                log.warn(executor + " Thread is running ...");
            }
        }
        syncHandlers.put(threadModel, executor);
    }
    
     /**
     * 获得线程模型对应的处理器
     * @param threadModel 线程模型ID
     * @return 线程模型处理器
     */
    @Override
    public Executor getExecutor(int threadModel) {
        return syncHandlers.get(threadModel);
    }
    
    /**
     * 注册协议
     * @param content
     * @param handlerClass
     * @param threadModel
     */
    public void register(String content, Class<? extends IHandler> handlerClass, int threadModel) {
        messagebeans.put(content, new HttpMessageBean(handlerClass, threadModel));
    }

    @Override
    public HttpMessageBean getMessageBean(String content) {
        return messagebeans.get(content);
    }
}
