//package com.game.engine.thread.map;
//
//import com.game.engine.thread.ServerThread;
//import com.game.engine.thread.map.conf.MapConfig;
//import com.game.engine.thread.map.conf.MapConfigs;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * 地图线服务线程
// * @author Vicky
// * @mail   eclipser@163.com
// * @phone  13618074943
// * @author Vicky
// */
//public class MapServerImpl extends MapServer {
//
//    private static final Logger log = LoggerFactory.getLogger(MapServerImpl.class);
//    // 创建时间
//    private final long createTime;
//    // 地图管理器
//    private final IMapManager mapManager;
//    // 是否删除
//    private boolean delete = false;
//    
//    public MapServerImpl(String name, long zoneId, int zoneModelId, MapConfigs mapConfigs,IMapManager mapManager, String threadConfig) {
//        super(name, zoneId, zoneModelId, mapConfigs, threadConfig);
//        this.mapManager = mapManager;
//        this.createTime = System.currentTimeMillis();
//    }
//
//    public MapServerImpl(String name, long zoneId, int zoneModelId, MapConfigs mapConfigs,IMapManager mapManager) {
//        super(name, zoneId, zoneModelId, mapConfigs);
//        this.mapManager = mapManager;
//        this.createTime = System.currentTimeMillis();
//    }
//
//    @Override
//    protected void init() {
//        log.error(this.getName() + ":" + this.getZoneModelId() + ":" + this.getZoneId() + ":MServer.init:" + this.getMapConfigs().size());
//        for (MapConfig config : this.getMapConfigs()) {
//            //初始化地图
//            // config.setMapId(mapManager.initMaps(config.getServerId(), config.getLineId(), config.getMapModelId(), this.getZoneId(), this.getZoneModelId()));
//            
//            // TODO 进行以下修改
//            //初始化怪物
////            long initMonsterbegintime = System.currentTimeMillis();
////            ManagerPool.monsterManager.initNoCommonMonster(config.getServerId(), config.getLineId(), config.getMapId(), config.getMapModelId());
////            long initMonsterexetime = System.currentTimeMillis() - initMonsterbegintime;
////            log.error(this.getName() + ":" + this.getZoneModelId() + ":" + this.getZoneId() + ":initmonstertime:" + initMonsterexetime);
////            if (initMonsterexetime > maxinitmonstertime) {
////                maxinitmonstertime = initMonsterexetime;
////                log.error(this.getName() + ":" + this.getZoneModelId() + ":" + this.getZoneId() + ":initmonstermaxtime:" + maxinitmonstertime);
////            }
//            // 初始化NPC
////            ManagerPool.npcManager.initSceneNpc(config.getServerId(), config.getLineId(), config.getMapId(), config.getMapModelId());
//        }
//    }
//
//    @Override
//    public void run() {
//        try {
//            log.error(this.getName() + ":" + this.getZoneModelId() + ":" + this.getZoneId() + ":MServer.run");
//            super.run();
//            //添加服务器消息执行检查
//            this.thread_pool.get(MapServer.MAINTHREAD).addCommandFitler(new HandlerFilter(this.getMapConfigs()));
//            log.error(this.getName() + ":" + this.getZoneModelId() + ":" + this.getZoneId() + ":MServer.run.addTimerEvent:" + this.getMapConfigs().size());
//            for (int i = 0; i < this.getMapConfigs().size(); i++) {
//
//                MapConfig config = this.getMapConfigs().get(i);
////                //同步怪物信息
////                //ManagerPool.monsterManager.syncMonster(config.getServerId(), config.getLineId(), config.getMapId());
////                //初始化人物移动定时 龙纹战域没有了
////                //this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PlayerStepTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //初始化人物走路 龙纹战域没有了
////                //this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PlayerRunTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //初始化怪物移动定时
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MonsterStepTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //初始化怪物AI定时
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MonsterAiTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //初始化怪物攻击定时
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MonsterAttackTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //初始化怪物复活定时
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MonsterReviveTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //包裹 仓库自动开格定时
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new BackPackTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //定时格挡 龙纹战域没有格挡
////                //this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PlayerBlockTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //玩家心跳
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PlayerHeartTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //怪物心跳
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MonsterHeartTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //地图中元素的统计
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MapCountTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //地面持续技能计时器
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MapContinuedSkillTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //玩家BUFF计时器
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PlayerBuffTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //怪物BUFF计时器
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MonsterBuffTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //定时计算宠物Buff
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PetBuffTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //宠物心跳AI
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PetHeartTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //宠物攻击
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PetAttackTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //宠物移动定时
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PetStepTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //宠物AI
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PetAiTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //掉落物品计时器
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new DropClearTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //测试坐标同步
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PlayerPositionTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //任务
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new SupperFinshTaskTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //定时刷场景NPC和怪物
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new SceneobjTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //地图心跳
////                this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MapHeartTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //测试坐标同步
////                //this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new MonsterPositionTimer(this.getServerId(), this.getLineId(), this.getMapId()));
////                //this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new PetPositionTimer(config.getServerId(), config.getLineId(), config.getMapId()));
////                //定时公告
////                //this.thread_pool.get(MapServer.MAINTHREAD).addTimerEvent(new BulletinTimer(config.getServerId(), config.getLineId(), config.getMapId()));
//            }
//        } catch (Exception e) {
//            log.error(this.getName() + ":" + this.getZoneModelId() + ":" + this.getZoneId() + ":MServer.run:" + this.getMapConfigs().size(), e);
//        }
//    }
//
//    @Override
//    public void stop(boolean flag) {
//        super.stop(flag);
//        if (flag) {
//            for (int i = 0; i < this.getMapConfigs().size(); i++) {
//                MapConfig config = this.getMapConfigs().get(i);
//                //移除怪物
//                // ManagerPool.monsterManager.removeMonster(config.getServerId(), config.getLineId(), config.getMapId());
//                //移除地图		
//                this.mapManager.removeMap(config.getServerId(), config.getLineId(), config.getMapId());
//            }
//        }
//    }
//
//    public ServerThread getMainThread() {
//        return this.thread_pool.get(MapServer.MAINTHREAD);
//    }
//
//    public long getCreateTime() {
//        return createTime;
//    }
//    
//    public boolean isDelete() {
//        return delete;
//    }
//
//    public void setDelete(boolean delete) {
//        this.delete = delete;
//    }
//    
////    /**
////     * 所有在地图中角色 执行任务
////     *
////     * @param run
////     */
////    public void allPlayerRun(final PlayerRunable run) {
////
////        ServerThread thread = thread_pool.get(Server.MAINTHREAD);
////        thread.addCommand(new ICommand() {
////
////            @Override
////            public void action() {
////                Map map = MapManager.getInstance().getMap(getServerId(), getLineId(), getMapId());
////                HashMap<Long, Player> players = map.getPlayers();
////                if (players != null && players.size() > 0) {
////                    List<Long> keys = new ArrayList<Long>();
////                    keys.addAll(players.keySet());
////                    for (Long key : keys) {
////                        Player player = players.get(key);
////                        if (player != null) {
////                            run.run(player);
////                        }
////                    }
////                }
////            }
////
////            public Object clone() throws CloneNotSupportedException {
////                return super.clone();
////            }
////        });
////    }
//}
