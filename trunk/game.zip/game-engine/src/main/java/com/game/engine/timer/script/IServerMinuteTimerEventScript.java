package com.game.engine.timer.script;

import com.game.engine.script.IBaseScript;

/**
 * 服务器每分钟心跳事件
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public interface IServerMinuteTimerEventScript extends IBaseScript {

    void action(int serverId, String serverWeb);
}
