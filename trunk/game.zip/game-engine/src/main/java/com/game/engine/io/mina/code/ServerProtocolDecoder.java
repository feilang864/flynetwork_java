package com.game.engine.io.mina.code;

import com.game.engine.io.conf.BaseServerConfig;
import com.game.engine.io.mina.utils.SessionUtil;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @param <T>
 */
public class ServerProtocolDecoder<T extends BaseServerConfig>
        implements ProtocolDecoder {

    private static final Logger log = LoggerFactory.getLogger(ServerProtocolDecoder.class);

    private static final String CONTEXT = "context";
    private static final String START_TIME = "start_time";
    private static final String RECEIVE_COUNT = "receive_count";

//    private static final int MAX_SIZE = 10240;
//    private static final int MAX_COUNT = 30;
    
    private final T config;
    
    public ServerProtocolDecoder(T config) {
        this.config = config;
    }

    // 解码
    @Override
    public void decode(IoSession session, IoBuffer buff, ProtocolDecoderOutput out)
            throws Exception {
        // log.error("\t decode " + Thread.currentThread().toString());
        long startTime = 0L;
        if (session.containsAttribute(START_TIME)) {
            startTime = (long) session.getAttribute(START_TIME);
        }
        int count = 0;
        if (session.containsAttribute(RECEIVE_COUNT)) {
            count = (int) session.getAttribute(RECEIVE_COUNT);
        }
        if (System.currentTimeMillis() - startTime > 1000L) {
            if (count > 10) {
                log.error(session + " --> 消息过于频繁:" + count + "\t" + session);
            }
            startTime = System.currentTimeMillis();
            count = 0;
        }
        count++;
        if (count > config.getMaxTryCount()) { // MAX_COUNT
            SessionUtil.close(session, "--> 消息长度过大:%d -->关闭链接-->buf.remaining():%d", count, buff.remaining());
            return;
        }

        session.setAttribute(START_TIME, startTime);
        session.setAttribute(RECEIVE_COUNT, count);

        ServerContext context = null;
        if (session.getAttribute(CONTEXT) != null) {
            context = (ServerContext) session.getAttribute(CONTEXT);
        }
        if (context == null) {
            context = new ServerContext();
            session.setAttribute(CONTEXT, context);
        }

        IoBuffer contextBuff = context.getBuff();
        contextBuff.put(buff);

        for (;;) {
            contextBuff.flip();
            if (contextBuff.remaining() < 4) {
                contextBuff.compact();
                break;
            }
            int length = contextBuff.getInt();
            if (length > config.getMaxReadSize()) { // MAX_SIZE
                SessionUtil.close(session, "--> 数据包长度超过限制:%d -->close-->buf:%d(%s)", length, buff.remaining(), buff.toString());
                return;
            }
            if (contextBuff.remaining() < length) {
                contextBuff.rewind();
                contextBuff.compact();
                break;
            }
            byte[] bytes = new byte[length];
            contextBuff.get(bytes);

            out.write(bytes);
            if (contextBuff.remaining() == 0) {
                contextBuff.clear();
                break;
            }
            contextBuff.compact();
        }
    }

    @Override
    public void dispose(IoSession session)
            throws Exception {
        if (session.getAttribute(CONTEXT) != null) {
            session.removeAttribute(CONTEXT);
        }
    }

    /**
     * 可以用于处理在 IoSession 关闭时剩余的未读取数据
     *
     * @param session
     * @param out
     * @throws Exception
     */
    @Override
    public void finishDecode(IoSession session, ProtocolDecoderOutput out)
            throws Exception {
    }
}
