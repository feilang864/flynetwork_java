package com.game.engine.thread.executor;

import com.game.engine.cache.AbstractWork;
import com.game.engine.cache.struct.OrderedQueuePool;
import com.game.engine.cache.struct.TasksQueue;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class OrderedQueuePoolExecutor
        extends ThreadPoolExecutor {

    private static final Logger log = LoggerFactory.getLogger(OrderedQueuePoolExecutor.class);
    
    private final OrderedQueuePool<Long, AbstractWork> pool = new OrderedQueuePool<>();
    private final String name;
    private final int corePoolSize;
    private final int maxQueueSize;

    public OrderedQueuePoolExecutor(String name, int corePoolSize, int maxPoolSize, long keepAliveTime) {
        super(corePoolSize, maxPoolSize, keepAliveTime, TimeUnit.SECONDS, new LinkedBlockingQueue());
        this.name = name;
        this.corePoolSize = corePoolSize;
        this.maxQueueSize = maxPoolSize;
    }

    public OrderedQueuePoolExecutor(int corePoolSize) {
        this("queue-pool", corePoolSize, corePoolSize * 2, 10000);
    }

    public boolean addTask(long key, AbstractWork task) {
        Long newkey = key % this.corePoolSize;
        TasksQueue<AbstractWork> queue = this.pool.getTasksQueue(newkey);
        boolean run = false;
        boolean result = false;
        synchronized (queue) {
            if ((this.maxQueueSize > 0)
                    && (queue.size() > this.maxQueueSize)) {
                log.error("OrderedQueuePoolExecutor " + this.name + "(" + newkey + ")" + "超过限制");
                queue.clear();
            }
            result = queue.add(task);
            if (result) {
                task.setTasksQueue(queue);
                if (queue.isProcessingCompleted()) {
                    queue.setProcessingCompleted(false);
                    run = true;
                }
            } else {
                log.error("OrderedQueuePoolExecutor 添加任务失败");
            }
        }
        if (run) {
            execute((Runnable) queue.poll());
        }
        return result;
    }

    @Override
    protected void afterExecute(Runnable r, Throwable t) {
        super.afterExecute(r, t);

        AbstractWork work = (AbstractWork) r;
        TasksQueue<AbstractWork> queue = work.getTasksQueue();
        if (queue != null) {
            AbstractWork afterWork = null;
            synchronized (queue) {
                afterWork = (AbstractWork) queue.poll();
                if (afterWork == null) {
                    queue.setProcessingCompleted(true);
                }
            }
            if (afterWork != null) {
                execute(afterWork);
            }
        } else {
            log.error("OrderedQueuePoolExecutor 获取 queue 失败");
        }
    }

    public int getTaskCounts() {
        int count = super.getActiveCount();

        Iterator<Map.Entry<Long, TasksQueue<AbstractWork>>> iter = this.pool.getTasksQueues().entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<Long, TasksQueue<AbstractWork>> entry = (Map.Entry) iter.next();
            TasksQueue<AbstractWork> tasksQueue = (TasksQueue) entry.getValue();

            count += tasksQueue.size();
        }
        return count;
    }
}
