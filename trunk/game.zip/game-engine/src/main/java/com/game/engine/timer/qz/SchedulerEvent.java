package com.game.engine.timer.qz;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public abstract class SchedulerEvent implements Runnable {

}

