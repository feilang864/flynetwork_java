package com.game.engine.script;

import java.net.URI;
import javax.tools.JavaFileObject;
import javax.tools.SimpleJavaFileObject;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
class BaseScriptJavaFileObject extends SimpleJavaFileObject {

    private final String sourceContent;

    public BaseScriptJavaFileObject(BaseScriptEntry baseScriptEntry, String scriptEntryClassName, String sourceContent) {
        super(URI.create("string:///" + scriptEntryClassName.replace('.', '/') + JavaFileObject.Kind.SOURCE.extension), JavaFileObject.Kind.SOURCE);
        this.sourceContent = sourceContent;
    }

    @Override
    public CharSequence getCharContent(boolean ignoreEncodingErrors) {
        return this.sourceContent;
    }
}
