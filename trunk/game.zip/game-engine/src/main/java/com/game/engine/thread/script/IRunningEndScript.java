package com.game.engine.thread.script;

import com.game.engine.script.IBaseScript;
import com.game.engine.thread.RunningThread;

/**
 * 寻路结束后执行
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public interface IRunningEndScript extends IBaseScript {

    void action(RunningThread.RunningInfo runningInfo);
}
