package com.game.engine.thread.map.conf;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 所有地图总汇
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class MapsConfig {
    
    private static final Logger log = LoggerFactory.getLogger(MapsConfig.class);
    
    private static final DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    //国家索引 key为国家id（0-为公共区） value为服务器Id
    private Map<Integer, Integer> countrys = new ConcurrentHashMap<>();
    //服务器索引 key为服务器Id value为国家id（0-为公共区）
    private Map<Integer, Integer> servers = new ConcurrentHashMap<>();
    //服务器索引 key为服务器Id value为服务器开服时间
    private Map<Integer, Date> serverTimes = new ConcurrentHashMap<>();
    
    public Map<Integer, Integer> getCountrys() {
        return countrys;
    }

    public void setCountrys(Map<Integer, Integer> countrys) {
        this.countrys = countrys;
    }

    public Map<Integer, Integer> getServers() {
        return servers;
    }

    public void setServers(Map<Integer, Integer> servers) {
        this.servers = servers;
    }

    public Map<Integer, Date> getServerTimes() {
        return serverTimes;
    }

    public void setServerTimes(Map<Integer, Date> serverTimes) {
        this.serverTimes = serverTimes;
    }
    
}
