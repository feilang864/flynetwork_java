package com.game.engine.thread.map;

import com.game.engine.thread.map.conf.MapInfo;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public interface IMapManager {

    /**
     * 获得地图信息
     * @param serverID 服务器ID
     * @param lineID 线路ID
     * @param mapID 地图ID
     * @return 
     */
    MapInfo getMap(int serverID, int lineID, long mapID);
    
    /**
     * 删除地图
     * @param serverID 服务器ID
     * @param lineID 线路ID
     * @param mapID 地图ID
     */
    void removeMap(int serverID, int lineID, long mapID);

    /**
     * 初始化地图
     * @param serverId 服务器ID
     * @param lineId 线路ID
     * @param mapModelId 地图模版ID
     * @param zoneId 副本ID
     * @param zoneModelId 副本模版ID
     * @return 
     */
    public long initMaps(int serverId, int lineId, int mapModelId, long zoneId, int zoneModelId);
}
