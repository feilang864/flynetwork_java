package com.game.engine.io.mina.impl;

import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.io.mina.code.HttpServerProtocolCodecFactory;
import com.game.engine.io.mina.handler.HttpServerProtocolHandler;
import java.io.IOException;
import java.net.InetSocketAddress;
import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.executor.ExecutorFilter;
import org.apache.mina.filter.executor.OrderedThreadPoolExecutor;
import org.apache.mina.transport.socket.SocketSessionConfig;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 * @author Vicky
 */
public class MinaHttpServer implements Runnable {
    
    private static final Logger log = LoggerFactory.getLogger(MinaHttpServer.class);

    private final MinaServerConfig minaServerConfig;

    private final NioSocketAcceptor acceptor;

    private final HttpServerProtocolHandler ioHandler;
    
    protected boolean isRunning = false;

    public MinaHttpServer(MinaServerConfig minaServerConfig, HttpServerProtocolHandler ioHandler) {
        this.minaServerConfig = minaServerConfig;
        this.ioHandler = ioHandler;

        acceptor = new NioSocketAcceptor();
    }

    @Override
    public void run() {
        synchronized (this) {
            if (!isRunning) {
                isRunning = true;
                new Thread(new ConnectServer()).start();
            }
        }
    }
    
    public void stop() {
        synchronized (this) {
            if (!isRunning) {
                log.info("HttpServer " + minaServerConfig.getName() + "is already stoped.");
                return;
            }
            isRunning = false;
            try {
                acceptor.unbind();
                acceptor.dispose();
                log.info("Server is stoped.");
            } catch (Exception ex) {
                log.error("", ex);
            }
        }
    }

    private class ConnectServer
            implements Runnable {

        private final Logger log = LoggerFactory.getLogger(ConnectServer.class);

        @Override
        public void run() {
            DefaultIoFilterChainBuilder chain = acceptor.getFilterChain();
            // 编码过滤器
            chain.addLast("codec", new ProtocolCodecFilter(new HttpServerProtocolCodecFactory()));
            // 线程队列池
            OrderedThreadPoolExecutor threadpool = new OrderedThreadPoolExecutor(minaServerConfig.getOrderedThreadPoolExecutorSize());
            chain.addLast("threadPool", new ExecutorFilter(threadpool));

            acceptor.setReuseAddress(minaServerConfig.isReuseAddress()); // 允许地址重用

            // 配置SessionConfig
            SocketSessionConfig sc = acceptor.getSessionConfig();
            sc.setReuseAddress(minaServerConfig.isReuseAddress());
            sc.setReceiveBufferSize(minaServerConfig.getReceiveBufferSize());
            sc.setSendBufferSize(minaServerConfig.getSendBufferSize());
            sc.setTcpNoDelay(minaServerConfig.isTcpNoDelay());
            sc.setSoLinger(minaServerConfig.getSoLinger());
            sc.setIdleTime(IdleStatus.READER_IDLE, minaServerConfig.getReaderIdleTime());
            sc.setIdleTime(IdleStatus.WRITER_IDLE, minaServerConfig.getWriterIdleTime());

            acceptor.setHandler(ioHandler);

            try {
                acceptor.bind(new InetSocketAddress(minaServerConfig.getPort()));
                this.log.info("Mina Server " + minaServerConfig.getName() + " Start At Port " + minaServerConfig.getPort());
            } catch (IOException e) {
                this.log.error("Mina Server " + minaServerConfig.getName() + " Port " + minaServerConfig.getPort() + "Already Use:" + e.getMessage());
                System.exit(1);
            }
        }
    }

}
