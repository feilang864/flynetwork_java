package com.game.engine.io.message;

import java.util.concurrent.Executor;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public interface IMessagePool<T> {

    /**
     * 获得线程模型对应的处理器
     * @param threadModel 线程模型ID
     * @return 线程模型处理器
     */
    Executor getExecutor(int threadModel);

    IMessageBean getMessageBean(T key);

    /**
     * 注册线程模型
     * @param threadModel 线程模型ID
     * @param executor 线程模型处理器
     */
    void register(int threadModel, Executor executor);

}
