package com.game.engine.thread;

import com.game.engine.script.IBaseScript;
import com.game.engine.script.manager.ScriptManager;
import com.game.engine.thread.script.IRunningEndScript;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 寻路线程
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class RunningThread
        extends Thread {

    private static final Logger log = LoggerFactory.getLogger(RunningThread.class);

    // 线程名称
    private final String threadName;
    // 线程心跳间隔
    private final long heart;

    private float step;

    // 线程处理命令队列
    private final Map<Long, RunningInfo> runningInfos = new ConcurrentHashMap<>();

    // 取消移动
    private final Set<Long> cancels = Collections.synchronizedSet(new HashSet<Long>());

    private final LinkedBlockingQueue<RunningInfo> command_queue = new LinkedBlockingQueue<>();

    private boolean stop;

    private Timer timer;
    private TimerTask timerTask;

    private boolean processingCompleted = false;

    public RunningThread(ThreadGroup group, String threadName, long heart) {
        super(group, threadName);
        this.threadName = threadName;
        this.heart = heart;

        if (this.heart > 0) {
            this.step = (float) (((double) heart) / 1000.0);
            this.timer = new Timer();
            this.timerTask = new TimerTask() {

                @Override
                public void run() {

                    if (RunningThread.this.runningInfos.isEmpty()) {
                        return;
                    }

                    long begin = System.currentTimeMillis();

                    // 未完成寻路的玩家
                    Set<RunningInfo> notOvers = new HashSet<>(RunningThread.this.runningInfos.values());
                    // 已经完成寻路的玩家
                    Set<RunningInfo> overs = new HashSet<>();

                    for (RunningInfo runningInfo : notOvers) {
                        if (RunningThread.this.stop) {
                            log.warn("地图寻路定时器停止了");
                            return;
                        }
                        float x = 0;
                        if (runningInfo.direction.x != 0) {
                            x = runningInfo.direction.x * runningInfo.speed * RunningThread.this.step;
                        }
                        // float y = runningInfo.direction.y * runningInfo.speed * RunningThread.this.step;  非3D无需计算y坐标
                        float z = 0;
                        if (runningInfo.direction.z != 0) {
                            z = runningInfo.direction.z * runningInfo.speed * RunningThread.this.step; // 实际计算的z为二维的y
                        }
//                        System.out.println("当前坐标:" + runningInfo.curX + "  " + runningInfo.curY);
                        runningInfo.curX += x;
                        runningInfo.curY += z;
                        runningInfo.lastRunTime += RunningThread.this.heart;

                        // TODO 判断是否到达目标点
                        boolean isArrived = false;

                        if (runningInfo.direction.x == 0) {
                            if ((runningInfo.direction.z > 0 && runningInfo.curY >= runningInfo.y2) || (runningInfo.direction.z < 0 && runningInfo.curY <= runningInfo.y2)) { // Y坐标已到达
                                isArrived = true;
                            }
                        } else if ((runningInfo.direction.x > 0 && runningInfo.curX >= runningInfo.x2) || (runningInfo.direction.x < 0 && runningInfo.curX <= runningInfo.x2)) { // X坐标已到达
                            if (runningInfo.direction.z == 0) {
                                isArrived = true;
                            } else if ((runningInfo.direction.z > 0 && runningInfo.curY >= runningInfo.y2) || (runningInfo.direction.z < 0 && runningInfo.curY <= runningInfo.y2)) { // Y坐标已到达
                                isArrived = true;
                            }
                        }

                        // 添加到目标点已到达
                        if (isArrived) {
                            RunningInfo removed = RunningThread.this.runningInfos.remove(runningInfo.playerid);
                            if (removed != null) {
                                removed.curX = removed.x2;
                                removed.curY = removed.y2;
                                overs.add(removed);
                                System.out.println("寻路完毕,到达目标点(" + runningInfo.x1 + " " + runningInfo.y1 + ")  (" + runningInfo.x2 + " " + runningInfo.x2 + ") 共耗时" + (runningInfo.lastRunTime - runningInfo.beginTime) + " ms");
                            }
                        }
                    }

                    // 删除取消
                    for (Long playerid : cancels) {
                        RunningInfo removed = RunningThread.this.runningInfos.remove(playerid);
                        if (removed != null) {
                            overs.add(removed);
                        }
                    }

                    // TODO 另外线程处理目标已到达的信息
                    if (!overs.isEmpty()) {
                        command_queue.addAll(overs);
                        try {
                            synchronized (RunningThread.this) {
                                RunningThread.this.notify();
                            }
                        } catch (Exception e) {
                            log.error("RunningThread " + RunningThread.this.threadName + " Notify Exception:" + e.getMessage());
                        }
                    }

                    long cost = System.currentTimeMillis() - begin;
//                    System.out.println("寻路定时器耗时:" + cost + " ms");

                }
            };
        }
        setUncaughtExceptionHandler(
                new Thread.UncaughtExceptionHandler() {
                    @Override
                    public void uncaughtException(Thread t, Throwable e) {
                        RunningThread.log.error("RunningThread.setUncaughtExceptionHandler", e);
                        if (RunningThread.this.timer != null) {
                            RunningThread.this.timer.cancel();
                        }
                        RunningThread.this.runningInfos.clear();
                        RunningThread.this.command_queue.clear();
                    }
                });
    }

    @Override
    public void run() {
        if (this.heart > 0 && this.timer != null) {
            this.timer.schedule(timerTask, 0, heart);
        }
        this.stop = false;

        int loop = 0;

        long lastrunthread = System.currentTimeMillis();
        long lastrunthreadsleep = System.currentTimeMillis();
        
        List<IBaseScript> evts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(IRunningEndScript.class.getName());
        if (evts == null || evts.isEmpty()) {
            this.command_queue.clear();
            log.error("未添加实现com.game.engine.thread.script.IRunningEndScript的脚本!!!");
            return;
        }

        while (!this.stop) {
            RunningInfo runningInfo = this.command_queue.poll();
            if (runningInfo == null) {
                try {
                    synchronized (this) {
                        loop = 0;
                        this.processingCompleted = true;
                        
                        {
                            log.warn("空闲后,重新获得寻路完毕脚本");
                            evts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(IRunningEndScript.class.getName());
                            if (evts == null || evts.isEmpty()) {
                                this.command_queue.clear();
                                log.error("未添加实现com.game.engine.thread.script.IRunningEndScript的脚本!!!");
                            }
                        }
                        
                        wait();
                        lastrunthreadsleep = System.currentTimeMillis();
                    }
                } catch (InterruptedException e) {
                    log.error("RunningThread.run 1 ", e);
                }
            } else {
                try {
                    long thisrunthread = System.currentTimeMillis();
                    if (thisrunthread - lastrunthread > this.heart + 200) {
                        log.error(getName() + "=run_interval=" + (thisrunthread - lastrunthread) + "=sleep_interval=" + (lastrunthreadsleep - lastrunthread));
                    }
                    lastrunthread = thisrunthread;

                    loop++;
                    this.processingCompleted = false;
                    long start = System.currentTimeMillis();

                    Iterator<IBaseScript> iterator = evts.iterator();
                    while (iterator.hasNext()) {
                        try {
                            IRunningEndScript script = (IRunningEndScript) iterator.next();
                            script.action(runningInfo);
                        } catch (Exception ex) { // 某些情况下最好别try catch 比如,角色创建,登录的时候
                            log.error("执行IRunningEndScript脚本异常", ex);
                        }
                    }

                    long cost = System.currentTimeMillis() - start;
                    if (cost > 30L) {
                        log.warn(getName() + "-->RunningThread[" + threadName + "]执行" + runningInfo.getClass().getSimpleName() + " 执行时间过长:" + cost);
                        if (cost > 100L) {
                            log.error("-->RunningThread[" + threadName + "]执行时间超过" + runningInfo.getClass().getSimpleName() + " 执行时间过长:" + cost + " 请确保该Handler逻辑是否正确");
                        }
                    }
                    if (loop > 50) {
                        loop = 0;
                        try {
                            Thread.sleep(1L);
                        } catch (InterruptedException e) {
                            log.error("-->RunningThread[" + threadName + "]已经执行超过300条任务,但依旧没执行完毕.请确认!", e);
                        }
                    }
                } catch (Exception e) {
                    log.error("RunningThread[" + threadName + "]执行任务错误 ", e);
                }
            }
        }

    }

    public void stop(boolean flag) {
        this.stop = flag;
        try {
            Thread.sleep(1000L);
        } catch (InterruptedException ex) {
        }
        if (this.timer != null) {
            this.timer.cancel();
        }
        this.runningInfos.clear();
        this.command_queue.clear();

        try {
            synchronized (this) {
                if (this.processingCompleted) {
                    this.processingCompleted = false;
                    notify();
                }
            }
        } catch (Exception e) {
            log.error("Main Thread " + this.threadName + " Notify Exception:" + e.getMessage());
        }
    }

    /**
     * 玩家移动
     *
     * @param playerid 玩家ID
     * @param x1 起始点X坐标
     * @param y1 起始点Y坐标
     * @param x2 结束点X坐标
     * @param y2 结束点Y坐标
     * @param speed 速度
     *
     * @param dir_x
     * @param dir_y
     * @param dir_z
     */
    public void addRuninfo(long playerid, float x1, float y1, float x2, float y2, float speed, float dir_x, float dir_y, float dir_z) {
        this.runningInfos.put(playerid, new RunningInfo(playerid, x1, y1, x2, y2, speed, dir_x, dir_y, dir_z));
    }

    public String getThreadName() {
        return this.threadName;
    }

    public long getHeart() {
        return this.heart;
    }

//    // RunningThread 测试
//    public static void main(String[] args) {
//        // 服务器启动线程组
//        String servername = "测试RunningThread";
//        ThreadGroup thread_group = new ThreadGroup(servername);
//        RunningThread wRunningThread = new RunningThread(thread_group, servername, 500L);
//        wRunningThread.start();
//
//        Random random = new Random();
//        int i = 10000;
//        for (int j = 0; j < 1; j++) {
//
//            long playerid = i++;
//            float x1 = random.nextFloat() * 200.0f;
//            float y1 = random.nextFloat() * 200.0f;
//
//            float x2 = random.nextFloat() * 200.0f;
//            float y2 = random.nextFloat() * 200.0f;
//
//            float x = x2 - x1;
//            float y = y2 - y1;
//
//            float speed = 6;
//
//            double sqrt = Math.sqrt(x * x + y * y);
//
//            float dir_x = (float) (x / sqrt);
//            float dir_y = 0;
//            float dir_z = (float) (y / sqrt);
//
////            System.out.println();
////            System.out.println(dir_x * dir_x + dir_y * dir_y);
////            System.out.println("(" + x1 + "  " + y1 + ")  (" + x2 + "  " + y2 + ")     (" + dir_x + "  " + dir_z + ")");
//            wRunningThread.addRuninfo(playerid, x1, y1, x2, y2, speed, dir_x, dir_y, dir_z);
//        }
//
//        for (;;) {
//            try {
//                Thread.sleep(random.nextInt(1000));
//            } catch (InterruptedException e) {
//            }
//
//            long playerid = i++;
//            float x1 = random.nextFloat() * 200.0f;
//            float y1 = random.nextFloat() * 200.0f;
//
//            float x2 = random.nextFloat() * 200.0f;
//            float y2 = random.nextFloat() * 200.0f;
//
//            float x = x2 - x1;
//            float y = y2 - y1;
//
//            float speed = 6;
//
//            double sqrt = Math.sqrt(x * x + y * y);
//
//            float dir_x = (float) (x / sqrt);
//            float dir_y = 0;
//            float dir_z = (float) (y / sqrt);
//
//            wRunningThread.addRuninfo(playerid, x1, y1, x2, y2, speed, dir_x, dir_y, dir_z);
//        }
//    }

    // 方向
    public static final class Vector3 {

        protected final float x;
//    protected final float y;
        protected final float z;

        public Vector3(float x/*, float y*/, float z) {
            this.x = x;
//        this.y = y;
            this.z = z;
        }

        public float getX() {
            return x;
        }

        public float getZ() {
            return z;
        }
        
    }

    public static final class RunningInfo {

        protected final long playerid; // 跑动的玩家

        //开始坐标点
        protected final float x1;

        protected final float y1;

        //结束坐标点(可能为NULL)
        protected final float x2;

        protected final float y2;

        //当前坐标点(可能为NULL)
        protected float curX;

        protected float curY;

        //速度
        protected final float speed;

        //方向
        protected final Vector3 direction;

        //开始时间
        protected final long beginTime;

        //最后一次跑动时间
        protected long lastRunTime;

        public RunningInfo(long playerid, float x1, float y1, float x2, float y2, float speed, float dir_x, float dir_y, float dir_z) {
            this.playerid = playerid;
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.curX = x1;
            this.curY = y1;
            this.speed = speed;
            this.direction = new Vector3(dir_x/*, dir_y*/, dir_z);
            this.beginTime = System.currentTimeMillis();
            this.lastRunTime = System.currentTimeMillis();
        }

        public long getPlayerid() {
            return playerid;
        }

        public float getX1() {
            return x1;
        }

        public float getY1() {
            return y1;
        }

        public float getX2() {
            return x2;
        }

        public float getY2() {
            return y2;
        }

        public float getCurX() {
            return curX;
        }

        public float getCurY() {
            return curY;
        }

        public float getSpeed() {
            return speed;
        }

        public Vector3 getDirection() {
            return direction;
        }

        public long getBeginTime() {
            return beginTime;
        }

        public long getLastRunTime() {
            return lastRunTime;
        }

        @Override
        public String toString() {
            return "RunningInfo{" + "playerid=" + playerid + ", x1=" + x1 + ", y1=" + y1 + ", x2=" + x2 + ", y2=" + y2 + ", curX=" + curX + ", curY=" + curY + ", speed=" + speed + ", direction=" + direction + ", beginTime=" + beginTime + ", lastRunTime=" + lastRunTime + '}';
        }
    }

}
