package com.game.engine.thread.map;

import com.game.engine.io.commmand.IHandler;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.engine.thread.map.conf.MapConfig;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class MapServerExcutor implements Executor {

    private static final Logger log = LoggerFactory.getLogger(MapServerExcutor.class);
    
    private static final String PLAYERID = "PLAYERID";
    
    private final ThreadPoolExecutorConfig decodeExcutorExcutorConfig;
    
    private final ThreadPoolExecutor decodeExcutor;
    
    private final Map<Long, MapServer> mapServers = new HashMap<>();
    
    public MapServerExcutor(ThreadPoolExecutorConfig decodeExcutorExcutorConfig) {
        this.decodeExcutorExcutorConfig = decodeExcutorExcutorConfig;
        this.decodeExcutor = this.decodeExcutorExcutorConfig.newThreadPoolExecutor();
    }
    
    public MapServerExcutor(String name, int type, int corePoolSize, int maxPoolSize, long keepAliveTime) {
        decodeExcutorExcutorConfig = new ThreadPoolExecutorConfig();
        decodeExcutorExcutorConfig.setName(name);
        decodeExcutorExcutorConfig.setType(type);
        decodeExcutorExcutorConfig.setCorePoolSize(corePoolSize);
        decodeExcutorExcutorConfig.setMaxPoolSize(maxPoolSize);
        decodeExcutorExcutorConfig.setKeepAliveTime(keepAliveTime);
        this.decodeExcutor = decodeExcutorExcutorConfig.newThreadPoolExecutor();
    }
    
    /**
     * 注册地图服务器
     * @param mapServer 
     */
    public void register(MapServer mapServer) {
        if (!mapServer.isAlive()) {
            mapServer.start();
        }
        for (MapConfig config : mapServer.getMapConfigs()) {
            mapServers.put(getKey(config.getLineId(), config.getMapId()), mapServer);
            log.info(mapServer + " " + config.getLineId() + " " + config.getMapId() + " register : " + getKey(config.getLineId(), config.getMapId()) + " SUCCESS");
//            if (mapManager != null) {
//                MapInfo mapInfo = mapManager.getMap(minaServerConfig.getId(), config.getLineId(), config.getMapId());
//                if (mapInfo != null) {
//                    log.info(String.format("地图创建：ModelId=%d,LineId=%d,MapId=%d,Width=%d,Height=%d,AreaNum=%d,MonsterNum=%d", mapInfo.getMapModelid(), mapInfo.getLineId(), mapInfo.getId(), mapInfo.getWidth(), mapInfo.getHeight()/*, mapInfo.getSyncAreas().size(), mapInfo.getMonsters().size()*/));
//                }
//            }
        }
    }

    private long getKey(int lineId, long mapId) {
        return lineId * 10000000 + mapId;
    }
    
    @Override
    public void execute(Runnable command) {
        if (command instanceof IHandler) {
            Distributer distributer = new Distributer((IHandler) command);
            decodeExcutor.execute(distributer);
        } else {
            log.error(command + "不是ReqHandler类型 !!!!");
        }
    }
    
    class Distributer implements Runnable {
        
        private final IHandler reqHandler;
        
        public Distributer(IHandler reqHandler) {
            this.reqHandler = reqHandler;
        }

        @Override
        public void run() {
            // 获得网络链接
            IoSession ioSession = reqHandler.getSession();
            if (ioSession == null) {
                log.error("执行分发command到地图服务器时,IoSession为NULL!");
                return;
            }
            
//            // 测试
//            long key = getKey(1, 0);
//            MapServer mapServer = mapServers.get(key);
//            if (mapServer != null) {
//                mapServer.addCommand(reqHandler);
//                return;
//            }
            
            // 获得PlayerID
            Long playerID = (Long) ioSession.getAttribute(PLAYERID);
            if (playerID == null) {
                log.error("执行分发command到地图服务器时,IoSession尚未赋值playerID!");
                return;
            }
            
            // 通过PlayerManager与playerID获得Player对象
            
            // reqHandler.setParameter(player) ;
            
            // 通过Player对象中的Line 和 Map信息,获得对应的MapServer
            
            
            // MapServer执行command 分发完毕
        }
    }

}
