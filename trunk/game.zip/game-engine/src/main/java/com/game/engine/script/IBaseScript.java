package com.game.engine.script;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
 public interface IBaseScript {

    /**
     * 获得唯一ID
     * @return 
     */
    int getOnlyId();

    /**
     * 获得版本
     * @return 
     */
    String getVer();

    /**
     * 获得名称
     * @return 
     */
    String getName();

    /**
     * 获得简易名称
     * @return 
     */
    String getSimpleName();

    /**
     * 获得实现了的所有脚本接口
     * @return 
     */
    String[] getEventList();

    /**
     * 初始化
     * @param paramInt
     * @param baseScriptEntry
     * @return 
     */
    boolean init(int paramInt, BaseScriptEntry baseScriptEntry);

    /**
     * 卸载
     * @param paramInt
     * @param baseScriptEntry
     * @return 
     */
    boolean uninit(int paramInt, BaseScriptEntry baseScriptEntry);
}
