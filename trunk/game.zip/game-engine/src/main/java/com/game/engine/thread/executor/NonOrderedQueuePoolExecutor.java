package com.game.engine.thread.executor;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class NonOrderedQueuePoolExecutor
        extends ThreadPoolExecutor {

    
    private final String name;
    
    public NonOrderedQueuePoolExecutor(String name, int corePoolSize, int maxPoolSize, long keepAliveTime) {
        super(corePoolSize, maxPoolSize, keepAliveTime, TimeUnit.SECONDS, new LinkedBlockingQueue());
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
}
