package com.game.engine.io.message;

import com.game.engine.io.commmand.IHandler;
import com.game.engine.thread.map.MapServer;
import com.google.protobuf.Message;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 消息注册表
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class MessagePool implements IMessagePool<Integer> {

    private static final Logger log = LoggerFactory.getLogger(MessagePool.class);
    
    private final Map<Integer, MessageBean> messagebeans = new HashMap<>();
    
    private final Map<Integer, Executor> syncHandlers = new HashMap<>();
    
    /**
     * 注册线程模型
     * @param threadModel 线程模型ID
     * @param executor 线程模型处理器
     */
    @Override
    public void register(int threadModel, Executor executor) {
        if (executor instanceof Thread) {
            if (!((Thread)executor).isAlive()) {
                ((Thread)executor).start();
                log.warn(executor + " Thread is running ...");
            }
        }
        syncHandlers.put(threadModel, executor);
    }
    
    /**
     * 获得线程模型对应的处理器
     * @param threadModel 线程模型ID
     * @return 线程模型处理器
     */
    @Override
    public Executor getExecutor(int threadModel) {
        return syncHandlers.get(threadModel);
    }

    /**
     * 注册协议
     * @param id 协议ID
     * @param messageClass 协议请求消息类型
     * @param handlerClass 协议请求处理类型
     * @param threadModel 协议请求线程模型
     * @param builder 协议请求消息构造器
    // * @param messageClass4Res 协议响应消息类型
    // * @param builder4Res  协议响应消息构造器
     * @param mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
     *                      一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
     */
    public void register(int id, Class<? extends Message> messageClass, Class<? extends IHandler> handlerClass
            , int threadModel
            , Message.Builder builder
    //        , Class<? extends Message> messageClass4Res
    //        , Message.Builder builder4Res
            , int mapThreadQueue
    ) {
        if (messageClass == null) {
            log.error("MessagePool.register 异常! messageClass 不能为null!" + id + " " + messageClass + " " + handlerClass + " " + threadModel + " " + builder);
            System.exit(1);
        }
        
        if (builder == null) {
            log.error("MessagePool.register 异常! builder 不能为null!" + id + " " + messageClass + " " + handlerClass + " " + threadModel + " " + builder);
            System.exit(1);
        }
        
        // TODO 验证线程模型
        if (threadModel != 0 && syncHandlers.get(threadModel) == null) {
            log.error("无法找到线程模型:" + threadModel + "对应的处理器.请确保服务器启动时先初始化线程模型对象!");
            System.exit(1);
        }
        
        
        if (handlerClass == null) {
            log.warn("MessagePool.register 注册了一个转发消息!" + id + " " + messageClass + " " + handlerClass + " " + threadModel + " " + builder);
        }
        
        messagebeans.put(id, new MessageBean(messageClass, handlerClass, threadModel, builder/*, messageClass4Res, builder4Res*/, mapThreadQueue));
    }

    @Override
    public MessageBean getMessageBean(Integer id) {
        return messagebeans.get(id);
    }

    // TODO 通过xml配置和文件地址,创建MessagePool
}
