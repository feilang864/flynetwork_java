package com.game.engine.timer.qz;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedulerTask implements Job {

    private static final Logger log = LoggerFactory.getLogger(SchedulerTask.class);

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        JobDataMap data = context.getMergedJobDataMap();
        String className = data.getString("className");
        try {
            Class<?> c = Class.forName(className);
            SchedulerEvent job = (SchedulerEvent) c.newInstance();
            job.run();
        } catch (ClassNotFoundException | ClassCastException | IllegalAccessException | InstantiationException e) {
            log.error("QZ定时器执行错误", e);
        }
    }
}
