package com.game.engine.io.message;

import com.game.engine.io.commmand.IHandler;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class HttpMessageBean implements IMessageBean {
    
    private final Class<? extends IHandler> handlerClass;   // Handler类型
    private final int threadModel;

    public HttpMessageBean(Class<? extends IHandler> handlerClass, int threadModel) {
        this.handlerClass = handlerClass;
        this.threadModel = threadModel;
    }

    /**
     * 获取请求处理对象
     *
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    @Override
    public IHandler newHandler() throws InstantiationException, IllegalAccessException {
        if (handlerClass == null) return null;
        return handlerClass.newInstance();
    }

    @Override
    public int getThreadModel() {
        return threadModel;
    }
}
