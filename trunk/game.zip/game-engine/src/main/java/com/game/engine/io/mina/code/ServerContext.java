package com.game.engine.io.mina.code;

import org.apache.mina.core.buffer.IoBuffer;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public class ServerContext {

    private final IoBuffer buff;

    public ServerContext() {
        this.buff = IoBuffer.allocate(256);
        this.buff.setAutoExpand(true); // 允许自动扩展容量
        this.buff.setAutoShrink(true); // 允许自动缩减容量
    }

    public void append(IoBuffer buff) {
        this.buff.put(buff);
    }

    public IoBuffer getBuff() {
        return this.buff;
    }
}
