package com.game.engine.io.mina;

import com.game.engine.io.commmand.IHandler;
import com.game.engine.io.conf.BaseServerConfig;
import com.game.engine.io.message.IMessagePool;
import com.game.engine.thread.SyncThreadExecutor;
import com.game.engine.thread.executor.conf.ThreadPoolExecutorConfig;
import com.game.engine.thread.map.MapServerExcutor;
import java.util.concurrent.ThreadPoolExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @param <MsgPool>
 * @param <Conf>
 */
public abstract class Service<MsgPool extends IMessagePool, Conf extends BaseServerConfig> implements Runnable {
    
    private static final Logger log = LoggerFactory.getLogger(Service.class);
    
    // 消息协议
    protected final MsgPool messagePool;
    
    // 对应线程模型0.客户端的请求,默认使用其执行
    protected final ThreadPoolExecutor defaultThreadExcutor;
    
    // 对应线程模型1.玩家的请求,默认使用其执行,其会获得Player等信息,并派发Handler到具体的MapServer处理
    protected final MapServerExcutor mapServerThreadExcutor;
    
    // 用于处理一类,或多类需要线程同步的消息
    protected final SyncThreadExecutor<? extends IHandler> syncThreadExecutor = new SyncThreadExecutor<>("全局线程同步执行器");

    protected Service(MsgPool messagePool, ThreadPoolExecutorConfig defaultThreadExcutorConfig, ThreadPoolExecutorConfig mapServerThreadExcutorConfig) {
        this.messagePool = messagePool;
        // 初始化defaultThreadExcutor
        if (defaultThreadExcutorConfig!= null) defaultThreadExcutor = defaultThreadExcutorConfig.newThreadPoolExecutor();
        else defaultThreadExcutor = null;
        // 初始化mapServerThreadExcutor
        if (mapServerThreadExcutorConfig != null) mapServerThreadExcutor = new MapServerExcutor(mapServerThreadExcutorConfig);
        else mapServerThreadExcutor = null;
    }

    @Override
    public void run() {
        Runtime.getRuntime().addShutdownHook(new Thread(new CloseByExit(this)));
        String info = this.toString();
        log.info(info + " add shutdown hook success ...");
        initProtosThreadModel();
        log.info(info + " init protos thread model success ...");
        initProtos();
        log.info(info + " init protocels success ...");
        initMapServers();
        log.info(info + " init protocels success ...");
        running();
        log.info(info + " is running ...");
    }

    protected void initProtosThreadModel() {
        if (defaultThreadExcutor != null) messagePool.register(0, defaultThreadExcutor);
        if (mapServerThreadExcutor != null) messagePool.register(1, mapServerThreadExcutor);
        if (syncThreadExecutor != null) messagePool.register(2, syncThreadExecutor);
    }
    
    /**
     * 初始化协议
     */
    protected abstract void initProtos();
    
    /**
     * 初始化地图(地图线程)
     */
    protected abstract void initMapServers();
    
    /**
     * 运行中
     */
    protected abstract void running();

    /**
     * 关闭回调
     */
    protected abstract void onShutdown();
    
    @Override
    public abstract String toString();
    
    
    private static final class CloseByExit implements Runnable {

        private final Logger log = LoggerFactory.getLogger(CloseByExit.class);
        private final Service server;

        public CloseByExit(Service server) {
            this.server = server;
        }

        @Override
        public void run() {
            server.onShutdown();
            log.info("[" + server.getClass().getName() + "] " + server.toString() + " Stop!");
        }
    }
}
