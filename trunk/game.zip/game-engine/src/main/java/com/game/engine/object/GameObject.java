package com.game.engine.object;

import com.game.engine.utils.Config;
import java.io.Serializable;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class GameObject implements Serializable {

    private static final long serialVersionUID = 6697306295815768277L;

    protected long id;

    protected GameObject() {
        this.id = Config.getId();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
//    public String getClazz() {
//        return this.getClass().getName();
//    }
//
//    public void setClazz(String clazz) {
//        this.clazz = "";
//    }
}
