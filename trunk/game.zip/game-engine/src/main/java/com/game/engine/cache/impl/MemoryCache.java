package com.game.engine.cache.impl;

import com.game.engine.cache.Cache;
import com.game.engine.cache.struct.LRULinkedHashMap;
import com.game.engine.cache.struct.WaitingUpdateQueue;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class MemoryCache<K, V>
        implements Cache<K, V>, Serializable {

    private static final long serialVersionUID = -3656956459941919920L;
    private static final int MAX_SIZE = 5000;
    private static final int PER_SAVE = 5;
    
    private final WaitingUpdateQueue<V> queue = new WaitingUpdateQueue();
    
    private LRULinkedHashMap<K, V> cache;
    
    protected int saveSize;

    public MemoryCache() {
        this(MAX_SIZE, PER_SAVE);
    }

    public MemoryCache(int maxSize, int saveSize) {
        this.cache = new LRULinkedHashMap(maxSize);
        this.saveSize = saveSize;
    }

    @Override
    public synchronized void put(K key, V value) {
        if (this.cache.containsKey(key)) {
            this.queue.add(value);
            return;
        }
        this.cache.put(key, value);
    }

    @Override
    public V get(K key) {
        V value = this.cache.get(key);

        return value;
    }

    @Override
    public void remove(K key) {
        V value = this.cache.get(key);
        if (value != null) {
            this.cache.remove(key);

            this.queue.remove(value);
        }
    }

    @Override
    public List<V> getWaitingSave(int size) {
        ArrayList<V> waiting = new ArrayList();

        int i = 0;

        V value = this.queue.poll();
        while (value != null) {
            waiting.add(value);
            i++;
            if (i == size) {
                break;
            }
            value = this.queue.poll();
        }
        return waiting;
    }

    public List<V> getAllWaitingSave() {
        ArrayList<V> waiting = new ArrayList();

        V value = this.queue.poll();
        while (value != null) {
            waiting.add(value);

            value = this.queue.poll();
        }
        return waiting;
    }

    public LRULinkedHashMap<K, V> getCache() {
        return this.cache;
    }
}
