package com.game.engine.cache;

import java.util.List;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public interface Cache<K, V> {

    V get(K paramK);

    void put(K paramK, V paramV);

    void remove(K paramK);

    List<V> getWaitingSave(int paramInt);
}
