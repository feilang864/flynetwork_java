package com.game.engine.io.commmand;

import com.google.protobuf.Message;
import org.apache.mina.core.session.IoSession;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public abstract class TcpHandler
        implements IHandler{

    private Object parameter;
    
    private IoSession   session;       // 消息来源
    private Message     message;         // 请求消息
    private int         mapThreadQueue;  // 如果消息是地图服务器MapServer处理,那么具体是MapServer中那个线程处理,默认是MapServer.MAINTHREAD的线程处理
    
    private long createTime;

    @Override
    public Object clone()
            throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public IoSession getSession() {
        return session;
    }

    @Override
    public void setSession(IoSession session) {
        this.session = session;
    }
    
    @Override
    public Message getMessage() {
        return this.message;
    }

    @Override
    public void setMessage(Object message) {
        if (message instanceof Message) {
            this.message = (Message) message;
        }
    }

    @Override
    public Object getParameter() {
        return this.parameter;
    }

    @Override
    public void setParameter(Object parameter) {
        this.parameter = parameter;
    }

    @Override
    public long getCreateTime() {
        return this.createTime;
    }

    @Override
    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    @Override
    public int getMapThreadQueue() {
        return this.mapThreadQueue;
    }

    @Override
    public void setMapThreadQueue(int mapThreadQueue) {
        this.mapThreadQueue = mapThreadQueue;
    }
    
}
