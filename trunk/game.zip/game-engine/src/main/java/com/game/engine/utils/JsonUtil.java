package com.game.engine.utils;

import com.alibaba.fastjson.TypeReference;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;

/**
 * JSON序列化和反序列化
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class JsonUtil {

    /**
     * JSON序列化
     *
     * @param object 传入对象
     * @return String
     */
    public static String toJSONString(Object object) {
        return BaseJson.toJSONString(object);
    }

    /**
     * JSON序列化(默认写入类型名称)
     *
     * @param object 传入对象
     * @return String
     */
    public static String toJSONStringWriteClassName(Object object) {
        return BaseJson.toJSONStringWriteClassName(object);
    }

    /**
     * JSON序列化时间(默认格式yyyy-MM-dd HH:mm:ss)
     *
     * @param dateTime 传入时间
     * @return String
     */
    public static String toJSONStringWithDateFormat(long dateTime) {
        return BaseJson.toJSONStringWithDateFormat(dateTime);
    }

    /**
     * JSON序列化时间(自定义格式)
     *
     * @param dateTime 传入时间
     * @param dateFormat
     * @return String
     */
    public static String toJSONStringWithDateFormat(long dateTime, String dateFormat) {
        return BaseJson.toJSONStringWithDateFormat(dateTime, dateFormat);
    }

    /**
     * JSON序列化时间(默认格式yyyy-MM-dd HH:mm:ss)
     *
     * @param date 传入时间结构
     * @return String
     */
    public static String toJSONStringWithDateFormat(Date date) {
        return BaseJson.toJSONStringWithDateFormat(date);
    }

    /**
     * JSON序列化时间(自定义格式)
     *
     * @param date 传入时间结构
     * @param dateFormat
     * @return String
     */
    public static String toJSONStringWithDateFormat(Date date, String dateFormat) {
        return BaseJson.toJSONStringWithDateFormat(date, dateFormat);
    }

    /**
     * JSON反序列化
     *
     * @param text 传入被反序列化的对象
     * @return Object
     */
    public static Object parse(String text) {
        return BaseJson.parse(text);
    }

    /**
     * JSON反序列化
     *
     * @param <T>
     * @param text 传入被反序列化的对象
     * @param clazz 要被反序列化成的类型
     * @return 
     */
    public static <T extends Object> T parseObject(String text, Class<T> clazz) {
        return (T) BaseJson.parseObject(text, clazz);
    }

    /**
     * JSON反序列化(强制转化为T类型)
     *
     * @param <T>
     * @param text 传入被反序列化的对象
     * @param type 要被反序列化成的类型
     * @return 
     */
    public static <T extends Object> T parseObject(String text, TypeReference<T> type) {
        return (T) BaseJson.parseObject(text, type);
    }

    /**
     * JSON反序列化(反序列化为List)
     *
     * @param <T>
     * @param text 传入被反序列化的对象
     * @param clazz 要被反序列化成的类型
     * @return 
     */
    public static <T extends Object> List<T> parseArray(String text, Class<T> clazz) {
        return (List<T>) BaseJson.parseArray(text, clazz);
    }

    /**
     * JSON反序列化(反序列化为List) Type[] types = new Type[] {String.class, Byte.class};
     *
     * @param text 传入被反序列化的对象
     * @param types 要被反序列化成的类型数组(可多个类型，按照顺序反序列化)
     * @return 
     */
    public static List<Object> parseArray(String text, Type[] types) {
        return BaseJson.parseArray(text, types);
    }

}
