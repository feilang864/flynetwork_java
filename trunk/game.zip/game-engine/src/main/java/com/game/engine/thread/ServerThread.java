package com.game.engine.thread;


import com.game.engine.io.commmand.filter.IRunnableFilter;
import com.game.engine.thread.timer.TimerThread;
import com.game.engine.timer.TimerEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class ServerThread
        extends Thread {

    private static final Logger log = LoggerFactory.getLogger(ServerThread.class);

    // 线程名称
    protected final String threadName;
    // 线程心跳间隔
    protected final long heart;
    // 线程处理命令队列
    private final LinkedBlockingQueue<Runnable> command_queue = new LinkedBlockingQueue<>();

    private final List<IRunnableFilter> filters = new ArrayList<>();

    private boolean stop;
    private boolean processingCompleted = false;

    private TimerThread timer;

    public ServerThread(ThreadGroup group, String threadName, long heart, Class<? extends TimerEvent>... classLogNames) {
        super(group, threadName);
        this.threadName = threadName;
        this.heart = heart;

        if (this.heart > 0) {
            this.timer = new TimerThread(this, classLogNames);
        }
        setUncaughtExceptionHandler(
                new Thread.UncaughtExceptionHandler() {
                    @Override
                    public void uncaughtException(Thread t, Throwable e) {
                        ServerThread.log.error("ServerThread.setUncaughtExceptionHandler", e);
                        if (ServerThread.this.timer != null) {
                            ServerThread.this.timer.stop(true);
                        }
                        ServerThread.this.command_queue.clear();
                    }
                });
    }

    @Override
    public void run() {
        if (this.heart > 0 && this.timer != null) {
            this.timer.start();
        }

        this.stop = false;

        int loop = 0;

        long lastrunthread = System.currentTimeMillis();
        long lastrunthreadsleep = System.currentTimeMillis();

        while (!this.stop) {
            Runnable command = (Runnable) this.command_queue.poll();
            if (command == null) {
                try {
                    synchronized (this) {
                        loop = 0;
                        this.processingCompleted = true;
                        wait();
                        lastrunthreadsleep = System.currentTimeMillis();
                    }
                } catch (InterruptedException e) {
                    log.error("ServerThread.run 1 ", e);
                }
            } else {
                try {
                    long thisrunthread = System.currentTimeMillis();
                    if (thisrunthread - lastrunthread > this.heart + 200) {
                        log.error(getName() + "=run_interval=" + (thisrunthread - lastrunthread) + "=sleep_interval=" + (lastrunthreadsleep - lastrunthread));
                    }
                    lastrunthread = thisrunthread;

                    loop++;
                    this.processingCompleted = false;
                    long start = System.currentTimeMillis();
                    boolean result = false;
                    for (IRunnableFilter filter : this.filters) {
                        if (!filter.filter(command)) {
                            result = true;
                            break;
                        }
                    }
                    if (!result) {
                        command.run();
                        long cost = System.currentTimeMillis() - start;
                        if (cost > 30L) {
                            log.warn(getName() + "-->ServerThread["+threadName+"]执行" + command.getClass().getSimpleName() + " 执行时间过长:" + cost);
                            if (cost > 500L) {
                                log.error("-->ServerThread["+threadName+"]执行时间超过" + command.getClass().getSimpleName() + " 执行时间过长:" + cost + " 请确保该Handler逻辑是否正确");
                            }
                        }
                        if (loop > 300) {
                            loop = 0;
                            try {
                                Thread.sleep(1L);
                            } catch (InterruptedException e) {
                                log.error("-->ServerThread["+threadName+"]已经执行超过300条任务,但依旧没执行完毕.请确认!", e);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error("ServerThread["+threadName+"]执行任务错误 ", e);
                }
            }
        }
    }

    public void stop(boolean flag) {
        this.stop = flag;
        if (this.timer != null) {
            this.timer.stop(flag);
        }
        this.command_queue.clear();
        try {
            synchronized (this) {
                if (this.processingCompleted) {
                    this.processingCompleted = false;
                    notify();
                }
            }
        } catch (Exception e) {
            log.error("Main Thread " + this.threadName + " Notify Exception:" + e.getMessage());
        }
    }

    /**
     * 执行IHandler. ReqHandler/ResHandler
     * @param command 
     */
    public void addCommand(Runnable command) {
        try {
            this.command_queue.add(command);
            synchronized (this) {
                notify();
            }
        } catch (Exception e) {
            log.error("Main Thread " + this.threadName + " Notify Exception:" + e.getMessage());
        }
    }

    /**
     * 添加过滤器
     * @param filter 
     */
    public void addCommandFitler(IRunnableFilter filter) {
        this.filters.add(filter);
    }

    public void addTimerEvent(TimerEvent event) {
        if (this.timer != null) {
            this.timer.addTimerEvent(event);
        }
    }

    public void removeTimerEvent(TimerEvent event) {
        if (this.timer != null) {
            this.timer.removeTimerEvent(event);
        }
    }

    public String getThreadName() {
        return this.threadName;
    }

    public long getHeart() {
        return this.heart;
    }
//    
//    // ServerThread 测试
//    public static void main(String[] args) {
//        // 服务器启动线程组
//        int serverid = 1;
//        String servername = "测试ServerThread";
//        String serverweb = "serverweb";
//        ThreadGroup thread_group = new ThreadGroup(servername);
//        ServerThread wServerThread = new ServerThread(thread_group, servername, 1000L /**1秒执行一次*/);
//        wServerThread.start();
//        wServerThread.addTimerEvent(new ServerHeartTimer(serverid, serverweb));
//        wServerThread.addCommand(new Runnable(){
//            @Override
//            public void run() {
//                System.out.println("xxxxxxxxxxx");
//            }
//        });
//        
//        ReqHandler reqHandler = new ReqHandler(){
//
//            @Override
//            public void run() {
//                System.out.println("ReqHandler getMessage() : " + getMessage());
//                System.out.println("ReqHandler getIoSession() : " + getIoSession());
//                try {
//                    Thread.sleep(80L);
//                } catch (InterruptedException ex) {
//                }
//            }
//        };
//        
//        for (int i = 0; i < 500; i++) {
//            wServerThread.addCommand(reqHandler);
//        }
//        
//        wServerThread.addCommand(new ResHandler(){
//
//            @Override
//            public void run() {
//                System.out.println("ResHandler getMessage() : " + getMessage());
//                System.out.println("ResHandler getIoSession() : " + getIoSession());
//            }
//            
//        });
//    }
}
