package com.game.engine.thread.executor.conf;

import com.game.engine.thread.executor.NonOrderedQueuePoolExecutor;
import com.game.engine.thread.executor.OrderedQueuePoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
@Root
public class ThreadPoolExecutorConfig {

    // 线程池执行器名称
    @Element(required = true)
    private String name;
    
    // 线程池类型:1为NonOrderedQueuePoolExecutor
    @Element(required = true)
    private int type;
    
    // 核心线程池值
    @Element(required = true)
    private int corePoolSize = 100;
    
    // 线程池最大值
    @Element(required = true)
    private int maxPoolSize = 200;
    
    // 线程池保持活跃时间(秒)
    @Element(required = true)
    private long keepAliveTime = 30L;
    
    public ThreadPoolExecutor newThreadPoolExecutor() throws RuntimeException {
        switch (type) {
            case 1:
                return new NonOrderedQueuePoolExecutor(name, corePoolSize, maxPoolSize, keepAliveTime);
            case 2:
                return new OrderedQueuePoolExecutor(name, corePoolSize, maxPoolSize, keepAliveTime);
            default:
                throw new RuntimeException(String.format("线程池类型%d,无法确认!", type));
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
    
    public int getCorePoolSize() {
        return corePoolSize;
    }

    @Deprecated
    public void setCorePoolSize(int corePoolSize) {
        this.corePoolSize = corePoolSize;
    }

    public int getMaxPoolSize() {
        return maxPoolSize;
    }

    @Deprecated
    public void setMaxPoolSize(int maxPoolSize) {
        this.maxPoolSize = maxPoolSize;
    }

    public long getKeepAliveTime() {
        return keepAliveTime;
    }

    @Deprecated
    public void setKeepAliveTime(long keepAliveTime) {
        this.keepAliveTime = keepAliveTime;
    }
    
}
