package com.game.engine.script;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class BaseScriptEntry {

    private static final Logger log = LoggerFactory.getLogger(BaseScriptEntry.class);

    // 使用的类加载器
    private URLClassLoader urlClassLoader;
    private IBaseScript baseScript;

    // urlClassLoader信息.主要是已加载的jar,和class路径. 如:/E:/NetBeansProjects/lhcj/Libs/libs/GameCore.jar;/E:/NetBeansProjects/lhcj/Libs/libs/GameRecorder.jar;E:/NetBeansProjects/lhcj/LhcjServer/build/classes/; ...
    private String urlClassLoaderInfo;
    // 基础脚本实体java源文件相对"根"路径      如:"jbsrc"
    private String scriptEntrySrc;
    // 基础脚本实体编译后.class文件存放地址    如:"bin/server"
    private String scriptEntryCompileTo;
    // 基础脚本实体编译后.class文件存放地址    如:"bin.server."
    private String scriptEntryCompileTo2;
    // 基础脚本实体java源文件相对路径          "jbsrc/serverscripts/main/MainScript.java"
    private String scriptEntrySource;
    // 基础脚本实体完整类名                   "serverscripts.main.MainScript"
    private String scriptEntryClassName;
    
    // 全局消息
    private String msg;

    // 通过源文件编译生成的类
    private Class compileClass;
    private BaseScriptClassLoader baseScriptClassLoader;

    // 名称
    private final String name;
    // 是否允许开始加载的状态开关
    private final AtomicBoolean loadState = new AtomicBoolean(true);
    private final AtomicBoolean swapState = new AtomicBoolean(false);

    private final Object syncObj = new Object();

    // 保存脚本名称和脚本对象
    private final Map<String, IBaseScript> nameAndScript = new ConcurrentHashMap<>();
    // 备份nameAndScript
    private final Map<String, IBaseScript> nameAndScriptDump = new ConcurrentHashMap<>();
    // 脚本接口名称和实现该接口的所有脚本对象
    private final Map<String, List<IBaseScript>> eventAndScript = new ConcurrentHashMap<>(); // key = 脚本接口名称, value = 实现了该脚本的脚本对象
    // 备份eventAndScript
    private final Map<String, List<IBaseScript>> eventAndScriptDump = new ConcurrentHashMap<>();

    private final List<String> errors = new ArrayList<>();

    public long scriptID = 0L;

    public List<String> getErrors() {
        return this.errors;
    }

    BaseScriptEntry(String name, String scriptEntrySource, String scriptEntryClassName, String scriptEntrySrc, String scriptEntryCompileTo, int scriptEntryCompileType, ClassLoader scriptEntryCompileClassLoader) throws Exception {
        this.name = name; // MainScript
        this.compileClass = null;
        
        Class localClass = null;
        try {
            localClass = Class.forName(scriptEntryClassName);
        } catch (ClassNotFoundException ex) {
        }
        if (localClass != null) { // 通过Class.forName查找当前环境是否已加载了该类
//            File localFile = new File("script.opendebug.class"); // 如果已经加载,查看是否存在script.opendebug.class,存在的话,标识号开发环境
//            if (localFile.exists()) {
//                this.compileClass = localClass;
//            } else {
//                throw new Exception(String.format("error:class is exists (%s):%s", localClass.getClassLoader().toString(), scriptEntryClassName));
//            }
            
            
            log.warn("加载脚本的时候,发现" + scriptEntryClassName + "已被加载!");
            this.compileClass = localClass;
        }
        initScriptEntry(scriptEntryCompileClassLoader, scriptEntryCompileType, scriptEntrySource, scriptEntryClassName, scriptEntrySrc, scriptEntryCompileTo);
    }

    private void initUrlClassLoaderInfo() {
        this.urlClassLoaderInfo = null;
        StringBuilder localStringBuilder = new StringBuilder();
        for (URL localURL : this.urlClassLoader.getURLs()) {
            String str = localURL.getFile();
            localStringBuilder.append(str).append(File.pathSeparator);
        }
        this.urlClassLoaderInfo = localStringBuilder.toString(); // /E:/NetBeansProjects/lhcj/Libs/libs/GameCore.jar;/E:/NetBeansProjects/lhcj/Libs/libs/GameRecorder.jar;/E:/NetBeansProjects/lhcj/Libs/libs/LhcjCommon.jar;/E:/NetBeansProjects/lhcj/Libs/libs/asm-3.3.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/bean-validator-4.0.0.jar;/E:/NetBeansProjects/lhcj/Libs/libs/c3p0-0.9.1-pre6.jar;/E:/NetBeansProjects/lhcj/Libs/libs/cglib-2.2.2.jar;/E:/NetBeansProjects/lhcj/Libs/libs/common-gamelog-1.0.2.RELEASE.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-beanutils.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-codec.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-collections-3.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-dbutils-1.5.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-lang-2.4.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-logging-1.1.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/ezmorph-1.0.6.jar;/E:/NetBeansProjects/lhcj/Libs/libs/fastjson-1.1.17.jar;/E:/NetBeansProjects/lhcj/Libs/libs/jakarta-oro-2.0.8.jar;/E:/NetBeansProjects/lhcj/Libs/libs/json-lib-2.3-jdk15.jar;/E:/NetBeansProjects/lhcj/Libs/libs/log4j-1.2.16.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mail.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mina-core-2.0.4.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mybatis-3.0.6.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mysql-connector-java-5.0.7-bin.jar;/E:/NetBeansProjects/lhcj/Libs/libs/quartz-2.1.3.jar;/E:/NetBeansProjects/lhcj/Libs/libs/slf4j-api-1.6.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/slf4j-log4j12-1.6.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/tools.jar;/E:/NetBeansProjects/lhcj/LhcjServer/build/classes/;
    }

    /**
     * 清理一类脚本
     *
     * @param scriptEntryCompileType 基础脚本实体编译类型 SERVER_LOAD
     */
    public void clear(int scriptEntryCompileType) {
        if (this.baseScript != null) {
            log.info(String.format("clear.main.class call uninit (%s)", this.baseScript.getClass().getName()));
            this.baseScript.uninit(scriptEntryCompileType, this);
            this.baseScript = null;
        }
        this.urlClassLoader = null;
        this.urlClassLoaderInfo = null;
        this.scriptEntrySrc = null;
        this.scriptEntryCompileTo = null;
        this.scriptEntryCompileTo2 = null;
        this.msg = null;
        this.scriptEntrySource = null;
        this.scriptEntryClassName = null;
        this.baseScriptClassLoader = null;
        clear_require(scriptEntryCompileType);
        clear_dump(scriptEntryCompileType);
    }

    public final void initScriptEntry(
            ClassLoader scriptEntryCompileClassLoader,
            int scriptEntryCompileType,
            String scriptEntrySource,
            String scriptEntryClassName,
            String scriptEntrySrc,
            String scriptEntryCompileTo) {
        if (scriptEntryCompileClassLoader == null) { // 初始化ClassLoader编译器,如果为空的话,使用当前类的类加载器
            scriptEntryCompileClassLoader = getClass().getClassLoader();
        }
        this.urlClassLoader = (URLClassLoader) scriptEntryCompileClassLoader;

        scriptEntrySrc = scriptEntrySrc.replace("\\", "/"); // jbsrc
        if (scriptEntrySrc.endsWith("/")) {
            scriptEntrySrc = scriptEntrySrc.substring(0, scriptEntrySrc.length() - 1);
        }
        this.scriptEntrySrc = scriptEntrySrc;

        scriptEntryCompileTo = scriptEntryCompileTo.replace("\\", "/"); // bin/server
        if (scriptEntryCompileTo.endsWith("/")) {
            scriptEntryCompileTo = scriptEntryCompileTo.substring(0, scriptEntryCompileTo.length() - 1);
        }
        this.scriptEntryCompileTo = scriptEntryCompileTo; // bin/server

        this.scriptEntryCompileTo2 = (scriptEntryCompileTo + ".").replace("/", "."); // bin.server.

        this.scriptEntrySource = scriptEntrySource.replace("\\", "/"); // jbsrc/serverscripts/main/MainScript.java

        this.scriptEntryClassName = scriptEntryClassName; // serverscripts.main.MainScript

        initUrlClassLoaderInfo();
    }

    /**
     * 加载脚本
     *
     * @param scriptEntrySource 基础脚本实体java源文件相对路径
     * "jbsrc/serverscripts/main/MainScript.java"
     * @param scriptEntryClassName 基础脚本实体完整类名 "serverscripts.main.MainScript"
     * @param scriptEntrySrc 基础脚本实体java源文件相对"根"路径 "jbsrc"
     * @param scriptEntryCompileTo 基础脚本实体编译后.class文件存放地址 "bin/server"
     * @param scriptEntryCompileType 基础脚本实体编译类型 SERVER_LOAD
     * @param scriptEntryCompileClassLoader 基础脚本实体编译使用的ClassLoader null
     * @return
     */
    public final Map loadScript(
            ClassLoader scriptEntryCompileClassLoader,
            int scriptEntryCompileType,
            String scriptEntrySource,
            String scriptEntryClassName,
            String scriptEntrySrc,
            String scriptEntryCompileTo) {
        // 清理
        clear(scriptEntryCompileType);
        // 初始化
        initScriptEntry(scriptEntryCompileClassLoader, scriptEntryCompileType, scriptEntrySource, scriptEntryClassName, scriptEntrySrc, scriptEntryCompileTo);
        // 加载
        return loadScript(scriptEntryCompileType);
    }

    public Map loadScript(int scriptEntryCompileType) {
        Map result = new HashMap();
        result.put("code", "-1"); // 第一步
        getErrors().clear();
        File scriptEntrySrc = new File(this.scriptEntrySrc); // jbscr 脚本源文件主目录是否存在
        if (!scriptEntrySrc.exists()) {
            this.msg = String.format("脚本源文件路径不存在!! 脚本:%s:  源文件路径:%s", this.scriptEntrySource, this.scriptEntrySrc);
            result.put("msg", this.msg);
            log.error(this.msg);
            return result;
        }
        
        File scriptEntryCompileTo = new File(this.scriptEntryCompileTo); // bin/server 编译后存放的文件夹是否存在,不存在的话,创建
        if (!scriptEntryCompileTo.exists()) {
            scriptEntryCompileTo.mkdirs();
        }
        try {
            result.put("code", "-2"); // 第2步
            StringBuilder sourceContent = new StringBuilder();
            BufferedReader bufferedReader = null;

            try {
                File scriptEntrySource = new File(this.scriptEntrySource); // jbsrc/serverscripts/main/MainScript.java
                bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(scriptEntrySource), "UTF-8")); // 读取脚本java源文件
                char[] buf = new char[4096];
                int i1 = 0;
                while (0 < (i1 = bufferedReader.read(buf))) {
                    sourceContent.append(buf, 0, i1);
                }
                try {
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                result.put("code", "-200"); // 读取脚本java源文件完毕
            } catch (IOException | RuntimeException ex) {
                throw new RuntimeException(ex);
            } finally {
                try {
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
            result.put("msg", "开始加载源文件!!!"); // 开始加载源文件

            if (this.loadState.getAndSet(false)) { // m = new AtomicBoolean(true)
                try {
                    getErrors().clear();
                    result.put("code", "-3"); // 第3步
                    this.msg = "";
                    this.baseScriptClassLoader = new BaseScriptClassLoader(this.urlClassLoader); // 创建BaseScriptClassLoader
                    Class compileClass = this.compileClass != null ? this.compileClass : compileSource(this.scriptEntryClassName, sourceContent.toString()); // BaseScriptJavaFileObject("serverscripts.main.MainScript", "jbsrc/serverscripts/main/MainScript.java文件的文本内容")
                    result.put("msg", this.msg);
                    if (compileClass != null) {
                        IBaseScript baseScript = this.baseScript;
                        IBaseScript newBaseScript = (IBaseScript) compileClass.newInstance(); // 生成脚本对象
                        if (newBaseScript != null) {
                            try {
                                if (baseScript != null) {
                                    log.info(String.format("卸载原来的脚本:uninit (%s)", baseScript.getClass().getName()));
                                    baseScript.uninit(scriptEntryCompileType, this);
                                }
                                swap(scriptEntryCompileType);
                                log.info(String.format("初始化新加载的脚本:init (%s)", newBaseScript.getClass().getName()));
                                newBaseScript.init(scriptEntryCompileType, this); // 执行脚本初始化操作
                                if (getErrors().isEmpty()) {
                                    this.baseScript = newBaseScript; // MainScript对象
                                } else {
                                    back(scriptEntryCompileType);
                                }
                            } finally {
                                log.error(String.format("加载脚本,共出现错误: %d", getErrors().size()));
                                if (getErrors().isEmpty()) {
                                    this.scriptID = System.currentTimeMillis(); // 脚本ID 使用系统当前时间
                                }
                            }
                            try {
                                Thread.sleep(2000L);
                            } catch (InterruptedException ex) {
                            } finally {
                                clear_dump(scriptEntryCompileType);
                            }
                            if (getErrors().isEmpty()) {
                                result.put("code", "0");
                            } else {
                                result.put("code", "-100");
                                result.put("msg", "class require or init error!!" + getErrors().size());
                                for (String err : getErrors()) {
                                    log.error(err);
                                }
                            }
                        }
                    } else {
                        result.put("code", "-4");
                    }
                } catch (IOException | IllegalAccessException | InstantiationException ex) {
                    this.msg = String.format("加载脚本异常 (%s : %s) : %s", this.scriptEntrySource, this.msg, ex.toString());
                    result.put("msg", this.msg);
                    log.error(String.format("code2class error (%s : %s)", this.scriptEntrySource, this.msg), ex);
                } finally {
                    this.loadState.set(true);
                }
            }
        } catch (RuntimeException ex) {
            this.msg = String.format("加载脚本异常 (%s : %s) : %s", this.scriptEntrySource, this.msg, ex.toString());
            result.put("msg", this.msg);
            log.error(String.format("加载脚本异常 (%s : %s)", this.scriptEntrySource, this.msg), ex);
        }
        return result;
    }

    /**
     * 编译文件,或目录下的所有文件
     *
     * @param binPathOrClassPath class文件或bin目录
     * @param scriptEntryClassPath 脚本实体class路径
     * @return
     */
    private boolean compile(File binPathOrClassPath, String scriptEntryClassPath) { // 循环执行,处理所有的脚本文件,读取
        if (binPathOrClassPath.isDirectory()) { // bin\server
            File[] subFiles = binPathOrClassPath.listFiles(); // File[]{bin\server\serverscripts    ... }
            for (File file : subFiles) {
                File subFile = file; // bin\server\serverscripts
                if (!compile(subFile, scriptEntryClassPath)) { // bin/server/serverscripts/main/MainScript.class
                    return false;
                }
            }
        } else {
            String scriptEntryClassPathStr = binPathOrClassPath.getPath(); // bin\server\serverscripts\activities\ActivitieValueScript.class
            scriptEntryClassPathStr = scriptEntryClassPathStr.replace("\\", "/"); // bin/server/serverscripts/activities/ActivitieValueScript.class
            if (scriptEntryClassPathStr.endsWith(".class") && !scriptEntryClassPathStr.equalsIgnoreCase(scriptEntryClassPath)) {
                BaseScriptClassLoader localBaseScriptClassLoader = this.baseScriptClassLoader;
                String scriptEntryClassName = scriptEntryClassPathStr.replace("/", ".").replace(".class", "").replace(this.scriptEntryCompileTo2, ""); // serverscripts.activities.ActivitieValueScript
                if (localBaseScriptClassLoader.loadScriptClass(scriptEntryClassName, scriptEntryClassPathStr) == null) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 编译JAVA源文件
     *
     * @param scriptEntryClassName java实体类名
     * @param sourceContent java源文件
     * @return
     * @throws IOException
     */
    private Class compileSource(String scriptEntryClassName, String sourceContent) throws IOException { // paramString1 = serverscripts.main.MainScript  paramString2 = java文件内容
        JavaCompiler localJavaCompiler = null;
        try {
            localJavaCompiler = ToolProvider.getSystemJavaCompiler(); // 本地java编译器
        } catch (Exception ex) {
            this.msg += "\r\n获得JAVA系统编译器失败";
            log.error(this.msg);
            return null;
        }
        if (localJavaCompiler == null) {
            this.msg += "\r\n编译器为空 == null";
            log.error(this.msg);
            return null;
        }
        log.error("\r\ncompiler != null");

        DiagnosticCollector diagnosticListener = new DiagnosticCollector(); // 诊断收集器
        if (diagnosticListener == null) {
            this.msg += "\r\n诊断收集器创建失败";
            log.error(this.msg);
            return null;
        }
        StandardJavaFileManager fileManager = localJavaCompiler.getStandardFileManager(diagnosticListener, null, null); // 标准的Java文件管理器
        if (fileManager == null) {
            this.msg += "\r\n标准的Java文件管理器加载失败";
            log.error(this.msg);
            return null;
        }

        BaseScriptClassLoader baseScriptClassLoader = this.baseScriptClassLoader;
        BaseScriptJavaFileObject baseScriptJavaFileObject = new BaseScriptJavaFileObject(this, scriptEntryClassName, sourceContent); 
        List<BaseScriptJavaFileObject> compilationUnits = new ArrayList<>();
        compilationUnits.add(baseScriptJavaFileObject);
        List<String> options = new ArrayList<>();
        options.add("-encoding");
        options.add("UTF-8");
        options.add("-classpath");
        options.add(this.urlClassLoaderInfo); // /E:/NetBeansProjects/lhcj/Libs/libs/GameCore.jar;/E:/NetBeansProjects/lhcj/Libs/libs/GameRecorder.jar;/E:/NetBeansProjects/lhcj/Libs/libs/LhcjCommon.jar;/E:/NetBeansProjects/lhcj/Libs/libs/asm-3.3.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/bean-validator-4.0.0.jar;/E:/NetBeansProjects/lhcj/Libs/libs/c3p0-0.9.1-pre6.jar;/E:/NetBeansProjects/lhcj/Libs/libs/cglib-2.2.2.jar;/E:/NetBeansProjects/lhcj/Libs/libs/common-gamelog-1.0.2.RELEASE.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-beanutils.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-codec.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-collections-3.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-dbutils-1.5.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-lang-2.4.jar;/E:/NetBeansProjects/lhcj/Libs/libs/commons-logging-1.1.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/ezmorph-1.0.6.jar;/E:/NetBeansProjects/lhcj/Libs/libs/fastjson-1.1.17.jar;/E:/NetBeansProjects/lhcj/Libs/libs/jakarta-oro-2.0.8.jar;/E:/NetBeansProjects/lhcj/Libs/libs/json-lib-2.3-jdk15.jar;/E:/NetBeansProjects/lhcj/Libs/libs/log4j-1.2.16.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mail.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mina-core-2.0.4.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mybatis-3.0.6.jar;/E:/NetBeansProjects/lhcj/Libs/libs/mysql-connector-java-5.0.7-bin.jar;/E:/NetBeansProjects/lhcj/Libs/libs/quartz-2.1.3.jar;/E:/NetBeansProjects/lhcj/Libs/libs/slf4j-api-1.6.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/slf4j-log4j12-1.6.1.jar;/E:/NetBeansProjects/lhcj/Libs/libs/tools.jar;/E:/NetBeansProjects/lhcj/LhcjServer/build/classes/;
        options.add("-sourcepath");
        options.add(this.scriptEntrySrc); // jbsrc
        options.add("-d");
        options.add(this.scriptEntryCompileTo); // bin/server

        // 获得JAVA编译器
        JavaCompiler.CompilationTask localCompilationTask = localJavaCompiler.getTask(null, fileManager, diagnosticListener, options, null, compilationUnits);
        boolean bool = localCompilationTask.call();
        fileManager.close();

        if (bool) {
            String scriptEntryClassPath = this.scriptEntryCompileTo + "/" + scriptEntryClassName.replace('.', '/') + ".class"; // bin/server/serverscripts/main/MainScript.class
            File binPath = new File(this.scriptEntryCompileTo); // bin/server
            if (compile(binPath, scriptEntryClassPath)) {
                Class clazz = baseScriptClassLoader.loadScriptClass(scriptEntryClassName, scriptEntryClassPath); // serverscripts.main.MainScript    bin/server/serverscripts/main/MainScript.class
                if (clazz == null) {
                    this.msg += "\r\nEntryclass 加载错误";
                }
                return clazz;
            }
            this.msg += "\r\nclass 加载错误";
        } else {
            Iterator<Diagnostic> it = diagnosticListener.getDiagnostics().iterator();
            while (it.hasNext()) {
                Diagnostic diagnostic = it.next();
                this.msg += buildDiagnosticInfo(diagnostic);
            }
        }
        return null;
    }

    private String buildDiagnosticInfo(Diagnostic diagnostic) {
        StringBuilder sb = new StringBuilder();
        sb.append("Code:[").append(diagnostic.getCode()).append("]\n");
        sb.append("Kind:[").append(diagnostic.getKind()).append("]\n");
        sb.append("Position:[").append(diagnostic.getPosition()).append("]\n");
        sb.append("Start Position:[").append(diagnostic.getStartPosition()).append("]\n");
        sb.append("End Position:[").append(diagnostic.getEndPosition()).append("]\n");
        sb.append("Source:[").append(diagnostic.getSource()).append("]\n");
        sb.append("Message:[").append(diagnostic.getMessage(null)).append("]\n");
        sb.append("LineNumber:[").append(diagnostic.getLineNumber()).append("]\n");
        sb.append("ColumnNumber:[").append(diagnostic.getColumnNumber()).append("]\n");
        return sb.toString();
    }

    public String getName() {
        return this.name;
    }

    /**
     * 验证脚本对象属性
     *
     * @param baseScript
     * @return
     */
    private boolean checkScriptFields(IBaseScript baseScript) {
        boolean bool = true;
        Field[] fields = baseScript.getClass().getDeclaredFields(); // 脚本公开属性
        if (fields != null) {
            for (Field field : fields) {
                if (field != null) {
                    int modifiers = field.getModifiers(); // 以整数形式返回由此 Field 对象表示的字段的 Java 语言修饰符。
                    Class fieldType = field.getType(); // 获得字段类型
                    if (!field.getName().startsWith("uck_")) { // TODO 非uck_开头的属性,既不是final的也不是
                        String error;
                        if ((!Modifier.isFinal(modifiers) || !Modifier.isStatic(modifiers)) && // 不是final类型或不是static类型
                                (!Modifier.isStatic(modifiers)
                                || (fieldType != baseScript.getClass()) || (!"obj".equalsIgnoreCase(field.getName()) && (!"s_instance".equalsIgnoreCase(field.getName())) && (!"s_me".equalsIgnoreCase(field.getName()))))) {
                            error = String.format("(%s 属性 %s)不是静态的,也不是常量; 并且类型也并非脚本类型 ;并且属性名称也不是(obj, s_instance, s_me)之一!!!!脚本验证不通过", baseScript.getClass().getName(), field.getName());
                            getErrors().add(error);
                            log.error(error);
                            bool = false;
                        }
                        if ((Collection.class.isAssignableFrom(fieldType)) || (Map.class.isAssignableFrom(fieldType)) || (AbstractCollection.class.isAssignableFrom(fieldType))
                                || (Vector.class.isAssignableFrom(fieldType)) || (Set.class.isAssignableFrom(fieldType)) || (Stack.class.isAssignableFrom(fieldType)) || (Queue.class.isAssignableFrom(fieldType))) {
                            error = String.format("(%s 属性 %s) 是 %s,需要使用uck_开头!!!!脚本验证不通过", baseScript.getClass().getName(), field.getName(), field.getType().getName());
                            getErrors().add(error);
                            log.error(error);
                            bool = false;
                        }
                    } else {
                        log.warn("uck_ 鍓嶇紑浼氬己鍒跺厑璁歌瀛楁鍔犺浇,浣嗗姟蹇呰纭繚 " + baseScript.getClass().getName() + "." + field.getName() + " 涓殑鏁版嵁鏄厑璁镐涪澶辩殑鏁版嵁锛屽惁鍒欒剼鏈噸杞藉彲鑳藉鑷存暟鎹涪澶�!!!");
                    }
                }
            }
        }
        return bool;
    }

    /**
     * 注册脚本,将脚本分别注册到nameAndScript 和 eventAndScript中.并执行初始化操作
     *
     * @param baseScript
     * @param paramInt
     */
    private void requireScript(IBaseScript baseScript, int paramInt) {
        if (checkScriptFields(baseScript)) {
            this.nameAndScript.put(baseScript.getSimpleName(), baseScript); // BaseActivities
            String[] events = baseScript.getEventList(); // [] {com.game.activities.script.IBaseActivityScript, com.game.server.script.IPlayerMidNightScript, com.game.server.script.IServerMidNightScript,com.game.player.script.IPlayerHandlerActionScript,com.game.player.script.IPlayerLoginEndScript ... }
            if (events != null && events.length > 0) {
                for (String event : events) {
                    List<IBaseScript> list;
                    if (this.eventAndScript.containsKey(event)) {
                        list = this.eventAndScript.get(event);
                        if (list == null) {
                            list = new ArrayList<>();
                            this.eventAndScript.put(event, list);
                        }
                        if (!list.contains(baseScript)) {
                            list.add(baseScript);
                        }
                    } else {
                        list = new ArrayList<>();
                        this.eventAndScript.put(event, list); // com.game.activities.script.IBaseActivityScript
                        if (!list.contains(baseScript)) {
                            list.add(baseScript);
                        }
                    }
                }
            }
            log.info(String.format("执行脚本对象初始化操作 init (%s)", baseScript.getClass().getName()));
            baseScript.init(paramInt, this);
        }
    }

    public boolean needUpdateQuickScript(quickScriptObj paramquickScriptObj) {
        return (paramquickScriptObj != null) && ((paramquickScriptObj.scriptID != this.scriptID) || (paramquickScriptObj.script == null));
    }

    public boolean getUpdateFirstEvt(quickScriptObj quickScript) {
        if (needUpdateQuickScript(quickScript) && quickScript.evtname != null && !quickScript.evtname.equals("")) {
            List events = getEvts(quickScript.evtname);
            if (events != null && !events.isEmpty()) {
                if ((quickScript.className != null) && (!quickScript.className.equals(""))) {
                    for (int i1 = 0; i1 < events.size(); i1++) {
                        IBaseScript localIBaseScript = (IBaseScript) events.get(i1);
                        if ((localIBaseScript.getName().equals(quickScript.className)) || (localIBaseScript.getSimpleName().equals(quickScript.className))) {
                            quickScript.scriptID = this.scriptID;
                            quickScript.script = ((IBaseScript) events.get(i1));
                            break;
                        }
                    }
                } else {
                    quickScript.scriptID = this.scriptID; // 1405402916122
                    quickScript.script = ((IBaseScript) events.get(0)); // 如DebugScript对象
                }
            }
        }
        return true;
    }

    public quickScriptObj getFirstEvt(String paramString1, String paramString2) {// com.game.debug.script.IDebugScript  null
        quickScriptObj localquickScriptObj = new quickScriptObj(this);
        localquickScriptObj.scriptID = 0L;
        localquickScriptObj.evtname = paramString1;
        localquickScriptObj.className = paramString2;
        localquickScriptObj.script = null;
        getUpdateFirstEvt(localquickScriptObj);
        return localquickScriptObj;
    }

    public quickScriptObj getFirstEvt(String paramString) {
        return getFirstEvt(paramString, null);
    }

//    public Object callScript(Class paramClass, IBaseScriptCaller paramIBaseScriptCaller, Object... paramVarArgs) {
//        Object localObject = null;
//        ArrayList localArrayList = getEvts(paramClass.getName());
//        if (localArrayList != null && !localArrayList.isEmpty()) {
//            Iterator localIterator = localArrayList.iterator();
//            while (localIterator.hasNext()) {
//                IBaseScript localIBaseScript = (IBaseScript) localIterator.next();
//                if (localIBaseScript != null) {
//                    try {
//                        localObject = paramIBaseScriptCaller.callScript(localIBaseScript, paramVarArgs);
//                    } catch (Exception ex) {
//                        log.error(paramClass.getName() + "=" + paramIBaseScriptCaller.getClass().getName(), ex);
//                    }
//                }
//            }
//        }
//        return localObject;
//    }

    public List<IBaseScript> getEvts(String event) {
        List<IBaseScript> events = this.eventAndScript.get(event);
        if (events != null) {
            return events;
        }
        synchronized (this.syncObj) {
            events = this.eventAndScriptDump.get(event);
            if (events != null) {
                return events;
            }
        }
        return null;
    }

    public void clearEvts(String event) {
        if (event != null && !event.trim().equals("")) {
            List<IBaseScript> events = this.eventAndScript.get(event);
            this.eventAndScript.remove(event);
            if (events != null) events.clear();
        } else if (event == null) {
            Iterator<List<IBaseScript>> it = this.eventAndScript.values().iterator();
            while (it.hasNext()) {
                List<IBaseScript> events = it.next();
                if (events != null) events.clear();
            }
            this.eventAndScript.clear();
        }
    }

    public boolean require(IBaseScript baseScript, int paramInt) {
        if (baseScript != null) {
            try {
                if (baseScript.getName() != null && !baseScript.getName().trim().equals("")) {
                    requireScript(baseScript, paramInt);
                    return true;
                }
            } catch (Exception ex) {
                log.error(String.format("require error (%s)", baseScript.getName()), ex);
            }
            getErrors().add(String.format("%s require fail!!!!", baseScript.getClass().getName()));
        } else {
            getErrors().add("require null fail!!!!");
        }
        return false;
    }

    public boolean require_once(IBaseScript paramIBaseScript, int paramInt) {
        if (paramIBaseScript != null) {
            if ((paramIBaseScript.getName() != null) && (!paramIBaseScript.getName().isEmpty())) {
                if (!this.nameAndScript.containsKey(paramIBaseScript.getSimpleName())) {
                    return require(paramIBaseScript, paramInt);
                }
                getErrors().add(String.format("%s require duplicate fail!!!!", paramIBaseScript.getClass().getName()));
                return false;
            }
            getErrors().add(String.format("%s(name empty) require fail!!!!", paramIBaseScript.getClass().getName()));
        } else {
            getErrors().add(String.format("require null fail!!!!"));
        }
        return false;
    }

    private boolean swap(int scriptEntryCompileType) {
        synchronized (this.syncObj) {
            this.nameAndScriptDump.clear();
            this.nameAndScriptDump.putAll(this.nameAndScript);
            this.nameAndScript.clear();
            this.eventAndScriptDump.clear();
            this.eventAndScriptDump.putAll(this.eventAndScript);
            this.eventAndScript.clear();
            this.swapState.set(true);
        }
        return true;
    }

    /**
     * 还原
     *
     * @param scriptEntryCompileType
     * @return
     */
    private boolean back(int scriptEntryCompileType) {
        synchronized (this.syncObj) {
            if (this.nameAndScript.isEmpty() && !this.nameAndScriptDump.isEmpty()) {
                this.nameAndScript.putAll(this.nameAndScriptDump);
                this.nameAndScriptDump.clear();
            }
            if (this.eventAndScript.isEmpty() && !this.eventAndScriptDump.isEmpty()) {
                this.eventAndScript.putAll(this.eventAndScriptDump);
                this.eventAndScriptDump.clear();
            }
        }
        return true;
    }

    /**
     * 清理
     *
     * @param scriptEntryCompileType 基础脚本实体编译类型 SERVER_LOAD
     * @return
     */
    private boolean clear_dump(int scriptEntryCompileType) {
        synchronized (this.syncObj) {
            this.nameAndScriptDump.clear();
            this.eventAndScriptDump.clear();
            this.swapState.set(false);
        }
        return true;
    }

    /**
     * @param scriptEntryCompileType 基础脚本实体编译类型 SERVER_LOAD
     * @return
     */
    public boolean clear_require(int scriptEntryCompileType) {
        this.nameAndScript.clear();
        this.eventAndScript.clear();
        return true;
    }
}
