package com.game.engine.thread.map.conf;

import com.game.engine.object.GameObject;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 地图信息
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class MapInfo extends GameObject {

    private static final long serialVersionUID = -8549637893123656227L;
    private static Logger log = LoggerFactory.getLogger(MapInfo.class);

//    //地区列表
//    private final HashMap<Integer, Area> areas = new HashMap<Integer, Area>();
//    private ConcurrentHashSet<Area> syncareas = new ConcurrentHashSet<Area>();
//    //玩家列表
//    private HashMap<Long, Player> players = new HashMap<Long, Player>();
//    //怪物列表
//    private HashMap<Long, Monster> monsters = new HashMap<Long, Monster>();
//    //宠物列表
//    private HashMap<Long, Pet> pets = new HashMap<Long, Pet>();
//    //跑动怪物列表
//    private HashMap<Long, Monster> runningMonsters = new HashMap<Long, Monster>();
//    //跑动宠物列表
//    private HashMap<Long, Pet> runningPets = new HashMap<Long, Pet>();
//    //跑动玩家列表
//    private HashMap<Long, Player> runningPlayers = new HashMap<Long, Player>();
//    //格挡玩家列表
//    private HashMap<Long, Player> blockingPlayers = new HashMap<Long, Player>();
//    //等待复活怪物列表
//    private HashMap<Long, Monster> revives = new HashMap<Long, Monster>();
    //地图陷阱点列表
    private HashMap<Integer, Object> trappingsites = new HashMap<>();
    //地图模块Id
    private int mapModelid;
    //所在线
    private int lineId;
    //所在服务器
    private int serverId;
    //地图是否为副本
    private boolean copy;
    //地图绑定副本
    private long zoneId;
    //地图绑定副本模板
    private int zoneModelId;
    //地图创建时间
    private long create;
    //地图视野范围
    private int round;
    //地图宽度
    private int width;
    //地图高度
    private int height;
    //统计地图最大人数
    private int maxplayercount;
    //是否刷出普通怪物
    private boolean boCommonMonster;
    //最后一个玩家离开地图的时间
    private long playerQuitMapTime;
    //发送Id
    private long sendId;
    //临时参数列表
    private Map<String, Object> parameters = new ConcurrentHashMap<>();

    public int getLineId() {
        return lineId;
    }

    public void setLineId(int lineId) {
        this.lineId = lineId;
    }

    public int getServerId() {
        return serverId;
    }

    public void setServerId(int serverId) {
        this.serverId = serverId;
    }

//    public ConcurrentHashSet<Area> getSyncAreas() {
//        return syncareas;
//    }
//
//    public Area getAreaById(int areaid) {
//        Area r = areas.get(areaid);
//        if (r == null) {
//            short w = (short) (areaid / 1000);
//            short h = (short) (areaid % 1000);
//            if (MapManager.getInstance().getAreaId(new Position((short) (w * MapManager.AREA_WIDTH), (short) (h * MapManager.AREA_HEIGHT))) == areaid) {
//                if (w >= 0 && w < width && h >= 0 && h < height) {
//                    synchronized (areas) {
//                        r = areas.get(areaid);
//                        if (r == null) {
//                            r = new Area();
//                            r.setId(areaid);
//                            areas.put(areaid, r);
//                            syncareas.add(r);
//                        }
//                    }
//                    return r;
//                }
//            }
//            return null;
//        } else {
//            return r;
//        }
//    }
//
//    public void removeArea(Iterator<Area> iter, Area r) {
//        synchronized (areas) {
//            iter.remove();
//            areas.remove((int) r.getId());
//            syncareas.remove(r);
//        }
//    }
//
//    /**
//     * 刷新地图
//     */
//    public void refreshMapAll() {
//        if (!this.isBoCommonMonster()) {
//            try {
//                MonsterManager.getInstance().initCommonMonster(this.getServerId(), this.getLineId(), (int) this.getId(), this.getMapModelid());
//            } catch (Exception e) {
//                WServer.errorlog.error(this.getClass().getName() + "：action = refreshMapAll = error :" + this.getMonsters().size(), e);
//            } finally {
//                this.setBoCommonMonster(true);
//                WServer.errorlog.error(this.getClass().getName() + "：action = refreshMapAll = ok : " + this.getMonsters().size());
//            }
//        }
//    }
//
//    /**
//     * 删除地图
//     */
//    public void deleteMapAll() {
//        try {
//            if (isCanDelete()) {
//                MonsterManager instance = MonsterManager.getInstance();
//                Iterator<Monster> iterator2 = this.getRunningMonsters().values().iterator();
//                while (iterator2.hasNext()) {
//                    Monster monster = iterator2.next();
//                    if (instance.isCommon(monster.getModelId())) {
//                        monster.reset();
//                        int areaId = ManagerPool.mapManager.getAreaId(monster.getPosition());
//                        //获得怪物所在区域
//                        Area area = this.getAreaById(areaId);
//                        if (area != null) {
//                            if (!area.getMonsters().containsKey(monster.getId())) {
//                                Iterator<Area> areas = this.getSyncAreas().iterator();
//                                while (areas.hasNext()) {
//                                    Area area2 = (Area) areas.next();
//                                    if (area2.getMonsters().containsKey(monster.getId())) {
//                                        area2.getMonsters().remove(monster.getId());
//                                    }
//                                }
//                            }
//                            //地图上移除怪物
//                            area.getMonsters().remove(monster.getId());
//                        }
//                        iterator2.remove();
//                    }
//                }
//                Iterator<Monster> iterator1 = this.getRevives().values().iterator();
//                while (iterator1.hasNext()) {
//                    Monster monster = iterator1.next();
//                    if (instance.isCommon(monster.getModelId())) {
//                        monster.reset();
//                        int areaId = ManagerPool.mapManager.getAreaId(monster.getPosition());
//                        //获得怪物所在区域
//                        Area area = this.getAreaById(areaId);
//                        if (area != null) {
//                            if (!area.getMonsters().containsKey(monster.getId())) {
//                                Iterator<Area> areas = this.getSyncAreas().iterator();
//                                while (areas.hasNext()) {
//                                    Area area2 = (Area) areas.next();
//                                    if (area2.getMonsters().containsKey(monster.getId())) {
//                                        area2.getMonsters().remove(monster.getId());
//                                    }
//                                }
//                            }
//                            //地图上移除怪物
//                            area.getMonsters().remove(monster.getId());
//                        }
//                        iterator1.remove();
//                    }
//                }
//                Iterator<Monster> iterator = this.getMonsters().values().iterator();
//                while (iterator.hasNext()) {
//                    Monster monster = iterator.next();
//                    if (instance.isCommon(monster.getModelId())) {
//                        monster.reset();
//                        int areaId = ManagerPool.mapManager.getAreaId(monster.getPosition());
//                        //获得怪物所在区域
//                        Area area = this.getAreaById(areaId);
//                        if (area != null) {
//                            if (!area.getMonsters().containsKey(monster.getId())) {
//                                Iterator<Area> areas = this.getSyncAreas().iterator();
//                                while (areas.hasNext()) {
//                                    Area area2 = (Area) areas.next();
//                                    if (area2.getMonsters().containsKey(monster.getId())) {
//                                        area2.getMonsters().remove(monster.getId());
//                                    }
//                                }
//                            }
//                            //地图上移除怪物
//                            area.getMonsters().remove(monster.getId());
//                        }
//                        iterator.remove();
//                    }
//                }
//                Iterator<Area> iterator3 = this.getSyncAreas().iterator();
//                while (iterator3.hasNext()) {
//                    Area area = iterator3.next();
//                    if (area.isEmpty()) {
//                        this.removeArea(iterator3, area);
//                    }
//                }
//                this.setBoCommonMonster(false);
//            }
//        } catch (Exception e) {
//            WServer.errorlog.error(this.getClass().getName() + "：action = deleteMapAll = error :" + this.getMonsters().size(), e);
//        } finally {
////            WServer.errorlog.error(this.getClass().getName() + "：action = deleteMapAll = ok : " + this.getMonsters().size());
//        }
//    }
    public boolean isCanDelete() {
        if (!isCopy() && isBoCommonMonster() && isEmpty() && playerQuitMapTime != 0) {
            long time = System.currentTimeMillis() - playerQuitMapTime;
            if (maxplayercount < 15) {
                if (time > 15 * 60 * 1000) {
                    return true;
                }
            } else if (maxplayercount < 25) {
                if (time > 20 * 60 * 1000) {
                    return true;
                }
            } else if (maxplayercount < 45) {
                if (time > 30 * 60 * 1000) {
                    return true;
                }
            } else if (maxplayercount < 200) {
                if (time > 45 * 60 * 1000) {
                    return true;
                }
            } else {
                if (time > 60 * 60 * 1000) {
                    return true;
                }
            }
        }
        return false;
    }

    public int getMapModelid() {
        return mapModelid;
    }

    public void setMapModelid(int mapModelid) {
        this.mapModelid = mapModelid;
    }

//    public HashMap<Long, Player> getPlayers() {
//        return players;
//    }
//
//    public void setPlayers(HashMap<Long, Player> players) {
//        this.players = players;
//    }
//
//    public HashMap<Long, Monster> getMonsters() {
//        return monsters;
//    }
//
//    public void setMonsters(HashMap<Long, Monster> monsters) {
//        this.monsters = monsters;
//    }
//
//    public HashMap<Long, Pet> getPets() {
//        return pets;
//    }
//
//    public void setPets(HashMap<Long, Pet> pets) {
//        this.pets = pets;
//    }
//
//    public HashMap<Long, Monster> getRunningMonsters() {
//        return runningMonsters;
//    }
//
//    public void setRunningMonsters(HashMap<Long, Monster> runningMonsters) {
//        this.runningMonsters = runningMonsters;
//    }
//
//    public HashMap<Long, Player> getRunningPlayers() {
//        return runningPlayers;
//    }
//
//    public void setRunningPlayers(HashMap<Long, Player> runningPlayers) {
//        this.runningPlayers = runningPlayers;
//    }
//
//    public HashMap<Long, Pet> getRunningPets() {
//        return runningPets;
//    }
//
//    public void setRunningPets(HashMap<Long, Pet> runningPets) {
//        this.runningPets = runningPets;
//    }
//
//    public HashMap<Long, Player> getBlockingPlayers() {
//        return blockingPlayers;
//    }
//
//    public void setBlockingPlayers(HashMap<Long, Player> blockingPlayers) {
//        this.blockingPlayers = blockingPlayers;
//    }
//
//    public HashMap<Long, Monster> getRevives() {
//        return revives;
//    }
//
//    public void setRevives(HashMap<Long, Monster> revives) {
//        this.revives = revives;
//    }
    public HashMap<Integer, Object> getTrappingsites() {
        return trappingsites;
    }

    public void setTrappingsites(HashMap<Integer, Object> trappingsites) {
        this.trappingsites = trappingsites;
    }

    public boolean isCopy() {
        return copy;
    }

    public void setCopy(boolean copy) {
        this.copy = copy;
    }

    public long getZoneId() {
        return zoneId;
    }

    public void setZoneId(long zoneId) {
        this.zoneId = zoneId;
    }

    public int getZoneModelId() {
        return zoneModelId;
    }

    public void setZoneModelId(int zoneModelId) {
        this.zoneModelId = zoneModelId;
    }

    public long getCreate() {
        return create;
    }

    public void setCreate(long create) {
        this.create = create;
    }

//    public int getPlayerNumber() {
//        return players.size();
//    }
    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getMaxplayercount() {
        return maxplayercount;
    }

    public void setMaxplayercount(int maxplayercount) {
        this.maxplayercount = maxplayercount;
    }

    public boolean isBoCommonMonster() {
        return boCommonMonster;
    }

    public void setBoCommonMonster(boolean boCommonMonster) {
        this.boCommonMonster = boCommonMonster;
    }

    public long getPlayerQuitMapTime() {
        return playerQuitMapTime;
    }

    public void setPlayerQuitMapTime(long playerQuitMapTime) {
        this.playerQuitMapTime = playerQuitMapTime;
    }

    public long getSendId() {
        return sendId;
    }

    public void setSendId(long sendId) {
        this.sendId = sendId;
    }

    /**
     * 地图上是否有玩家
     *
     * @return
     */
    public boolean isEmpty() {
        // TODO 正式版本删除行注释 return players.size() == 0;
        return true;
    }

//    /**
//     * 地图上是否有活着的玩家 true 全部死亡 false 还有幸存者
//     *
//     * @return
//     */
//    public boolean isAllDie() {
//        Iterator<Player> iterator = players.values().iterator();
//        while (iterator.hasNext()) {
//            Player player = iterator.next();
//            if (player != null && !player.isDie()) {
//                return false;
//            }
//        }
//        return true;
//    }
//
    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(ConcurrentHashMap<String, Object> parameters) {
        this.parameters = parameters;
    }
}
