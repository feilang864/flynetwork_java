package com.game.engine.io.mina.impl;

import com.game.engine.io.conf.MinaServerConfig;
import com.game.engine.io.mina.code.ServerProtocolCodecFactory;
import com.game.engine.io.mina.handler.ServerProtocolHandler;
import java.io.IOException;
import java.net.InetSocketAddress;
import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.executor.ExecutorFilter;
import org.apache.mina.filter.executor.OrderedThreadPoolExecutor;
import org.apache.mina.transport.socket.SocketSessionConfig;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 * @author Vicky
 */
public class MinaServer implements Runnable {
    
    private static final Logger log = LoggerFactory.getLogger(MinaServer.class);

    private final MinaServerConfig minaServerConfig;

    private final NioSocketAcceptor acceptor;

    private final ServerProtocolHandler ioHandler;

    private final IoHandler ioHandlerSSL;
    
    protected boolean isRunning = false;

    public MinaServer(MinaServerConfig minaServerConfig, ServerProtocolHandler ioHandler) {
        this.minaServerConfig = minaServerConfig;
        this.ioHandler = ioHandler;
        this.ioHandlerSSL = null;

        acceptor = new NioSocketAcceptor();
    }

    public MinaServer(MinaServerConfig minaServerConfig, ServerProtocolHandler ioHandler, IoHandler ioHandlerSSL) {
        this.minaServerConfig = minaServerConfig;
        this.ioHandler = ioHandler;
        this.ioHandlerSSL = ioHandlerSSL;

        acceptor = new NioSocketAcceptor();
    }
    
    @Override
    public void run() {
        synchronized (this) {
            if (!isRunning) {
                isRunning = true;
                new Thread(new ConnectServer(this)).start();

                if (minaServerConfig.getSslPort() > 0) {
                    new Thread(new SSLConnectServer(this)).start();
                }
            }
        }
    }

    public void stop() {
        synchronized (this) {
            if (!isRunning) {
                log.info("Server " + minaServerConfig.getName() + "is already stoped.");
                return;
            }
            isRunning = false;
            try {
                acceptor.unbind();
                acceptor.dispose();
                log.info("Server is stoped.");
            } catch (Exception ex) {
                log.error("", ex);
            }
        }
    }

    private class ConnectServer
            implements Runnable {

        private final Logger log = LoggerFactory.getLogger(ConnectServer.class);
        private final MinaServer server;

        public ConnectServer(MinaServer server) {
            this.server = server;
        }

        @Override
        public void run() {
            DefaultIoFilterChainBuilder chain = acceptor.getFilterChain();
            // 编码过滤器
            chain.addLast("codec", new ProtocolCodecFilter(new ServerProtocolCodecFactory<>(server.minaServerConfig)));
            // 线程队列池
            OrderedThreadPoolExecutor threadpool = new OrderedThreadPoolExecutor(server.minaServerConfig.getOrderedThreadPoolExecutorSize());
            chain.addLast("threadPool", new ExecutorFilter(threadpool));

            server.acceptor.setReuseAddress(server.minaServerConfig.isReuseAddress()); // 允许地址重用

            // 配置SessionConfig
            SocketSessionConfig sc = server.acceptor.getSessionConfig();
            sc.setReuseAddress(server.minaServerConfig.isReuseAddress());
            sc.setReceiveBufferSize(server.minaServerConfig.getReceiveBufferSize());
            sc.setSendBufferSize(server.minaServerConfig.getSendBufferSize());
            sc.setTcpNoDelay(server.minaServerConfig.isTcpNoDelay());
            sc.setSoLinger(server.minaServerConfig.getSoLinger());
            sc.setIdleTime(IdleStatus.READER_IDLE, server.minaServerConfig.getReaderIdleTime());
            sc.setIdleTime(IdleStatus.WRITER_IDLE, server.minaServerConfig.getWriterIdleTime());

            server.acceptor.setHandler(server.ioHandler);

            try {
                server.acceptor.bind(new InetSocketAddress(server.minaServerConfig.getPort()));
                this.log.info("Mina Server " + server.minaServerConfig.getName() + " Start At Port " + server.minaServerConfig.getPort());
            } catch (IOException e) {
                this.log.error("Mina Server " + server.minaServerConfig.getName() + " Port " + server.minaServerConfig.getPort() + "Already Use:" + e.getMessage());
                System.exit(1);
            }
        }
    }

    private class SSLConnectServer
            implements Runnable {

        private final Logger log = LoggerFactory.getLogger(SSLConnectServer.class);
        private final MinaServer server;

        public SSLConnectServer(MinaServer server) {
            this.server = server;
        }

        @Override
        public void run() {
            NioSocketAcceptor acceptor = new NioSocketAcceptor();
            acceptor.setHandler(ioHandlerSSL);
            try {
                acceptor.bind(new InetSocketAddress(server.minaServerConfig.getSslPort()));
                this.log.info("Mina SSL Server " + server.minaServerConfig.getName() + " Start At Port " + server.minaServerConfig.getSslPort());
            } catch (IOException e) {
                this.log.error("Mina SSL Server " + server.minaServerConfig.getName() + " Port " + server.minaServerConfig.getSslPort() + "Already Use:" + e.getMessage());
            }
        }
    }
}
