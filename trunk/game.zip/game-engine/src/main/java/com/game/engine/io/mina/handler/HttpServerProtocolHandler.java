package com.game.engine.io.mina.handler;

import com.game.engine.io.commmand.IHandler;
import com.game.engine.io.message.HttpMessageBean;
import com.game.engine.io.message.HttpMessagePool;
import com.game.engine.io.mina.code.HttpRequestMessage;
import java.util.concurrent.Executor;
import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public abstract class HttpServerProtocolHandler implements IoHandler {

    private static final Logger log = LoggerFactory.getLogger(HttpServerProtocolHandler.class);

    @Override
    public void sessionOpened(IoSession session) {
        // set idle time to 60 seconds   
        session.getConfig().setIdleTime(IdleStatus.BOTH_IDLE, 60);
    }

    @Override
    public void messageReceived(IoSession ioSession, Object message) {
        // Check that we can service the request context
        HttpRequestMessage httpRequest = (HttpRequestMessage) message;
        
        HttpMessageBean httpMessageBean = getMessagePool().getMessageBean(httpRequest.getContext());
        if (httpMessageBean == null) {
            log.error(String.format("HttpMessagePoll 未能找到 content = %s 的 httpMessageBean", httpRequest.getContext()));
            return;
        }
        
        try {
            IHandler handler = httpMessageBean.newHandler();
            //获取消息体
            // handler.setParameter(new HttpResponseMessage());
            handler.setMessage(httpRequest);
            handler.setSession(ioSession);
            handler.setCreateTime(System.currentTimeMillis());
            
            Executor executor = getMessagePool().getExecutor(httpMessageBean.getThreadModel());
            executor.execute(handler);
        } catch (InstantiationException | IllegalAccessException ex) {
            log.error("messageReceived build message error !!! ", ex);
        }
    }

    @Override
    public void sessionIdle(IoSession session, IdleStatus status) {
        session.close(false);
    }

    @Override
    public void exceptionCaught(IoSession session, Throwable cause) {
        session.close(false);
    }

    @Override
    public void sessionCreated(IoSession session) throws Exception {
        log.debug("http请求建立" + session);
    }

    @Override
    public void sessionClosed(IoSession session) throws Exception {
        log.debug("http请求断开" + session);
    }

    @Override
    public void messageSent(IoSession session, Object message) throws Exception {
    }
    
    protected abstract HttpMessagePool getMessagePool();
}
