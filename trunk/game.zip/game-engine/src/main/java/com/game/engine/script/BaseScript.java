package com.game.engine.script;

/**
 * 
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class BaseScript implements IBaseScript {

    // id计数器
    private static int autoID = 1000;
    
    // 脚本ID,自增
    private final int id;

    public BaseScript() {
        synchronized (BaseScript.class) {
            autoID += 1;
            this.id = autoID;
        }
    }

    @Override
    public String getVer() {
        return null;
    }

    @Override
    public String getName() {
        return getClass().getName();
    }

    @Override
    public String getSimpleName() {
        return getClass().getSimpleName();
    }

    /**
     * 返回该脚本对象类,实现了多少个IBaseScript接口,并返回IBaseScript接口名称
     * @return 
     */
    @Override
    public String[] getEventList() {
        Class[] interfaces = getClass().getInterfaces(); // 获得类实现的接口
        int baseScriptCount = 0;
        for (Class clazz : interfaces) {
            if (IBaseScript.class.isAssignableFrom(clazz) && clazz != IBaseScript.class) { // 接口,必须是IBaseScript的子接口,并且不是原始的IBaseScript接口
                baseScriptCount++;
            }
        }
        
        // 获得了类实现了IBaseScript的子接口的数量
        if (baseScriptCount == 0) {
            return null;
        }
        String[] interfaceNames = new String[baseScriptCount];
        baseScriptCount = 0;
        for (Class clazz : interfaces) {
            if (IBaseScript.class.isAssignableFrom(clazz) && clazz != IBaseScript.class) {
                interfaceNames[baseScriptCount] = clazz.getName();
                baseScriptCount++;
            }
        }
        return interfaceNames;
    }

    @Override
    public boolean init(int paramInt, BaseScriptEntry paramBaseScriptEntry) {
        return true;
    }

    @Override
    public boolean uninit(int paramInt, BaseScriptEntry paramBaseScriptEntry) {
        return true;
    }

    @Override
    public int getOnlyId() {
        return this.id;
    }
}
