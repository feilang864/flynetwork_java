package com.game.engine.io.mina.utils;

import java.net.InetSocketAddress;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 * @author Vicky
 */
public class SessionUtil {

    private static final Logger log = LoggerFactory.getLogger(SessionUtil.class);

    public static void close(IoSession session, String reason) {
        log.error(String.format("%s -->close [because] %s", session.toString(), reason));
        session.close(true);
    }

    public static void close(IoSession session, String fmt, Object... args) {
        String reason = String.format(fmt, args);
        log.error(String.format("%s -->close [because] %s", session.toString(), reason));
        session.close(true);
    }

    public static String getIp(IoSession session) {
        if (session == null || !session.isConnected()) return null;
        String ip = null;
        InetSocketAddress remoteAddress = (InetSocketAddress) session.getRemoteAddress();
        if (remoteAddress != null) {
            ip = remoteAddress.getAddress().getHostAddress();
        }
        return ip;
    }
}
