package com.game.engine.io.commmand;

import org.apache.mina.core.session.IoSession;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public interface IHandler extends Runnable {

    IoSession getSession();

    void setSession(IoSession session);

    Object getMessage();

    void setMessage(Object message);

    Object getParameter();

    void setParameter(Object parameter);

    long getCreateTime();

    void setCreateTime(long createTime);

    int getMapThreadQueue();

    void setMapThreadQueue(int mapThreadQueue);
}
