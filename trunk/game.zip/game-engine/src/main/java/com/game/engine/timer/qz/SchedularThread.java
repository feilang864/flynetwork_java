package com.game.engine.timer.qz;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
import java.util.ArrayList;
import java.util.List;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedularThread
        extends Thread {

    private static final Object obj = new Object();
    private static final Logger log = LoggerFactory.getLogger(SchedularThread.class);
    
    private final List<SchedulerInfo> infos = new ArrayList();
    
    private int count = 0;
    private Scheduler scheduler;


    @Override
    public void run() {
        try {
            synchronized (obj) {
                this.scheduler = StdSchedulerFactory.getDefaultScheduler();
                this.scheduler.start();
                init();
            }
        } catch (SchedulerException e) {
            log.error("QZ定时器执行异常", e);
        }
    }

    private void init() {
        for (SchedulerInfo info1 : this.infos) {
            SchedulerInfo info = (SchedulerInfo) info1;
            try {
                this.scheduler.scheduleJob(info.getJob(), info.getTrigger());
            } catch (SchedulerException e) {
                log.error("QZ定时器初始异常", e);
            }
        }
    }

    public Scheduler getScheduler() {
        return this.scheduler;
    }

    public void addSchedulerTask(String cron, String className) {
        this.count += 1;
        JobDetail job = JobBuilder.newJob(SchedulerTask.class).withIdentity("job" + this.count, "SchedulerTaskGroup").usingJobData("className", className).build();

        Trigger trigger = TriggerBuilder.newTrigger().withIdentity("trigger" + this.count, "SchedulerTaskGroup").withSchedule(CronScheduleBuilder.cronSchedule(cron)).forJob("job" + this.count, "SchedulerTaskGroup").build();
        synchronized (obj) {
            if (this.scheduler == null) {
                this.infos.add(new SchedulerInfo(job, trigger));
            } else {
                try {
                    this.scheduler.scheduleJob(job, trigger);
                } catch (SchedulerException e) {
                    log.error("QZ定时器添加任务异常", e);
                }
            }
        }
    }

    public void stop(boolean flag) {
        try {
            this.scheduler.shutdown(flag);
        } catch (SchedulerException e) {
            log.error("QZ定时器关闭异常", e);
        }
    }

    private class SchedulerInfo {

        private final JobDetail job;
        private final Trigger trigger;

        public SchedulerInfo(JobDetail job, Trigger trigger) {
            this.job = job;
            this.trigger = trigger;
        }

        public JobDetail getJob() {
            return this.job;
        }

        public Trigger getTrigger() {
            return this.trigger;
        }
    }
    
//    public static void main(String[] args) {
//        // 初始化定时线程
//        SchedularThread wSchedularThread = new SchedularThread();
//        wSchedularThread.start();
//        
//        //执行时间
//	String scheduler_time = "0 0 0 * * ?"; // 每天0点执行
//        scheduler_time = "* * * * * ?"; // 每秒执行
//        scheduler_time = "*/10 * * * * ?"; // 每10秒执行
//        
//	//执行函数
//	String scheduler_class = "com.game.timer.qz.At0ClockEvent";
//        wSchedularThread.addSchedulerTask(scheduler_time, scheduler_class);
//        try {
//            Thread.sleep(100000L);
//        } catch (InterruptedException ex) {
//            ex.printStackTrace();
//        }
//    }
}
