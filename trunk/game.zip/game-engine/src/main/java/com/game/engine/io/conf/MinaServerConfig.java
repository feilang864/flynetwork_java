package com.game.engine.io.conf;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 * 主要配置Mina服务器相关配置
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
@Root
public class MinaServerConfig
        extends BaseServerConfig {
    
    // 大区
    @Element(required = true)
    private int zoneid;
    
    // 大区名称
    @Element(required = true)
    private String zonename;

    // mina地址
    @Element(required = true)
    private String ip;
    
    // mina端口
    @Element(required = true)
    private int port = 8888;

    // mina ssl端口 0表示默认不开启
    @Element(required = false)
    private int sslport = 0;

    // http服务器地址
    @Element(required = false)
    private String url;

    // 服务器线程池大小
    @Element(required = true)
    private int orderedThreadPoolExecutorSize = 300;
    
    // ==============================================以下是sessionconfig的配置
    // 接收数据缓冲大小
    @Element(required = true)
    private int receiveBufferSize = 5120;

    // 发送数据缓冲大小
    @Element(required = true)
    private int sendBufferSize = 20480;

    // 是否重用地址
    @Element(required = true)
    private boolean reuseAddress = true;

    // Tcp没有延迟
    @Element(required = true)
    private boolean tcpNoDelay = true;

    // 读取空闲时间检测
    @Element(required = true)
    private int readerIdleTime = 30;

    // 写入空闲时间检测
    @Element(required = true)
    private int writerIdleTime = 0;

    @Element(required = true)
    private int soLinger = 0;
    
    // 版本信息
    @Element(required = true)
    private String version;

    // ==============================================以上是sessionconfig的配置
    public int getZoneid() {
        return zoneid;
    }

    public void setZoneid(int zoneid) {
        this.zoneid = zoneid;
    }

    public String getZonename() {
        return zonename;
    }

    public void setZonename(String zonename) {
        this.zonename = zonename;
    }
    
    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getSslPort() {
        return sslport;
    }

    public void setSslport(int sslport) {
        this.sslport = sslport;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getOrderedThreadPoolExecutorSize() {
        return orderedThreadPoolExecutorSize;
    }

    @Deprecated
    public void setOrderedThreadPoolExecutorSize(int orderedThreadPoolExecutorSize) {
        this.orderedThreadPoolExecutorSize = orderedThreadPoolExecutorSize;
    }

    public int getReceiveBufferSize() {
        return receiveBufferSize;
    }

    @Deprecated
    public void setReceiveBufferSize(int receiveBufferSize) {
        this.receiveBufferSize = receiveBufferSize;
    }

    public int getSendBufferSize() {
        return sendBufferSize;
    }

    @Deprecated
    public void setSendBufferSize(int sendBufferSize) {
        this.sendBufferSize = sendBufferSize;
    }

    public boolean isReuseAddress() {
        return reuseAddress;
    }

    @Deprecated
    public void setReuseAddress(boolean reuseAddress) {
        this.reuseAddress = reuseAddress;
    }

    public boolean isTcpNoDelay() {
        return tcpNoDelay;
    }

    @Deprecated
    public void setTcpNoDelay(boolean tcpNoDelay) {
        this.tcpNoDelay = tcpNoDelay;
    }

    public int getReaderIdleTime() {
        return readerIdleTime;
    }

    @Deprecated
    public void setReaderIdleTime(int readerIdleTime) {
        this.readerIdleTime = readerIdleTime;
    }

    public int getWriterIdleTime() {
        return writerIdleTime;
    }

    @Deprecated
    public void setWriterIdleTime(int writerIdleTime) {
        this.writerIdleTime = writerIdleTime;
    }

    public int getSoLinger() {
        return soLinger;
    }

    @Deprecated
    public void setSoLinger(int soLinger) {
        this.soLinger = soLinger;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

}
