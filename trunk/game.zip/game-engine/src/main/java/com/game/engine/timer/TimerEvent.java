package com.game.engine.timer;

/**
 * 定时器
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public abstract class TimerEvent implements Runnable {

    // 定时器结束时间
    private long end;
    // 定时器剩余时间
    private long remain;
    // 定时器循环次数
    private int loop;
    // 定时器循环间隔
    private long delay;

    protected TimerEvent(long end) {
        this.end = end;
        this.loop = 1;
    }

    protected TimerEvent(int loop, long delay) {
        this.loop = loop;
        this.delay = delay;
        this.end = (System.currentTimeMillis() + delay);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public long remain() {
        return this.end - System.currentTimeMillis();
    }

    public long getEnd() {
        return this.end;
    }

    public void setEnd(long end) {
        this.end = end;
    }

    public long getRemain() {
        return this.remain;
    }

    public void setRemain(long remain) {
        this.remain = remain;
    }

    public int getLoop() {
        return this.loop;
    }

    public void setLoop(int loop) {
        this.loop = loop;
        this.end = (System.currentTimeMillis() + this.delay);
    }

    public long getDelay() {
        return this.delay;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }
}
