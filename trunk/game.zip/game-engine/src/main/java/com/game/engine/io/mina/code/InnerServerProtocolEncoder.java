package com.game.engine.io.mina.code;

/**
 * 
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
import com.google.protobuf.Descriptors;
import com.google.protobuf.Message;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InnerServerProtocolEncoder
        implements ProtocolEncoder {

    private static final Logger log = LoggerFactory.getLogger(InnerServerProtocolEncoder.class);

    @Override
    public void dispose(IoSession session)
            throws Exception {
    }

    @Override
    public void encode(IoSession session, Object obj, ProtocolEncoderOutput out)
            throws Exception {
        // 无需考虑发送数据的长度
        if (obj instanceof Message) {
            Message message = (Message) obj;
            // 获得消息ID
            Descriptors.EnumValueDescriptor field = (Descriptors.EnumValueDescriptor) message.getField(message.getDescriptorForType().findFieldByNumber(1));
            int msgID = field.getNumber(); // 100201
            // 获得二进制数据
            byte[] msgData = message.toByteArray();
            int msgDataLength = msgData.length;

            IoBuffer buf = IoBuffer.allocate(8 + msgDataLength); // 4 len + 4 msgID

            buf.setAutoExpand(false);
            buf.setAutoShrink(false);

            buf.putInt(msgDataLength + 4); // 不包含数据长度
            buf.putInt(msgID);
            buf.put(msgData);
            buf.rewind();
            if (session.isConnected()) {
                out.write(buf);
                out.flush();
            }
        } else {
            log.error("未知的数据类型");
        }
    }
}
