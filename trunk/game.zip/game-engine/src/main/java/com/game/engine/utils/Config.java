package com.game.engine.utils;

import java.util.Random;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class Config {

    public static final String CLOSE_COMMAND = "stop server";
    private static final Object obj = new Object();

    private static int id = 0;
    
    public static int serverID = new Random().nextInt(1000000);

    public static long getId() {
        synchronized (obj) {
            id += 1;
            return (serverID & 0xFFFF) << 48 | (System.currentTimeMillis() / 1000L & 0xFFFFFFFF) << 16 | id & 0xFFFF;
        }
    }
}
