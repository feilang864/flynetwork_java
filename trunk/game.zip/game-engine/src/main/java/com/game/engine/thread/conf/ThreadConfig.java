package com.game.engine.thread.conf;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

/**
 * 线程配置
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
@Root
public class ThreadConfig {

    // 线程名字
    @Element(required = true)
    private int name;
    // 心跳
    @Element(required = true)
    private int heart;

    public int getName() {
        return this.name;
    }

    public void setName(int threadName) {
        this.name = threadName;
    }

    public int getHeart() {
        return this.heart;
    }

    public void setHeart(int heart) {
        this.heart = heart;
    }
}
