package com.game.engine.utils;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class PathUtils {

    /**
     * 获取当前运行程序jar包所在路径
     *
     * @return
     */
    public static String getProjectPath() {
        try {
            URL url = PathUtils.class.getProtectionDomain().getCodeSource().getLocation();
            String filePath = URLDecoder.decode(url.getPath(), "UTF-8");
            if (filePath.endsWith(".jar")) {
                filePath = filePath.substring(0, filePath.lastIndexOf("/") + 1);
            }
            return filePath;
        } catch (UnsupportedEncodingException ex) {
        }
        return "";
    }

    /**
     * 返回当前classpath路径
     *
     * @return
     */
    public static String currentPath() {
        try {
            File directory = new File(". ");
            //取得当前路径
            return directory.getCanonicalPath();
        } catch (IOException ex) {
        }
        return "";
    }

    /**
     * 获取一个Class的绝对路径
     *
     * @param clazz
     * @return Class的绝对路径
     *
     */
    public static String getPathByClass(Class clazz) {
        try {
            String path = null;
            URI uri = clazz.getResource("").toURI();
            File file = new File(uri);
            path = file.getCanonicalPath();
            return path;
        } catch (URISyntaxException | IOException ex) {
        }

        return null;
    }

    /**
     * 获取一个文件相对于一个Class相对的绝对路径
     *
     * @param clazz Class对象
     * @param relativePath Class对象的相对路径
     * @return 文件绝对路径
     */
    public static String getFilePathByClass(Class clazz, String relativePath) {
        try {
            String filePath = null;
            String clazzPath = getPathByClass(clazz);
            StringBuilder sbPath = new StringBuilder(clazzPath);
            sbPath.append(File.separator);
            sbPath.append(relativePath);
            File file = new File(sbPath.toString());
            filePath = file.getCanonicalPath();
            return filePath;
        } catch (IOException ex) {
        }
        return "";
    }

//    public static void main(String[] args) {
//        System.out.println(PathUtils.currentPath()); // E:\NetBeansProjects\m1\
//        System.out.println(PathUtils.getProjectPath()); // /E:/NetBeansProjects/m1/target/classes/
//        System.out.println(PathUtils.getPathByClass(PathUtils.class)); // E:\NetBeansProjects\m1\target\classes\com\game\\utils
//        System.out.println(PathUtils.getFilePathByClass(PathUtils.class, "../")); // E:\NetBeansProjects\m1\target\classes\com\game
//    }

}
