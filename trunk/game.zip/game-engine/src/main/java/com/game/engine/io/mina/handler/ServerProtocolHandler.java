package com.game.engine.io.mina.handler;


import com.game.engine.io.commmand.IHandler;
import com.game.engine.io.message.MessageBean;
import com.game.engine.io.message.MessagePool;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import java.util.concurrent.Executor;
import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public abstract class ServerProtocolHandler
        implements IoHandler {

    private static final Logger log = LoggerFactory.getLogger(ServerProtocolHandler.class);
    
    @Override
    public void sessionCreated(IoSession ioSession) throws Exception {
        log.debug(ioSession + " sessionCreated !");
    }

    @Override
    public void sessionOpened(IoSession session) {
        log.debug(session + " sessionOpened !");
    }

    @Override
    public void messageSent(IoSession ioSession, Object message) throws Exception {
        log.debug(ioSession + " messageSent !");
    }

    @Override
    public void sessionClosed(IoSession ioSession) {
        log.debug(ioSession + " sessionClosed !");
    }

    @Override
    public void sessionIdle(IoSession session, IdleStatus idleStatus) {
        log.debug(session + " sessionIdle !", idleStatus);
    }

    @Override
    public void exceptionCaught(IoSession ioSession, Throwable throwable) {
        log.error(ioSession + " exceptionCaught !", throwable);
    }
    
    protected abstract MessagePool getMessagePool();

    private static final boolean DEBUGCOST = true;
    
    @Override
    public void messageReceived(IoSession ioSession, Object obj)
            throws Exception {
        long begin = 0;
        long cost = 0;
        if (DEBUGCOST) {begin = System.currentTimeMillis();}
        
        byte[] bytes = (byte[]) obj;
        int msgID = bytes[3] & 0xFF | (bytes[2] & 0xFF) << 8 | (bytes[1] & 0xFF) << 16 | (bytes[0] & 0xFF) << 24;
        MessageBean messageBean = getMessagePool().getMessageBean(msgID);
        if (messageBean == null) {
            log.error(String.format("MessagePool 未能找到 msgID = %d 的 MessageBean", msgID));
            return;
        }
        
        //生成处理函数
        try {
            Message message = messageBean.buildMessage(bytes, 4, bytes.length - 4);
            
            IHandler handler = messageBean.newHandler();
            if (handler != null) {
                //获取消息体
                // handler.setParameter(null); // TODO 添加Player
                handler.setMessage(message);
                handler.setMapThreadQueue(messageBean.getMapThreadQueue());
                
                handler.setSession(ioSession);
                handler.setCreateTime(System.currentTimeMillis());
                
                Executor executor = getMessagePool().getExecutor(messageBean.getThreadModel());
                executor.execute(handler);
            } else {
                // log.error("MessagePool 未能 msgID = %d 的 Handler");
                // 没有Handler可能似是转发消息
                // TODO 实现消息转发
                doTranspond(ioSession, message);
            }
        } catch (InstantiationException | IllegalAccessException | InvalidProtocolBufferException ex) {
            log.error("messageReceived build message error !!! ", ex);
        }
        
        if(DEBUGCOST) {
            cost = System.currentTimeMillis() - begin;
            if(cost > 2L) {
                log.error(String.format("\t messageReceived %s msgID[%d] builder[%s] cost %d ms", Thread.currentThread().toString(), msgID, messageBean.getBuilder(), cost));
            } else {
                log.debug(String.format("\t messageReceived %s msgID[%d] builder[%s] cost %d ms", Thread.currentThread().toString(), msgID, messageBean.getBuilder(),cost));  // 一般执行下来是0毫秒
            }
            
        }
    }

    /**
     * 转发消息
     * @param ioSession
     * @param message 
     */
    protected abstract void doTranspond(IoSession ioSession, Message message);
}
