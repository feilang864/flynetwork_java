package com.game.engine.timer;

import com.game.engine.script.IBaseScript;
import com.game.engine.script.manager.ScriptManager;
import com.game.engine.timer.script.IServerMinuteTimerEventScript;
import com.game.engine.timer.script.IServerSecondTimerEventScript;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 服务器主定时器
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public class ServerHeartTimer extends TimerEvent {

    protected Logger log = LoggerFactory.getLogger(ServerHeartTimer.class);
    
    protected final int serverId;
    protected final String serverWeb;
    protected int min = -1;
    protected int sec = -1;
    public static boolean GLOBAL_PROTECT = false;

    public ServerHeartTimer(int serverId, String serverWeb) {
	super(-1, 200); // 每200毫秒,无限循环
	this.serverId = serverId;
	this.serverWeb = serverWeb;
    }

    @Override
    public void run() {
	Date curDate = new Date(System.currentTimeMillis());
        if (sec != curDate.getSeconds()) { //每秒钟执行
            List<IBaseScript> evts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(IServerSecondTimerEventScript.class.getName());
            if (evts != null && !evts.isEmpty()) {
                Iterator<IBaseScript> iterator = evts.iterator();
                while (iterator.hasNext()) {
                    IServerSecondTimerEventScript iBaseScript = (IServerSecondTimerEventScript) iterator.next();
                    if (iBaseScript != null) {
                        try {
                            iBaseScript.action(serverId, serverWeb);
                        } catch (Exception e) {
                            log.error("执行脚本异常", e);
                        }
                    }
                }
            }

            sec = curDate.getSeconds();
        } 
        if (min != curDate.getMinutes()) { // 每分钟执行
            List<IBaseScript> evts = ScriptManager.getInstance().getBaseScriptEntry().getEvts(IServerMinuteTimerEventScript.class.getName());
            if (evts != null && !evts.isEmpty()) {
                Iterator<IBaseScript> iterator = evts.iterator();
                while (iterator.hasNext()) {
                    IServerMinuteTimerEventScript iBaseScript = (IServerMinuteTimerEventScript) iterator.next();
                    if (iBaseScript != null) {
                        try {
                            iBaseScript.action(serverId, serverWeb);
                        } catch (Exception e) {
                            log.error("执行脚本异常", e);
                        }
                    }
                }
            }

            min = curDate.getMinutes();
        }
    }

}
