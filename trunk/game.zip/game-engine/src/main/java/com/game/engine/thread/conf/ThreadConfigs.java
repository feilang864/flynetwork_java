package com.game.engine.thread.conf;

import java.util.ArrayList;
import java.util.List;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
@Element
public class ThreadConfigs {

    @ElementList
    private List<ThreadConfig> configs = new ArrayList<>();
    
    // 寻路线程
    @Element(required = false)
    private ThreadConfig runConfig;

    public List<ThreadConfig> getConfigs() {
        return configs;
    }

    public void setConfigs(List<ThreadConfig> threadConfigs) {
        this.configs = threadConfigs;
    }
    
    public ThreadConfig getRunConfig() {
        return runConfig;
    }

    public void setRunConfig(ThreadConfig runConfig) {
        this.runConfig = runConfig;
    }
    
//    public static void main(String[] args) throws Exception {
//        ThreadConfig config = new ThreadConfig();
//        config.setName("Main");
//        config.setHeart(50);
//        ThreadConfigs configs = new ThreadConfigs();
//        configs.getConfigs().add(config);
//        new Persister().write(configs, System.out);
//    }

}
