package com.game.engine.io.message;

import com.game.engine.io.commmand.IHandler;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public interface IMessageBean {

    int getThreadModel();

    /**
     * 获取请求处理对象
     *
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    IHandler newHandler() throws InstantiationException, IllegalAccessException;
    
}
