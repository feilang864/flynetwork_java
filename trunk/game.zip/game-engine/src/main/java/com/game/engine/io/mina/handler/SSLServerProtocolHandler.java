package com.game.engine.io.mina.handler;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public abstract class SSLServerProtocolHandler
        implements IoHandler {

    protected static Logger log = LoggerFactory.getLogger(SSLServerProtocolHandler.class);
    private static final String security_ssl = "<policy-file-request/>";
    private static final String allow_ssl = "";

    @Override
    public void sessionCreated(IoSession ioSession) throws Exception {
        log.debug(ioSession + " sessionCreated !");
    }

    @Override
    public void sessionOpened(IoSession session) {
        log.debug(session + " sessionOpened !");
    }

    @Override
    public void messageSent(IoSession ioSession, Object message) throws Exception {
        log.debug(ioSession + " messageSent !");
        log.error(ioSession + " close by sslsend!");
        ioSession.close(true);
    }

    @Override
    public void sessionClosed(IoSession ioSession) {
        log.debug(ioSession + " sessionClosed !");
    }

    @Override
    public void sessionIdle(IoSession session, IdleStatus idleStatus) {
        log.debug(session + " sessionIdle !", idleStatus);
    }

    @Override
    public void exceptionCaught(IoSession ioSession, Throwable throwable) {
        log.error(ioSession + " exceptionCaught !", throwable);
    }

    @Override
    public void messageReceived(IoSession ioSession, Object message)
            throws Exception {
        IoBuffer buff = (IoBuffer) message;
        buff.flip();

        byte[] bytes = new byte[security_ssl.length()];
        byte[] bytes2 = buff.array();
        System.arraycopy(bytes2, 0, bytes, 0, Math.min(bytes.length, bytes2.length));
        String ssl = new String(bytes);
        log.debug(ioSession + " ssl send:" + ssl + "!");
        if (security_ssl.equals(ssl)) {
            bytes = allow_ssl.getBytes("UTF-8");
            IoBuffer out = IoBuffer.allocate(bytes.length);
            out.put(bytes);
            out.flip();
            ioSession.write(out);
        } else {
            ioSession.close(true);
        }
    }

    public abstract void doCommand(IoSession ioSession, IoBuffer buff);
}
