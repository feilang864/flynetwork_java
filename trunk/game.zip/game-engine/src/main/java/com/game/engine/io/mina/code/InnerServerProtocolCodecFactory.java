package com.game.engine.io.mina.code;

import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
import org.apache.mina.core.session.IoSession;

public class InnerServerProtocolCodecFactory
        implements ProtocolCodecFactory {

    public ProtocolDecoder getDecoder(IoSession session)
            throws Exception {
        return new InnerServerProtocolDecoder();
    }

    public ProtocolEncoder getEncoder(IoSession arg0)
            throws Exception {
        return new InnerServerProtocolEncoder();
    }
}
