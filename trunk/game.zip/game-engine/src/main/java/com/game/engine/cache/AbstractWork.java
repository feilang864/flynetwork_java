package com.game.engine.cache;

import com.game.engine.cache.struct.TasksQueue;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public abstract class AbstractWork
        implements Runnable {

    private TasksQueue<AbstractWork> tasksQueue;

    public TasksQueue<AbstractWork> getTasksQueue() {
        return this.tasksQueue;
    }

    public void setTasksQueue(TasksQueue<AbstractWork> tasksQueue) {
        this.tasksQueue = tasksQueue;
    }
}
