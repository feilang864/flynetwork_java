package com.game.engine.io.conf;

import java.util.HashSet;
import java.util.Set;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
@Root
public class MinaClientConfig extends BaseServerConfig {
    
    @Element(required = true)
    private int zoneid;
    
    @Element(required = true)
    private String zonename;

    @Element(required = true)
    private int receiveBufferSize = 524288;
    
    @Element(required = true)
    private int sendBufferSize = 1048576;
    
    // 客户端线程池大小
    @Element(required = true)
    private int orderedThreadPoolExecutorSize = 150;
    
    @Element(required = true)
    private int soLinger = 0;
    
    @ElementList(required = false)
    private Set<MinaClienConnToConfig> connTos = new HashSet<>();

    public int getZoneid() {
        return zoneid;
    }

    public void setZoneid(int zoneid) {
        this.zoneid = zoneid;
    }

    public String getZonename() {
        return zonename;
    }

    public void setZonename(String zonename) {
        this.zonename = zonename;
    }
    
    public int getReceiveBufferSize() {
        return receiveBufferSize;
    }

    @Deprecated
    public void setReceiveBufferSize(int receiveBufferSize) {
        this.receiveBufferSize = receiveBufferSize;
    }

    public int getSendBufferSize() {
        return sendBufferSize;
    }

    @Deprecated
    public void setSendBufferSize(int sendBufferSize) {
        this.sendBufferSize = sendBufferSize;
    }

    public int getOrderedThreadPoolExecutorSize() {
        return orderedThreadPoolExecutorSize;
    }

    @Deprecated
    public void setOrderedThreadPoolExecutorSize(int orderedThreadPoolExecutorSize) {
        this.orderedThreadPoolExecutorSize = orderedThreadPoolExecutorSize;
    }

    public int getSoLinger() {
        return soLinger;
    }

    @Deprecated
    public void setSoLinger(int soLinger) {
        this.soLinger = soLinger;
    }

    public Set<MinaClienConnToConfig> getConnTos() {
        return connTos;
    }

    public void setConnTos(Set<MinaClienConnToConfig> connTos) {
        this.connTos = connTos;
    }
    
    @Root
    public static class MinaClienConnToConfig extends BaseServerConfig {
        
        // 链接到服务器的类型.如:
        //  网关服务器GateServer 1
        //  游戏服务器GameServer 2
        //  数据服务器DataServer 3
        //  公共数据服务器PublicDataServer 4
        //  公公逻辑服务器PublicGameServer 5
        //  公共聊天服务器PublicChatServer 6
        //  ...
        @Element(required = true)
        private int type;
        
        // 链接到服务器的地址
        @Element(required = true)
        private String host;
        
        // 链接到服务器的端口
        @Element(required = true)
        private int port;

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }
        
        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public int getPort() {
            return port;
        }

        public void setPort(int port) {
            this.port = port;
        }

        @Override
        public int hashCode() {
            int hash = 5;
            hash = 47 * hash + this.type;
            hash = 47 * hash + this.id;
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final MinaClienConnToConfig other = (MinaClienConnToConfig) obj;
            if (this.type != other.type) {
                return false;
            }
            if (this.id != other.id) {
                return false;
            }
            return true;
        }

    }
}

