package com.game.engine.io.commmand.filter;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 */
public interface IRunnableFilter {
    
    boolean filter(Runnable runnable);
}
