package com.game.engine.thread.map;

import com.game.engine.io.commmand.IHandler;
import com.game.engine.thread.RunningThread;
import com.game.engine.thread.ServerThread;
import com.game.engine.thread.conf.ThreadConfig;
import com.game.engine.thread.conf.ThreadConfigs;
import com.game.engine.thread.map.conf.MapConfig;
import com.game.engine.thread.map.conf.MapConfigs;
import com.game.engine.utils.PathUtils;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.simpleframework.xml.core.Persister;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * @author Vicky
 */
public abstract class MapServer extends Thread {
    
    private static final Logger log = LoggerFactory.getLogger(MapServer.class);

    // 地图/副本唯一
    private final long zoneId;
    // 地图/副本配置ID
    private final int zoneModelId;
    // 地图配置,一个地图服务器线程可以管理多个地图,比如说一个玩家进入的副本,包含多个场景.那么这些场景地图,都由这一个线程管理
    private final MapConfigs mapConfigs;
    
    // 线程池
    protected final Map<Integer, ServerThread> thread_pool = new HashMap<>();
    // 线程组
    protected final ThreadGroup thread_group;
    
    // 地图服务器的主线程,每个地图服务器都应该有一个叫Main
    public static final int MAINTHREAD = 0; //"Main";
    
    // 地图寻路线程(主要是计算玩家当前坐标点,根据具体的寻路规则确认是否开启,如:如果说是客户端每200ms同步一次玩家坐标,那么就不需要该线程,相反则需要服务器定时器)
    public static final int RUNNINGTHREAD = 1; //"Runn";
    
    private RunningThread runningThread; // 寻路线程
    
    // 默认配置文件名
    private static final String defaultThreadConfigFile = "thread-config.xml";

    protected MapServer(String name, long zoneId, int zoneModelId, MapConfigs mapConfigs) {
        this(name, zoneId, zoneModelId, mapConfigs, defaultThreadConfigFile);
    }

    /**
     * @param name 名称
     * @param zoneId 地图/副本唯一
     * @param zoneModelId 地图/副本配置ID
     * @param mapConfigs 地图配置
     * @param threadConfig 线程配置
     */
    protected MapServer(String name, long zoneId, int zoneModelId, MapConfigs mapConfigs, String threadConfig) {
        super(name);
        this.zoneId = zoneId;
        this.zoneModelId = zoneModelId;
        this.mapConfigs = mapConfigs;
        
        // 通过配置路径创建线程配置对象
        if (threadConfig == null || threadConfig.trim().equals("")) {
            threadConfig = defaultThreadConfigFile;
        }
        
        // 初始化线程组
        this.thread_group = new ThreadGroup(name);
        
        try {
            File configFile = new File(threadConfig);
            if (!configFile.exists()) {
                threadConfig = PathUtils.getProjectPath() + threadConfig;
                configFile = new File(threadConfig);
                if (!configFile.exists()) {
                    log.error("无法找到线程"+threadConfig+"配置!");
                    System.exit(1);
                }
            }
            ThreadConfigs threadConfigs = new Persister().read(ThreadConfigs.class, new File(threadConfig));
            // 通过线程配置,创建线程对象,并添加到线程池中
            for (ThreadConfig config : threadConfigs.getConfigs()) {
                ServerThread thread = new ServerThread(this.thread_group, name + "MainThread", config.getHeart());
                this.thread_pool.put(config.getName(), thread);
            }
            
            ThreadConfig runConfig = threadConfigs.getRunConfig();
            if (runConfig != null) {
                log.warn("创建了地图寻路线程");
                runningThread = new RunningThread(thread_group, name + "RunningThread", runConfig.getHeart());
            } else {
                log.warn("未地图寻路线程");
            }
            
            init();
        } catch (Exception e) {
            log.error("反序列化地图服务器线程配置失败!!!", e);
        }
    }

    /**
     * 子类实现初始化
     */
    protected abstract void init();

    /**
     * 运行地图服务器中的所有线程
     */
    @Override
    public void run() {
        Iterator<ServerThread> iter = this.thread_pool.values().iterator();
        while (iter.hasNext()) {
            Thread thread = (Thread) iter.next();
            thread.start();
        }
        if (runningThread != null) {
            runningThread.start();
        }
    }

    /**
     * 停止地图服务器中的所有线程
     * @param flag 
     */
    public void stop(boolean flag) {
        Iterator<ServerThread> iter = this.thread_pool.values().iterator();
        while (iter.hasNext()) {
            ServerThread thread = (ServerThread) iter.next();
            thread.stop(true);
        }
    }

    public void addCommand(IHandler handler) {
        ServerThread thread = null;
        int mapThreadQueue = handler.getMapThreadQueue();
        thread = this.thread_pool.get(mapThreadQueue);
        if (thread == null) {
            log.warn("地图:" + getName() + " 线程模型:" + mapThreadQueue + " 找不到!!!");
            thread = this.thread_pool.get(MAINTHREAD/*"Main"*/);
        }
        
        if (thread != null) {
            thread.addCommand(handler);
        } else {
            log.error("无法找到地图服务器" + getName() + "处理消息的" + handler.getMapThreadQueue() + "线程!!!");
            handler.run();
        }
    }

    public List<MapConfig> getMapConfigs() {
        return this.mapConfigs.getMapConfigs();
    }

    public long getZoneId() {
        return this.zoneId;
    }

    public int getZoneModelId() {
        return this.zoneModelId;
    }
}
