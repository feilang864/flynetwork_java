package com.game.engine.io.mina.impl;

import com.game.engine.io.conf.MinaClientConfig;
import com.game.engine.io.mina.code.InnerServerProtocolCodecFactory;
import com.game.engine.io.mina.handler.ClientProtocolHandler;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.executor.ExecutorFilter;
import org.apache.mina.filter.executor.OrderedThreadPoolExecutor;
import org.apache.mina.transport.socket.SocketSessionConfig;
import org.apache.mina.transport.socket.nio.NioSocketConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail eclipser@163.com
 * @phone 13618074943
 */
public class MinaClient implements Runnable {

    public interface ClientCallbackHanlder {

        void connectComplete();

        void register(int type, int id, String ip, int port, IoSession session);
    }

    private static final Logger log = LoggerFactory.getLogger(MinaClient.class);

    // 类型 (服务器=具体Session)
    private final Map<Integer, Map<Integer, IoSession>> type_id_sessions = new HashMap<>();

    private NioSocketConnector connector = null;

    private final MinaClientConfig minaClientConfig;
    private final ClientProtocolHandler clientProtocolHandler;
    private final ClientCallbackHanlder callBackHandler;

    protected boolean isRunning = false;

    public MinaClient(MinaClientConfig minaClientConfig, ClientProtocolHandler clientProtocolHandler, ClientCallbackHanlder callBack) {
        this.minaClientConfig = minaClientConfig;
        this.clientProtocolHandler = clientProtocolHandler;
        this.callBackHandler = callBack;
    }

    @Override
    public void run() {
        synchronized (this) {
            if (!isRunning) {
                isRunning = true;
                this.connector = new NioSocketConnector();
                this.connector.getFilterChain().addLast("codec", new ProtocolCodecFilter(new InnerServerProtocolCodecFactory()));

                OrderedThreadPoolExecutor threadpool = new OrderedThreadPoolExecutor(minaClientConfig.getOrderedThreadPoolExecutorSize()); //  150
                this.connector.getFilterChain().addLast("threadPool", new ExecutorFilter(threadpool));

                SocketSessionConfig sc = this.connector.getSessionConfig();
                sc.setReceiveBufferSize(minaClientConfig.getReceiveBufferSize()); // 524288
                sc.setSendBufferSize(minaClientConfig.getSendBufferSize()); // 1048576

                sc.setSoLinger(minaClientConfig.getSoLinger()); // 0

                this.connector.setHandler(clientProtocolHandler);

                if (minaClientConfig != null) {
                    log.warn("开始链接其他服务器,共 [" + minaClientConfig.getConnTos().size() + "] 个");
                    for (MinaClientConfig.MinaClienConnToConfig connTo : minaClientConfig.getConnTos()) {
                        switch (connTo.getType()) {
                    //  网关服务器GateServer 1
                            //  游戏服务器GameServer 2
                            //  数据服务器DataServer 3
                            //  公共数据服务器PublicDataServer 4
                            //  公公逻辑服务器PublicGameServer 5
                            //  公共聊天服务器PublicChatServer 6
                            //  ...
                            case 1:
                                log.warn("链接 网关服务器GateServer" + connTo);
                                break;
                            case 2:
                                log.warn("链接 游戏服务器GameServer" + connTo);
                                break;
                            case 3:
                                log.warn("链接 数据服务器DataServer" + connTo);
                                break;
                            case 4:
                                log.warn("链接 公共数据服务器PublicDataServer" + connTo);
                                break;
                            case 5:
                                log.warn("链接 公公逻辑服务器PublicGameServer" + connTo);
                                break;
                            case 6:
                                log.warn("链接 公共聊天服务器PublicChatServer" + connTo);
                                break;
                            default:
                                log.error("未知的游戏服务器类型");
                                break;
                        }

                        ConnectFuture connect = this.connector.connect(new InetSocketAddress(connTo.getHost(), connTo.getPort()));
                        connect.awaitUninterruptibly();
                        if (!connect.isConnected()) {
                            log.error("链接服务器失败!!!!!!" + connTo);
                        } else {
                            IoSession session = connect.getSession();
                            session.setAttribute("connect-server-type", connTo.getType());
                            session.setAttribute("connect-server-id", connTo.getId());
                            session.setAttribute("connect-server-ip", connTo.getHost());
                            session.setAttribute("connect-server-port", connTo.getPort());

                            addSession(connTo.getType(), connTo.getId(), session);
                            callBackHandler.register(connTo.getType(), connTo.getId(), connTo.getHost(), connTo.getPort(), session);
                        }
                    }
                }
                callBackHandler.connectComplete();
            }
        }
    }

    public void stop() {
        synchronized (this) {
            if (!isRunning) {
                log.info("Client " + minaClientConfig.getName() + "is already stoped.");
                return;
            }
            isRunning = false;
            try {
                connector.dispose();
                log.info("Client is stoped.");
            } catch (Exception ex) {
                log.error("", ex);
            }
        }
    }

    public boolean reconnect(int type, int id, String ip, int port) {
        removeSession(type, id);

        ConnectFuture connect = this.connector.connect(new InetSocketAddress(ip, port));
        connect.awaitUninterruptibly(30000L);
        if (!connect.isConnected()) {
            log.error("重新链接服务器失败!!!!!!");
            return false;
        } else {
            IoSession session = connect.getSession();
            session.setAttribute("connect-server-type", type);
            session.setAttribute("connect-server-id", id);
            session.setAttribute("connect-server-ip", ip);
            session.setAttribute("connect-server-port", port);

            addSession(type, id, session);
            callBackHandler.register(type, id, ip, port, session);
            return true;
        }
    }

    public void removeSession(int type, int id) {
        synchronized (type_id_sessions) {
            Map<Integer, IoSession> id_sessions = type_id_sessions.get(type);
            if (id_sessions == null) {
                return;
            }

            IoSession oldSession = id_sessions.get(id);
            if (oldSession == null) {
                return;
            }

            id_sessions.remove(id);
        }
    }

    public boolean addSession(int type, int id, IoSession session) {
        synchronized (type_id_sessions) {
            Map<Integer, IoSession> id_sessions = type_id_sessions.get(type);
            if (id_sessions == null) {
                id_sessions = new HashMap<>();
                type_id_sessions.put(type, id_sessions);
            }

            IoSession oldSession = id_sessions.get(id);
            if (oldSession != null) {
                if (oldSession.isConnected()) {
                    log.error("再建立新的链接的时候,发现该配置和的链接已存在,并且还保持着链接,添加失败:" + type + " " + id + " " + session);
                    return false;
                } else {
                    log.error("再建立新的链接的时候,发现该配置和的链接已存在,但未保持着链接,更新:" + type + " " + id + " " + session);
                    id_sessions.remove(id);
                    id_sessions.put(id, session);
                }
            }
        }
        return true;
    }

}
