package com.game.engine.io.message;

import com.game.engine.io.commmand.IHandler;
import com.game.engine.thread.map.MapServer;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import org.apache.mina.core.buffer.IoBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Vicky
 * @mail   eclipser@163.com
 * @phone  13618074943
 * 
 * @param <MSG> 消息类型
 * @param <MSGHANDLER> Handler类型
 * @param <MSG4RES> 返回消息类型
 * @param <MSGHANDLER4RES> 返回消息构造器
 */
public class MessageBean<MSG, MSGHANDLER, MSG4RES, MSGHANDLER4RES> implements IMessageBean {
    
    private static final Logger log = LoggerFactory.getLogger(MessageBean.class);

    private final Class<? extends Message> messageClass;   // 消息类型
    private final Class<? extends IHandler> handlerClass;   // Handler类型
    private final int threadModel;                         // 线程模型 0 表示默认的地图线程处理
    
    private final Message.Builder builder;                 // 消息构造器
    
    //private final Class<? extends Message> messageClass4Res;    // 返回消息类型
    //private final Message.Builder builder4Res;                  // 返回消息构造器
    private final int mapThreadQueue;       // mapThreadQueue 协议请求地图服务器中的具体线程,默认情况下,每个地图服务器都有切只有一个Main线程.
                                            // 一般情况下玩家在地图的请求,都是Main线程处理的,然而某些地图,可能会使用多个线程来处理大模块的功能.
    

    public MessageBean(Class<? extends Message> messageClass, Class<? extends IHandler> handlerClass, int threadModel, Message.Builder builder
        //    , Class<? extends Message> messageClass4Res
        //    , Message.Builder builder4Res
            , int mapThreadQueue) { 
                            
        this.messageClass = messageClass;
        this.handlerClass = handlerClass;
        this.threadModel = threadModel;
        this.builder = builder;
        
        //this.messageClass4Res = messageClass4Res;
        //this.builder4Res = builder4Res;
        this.mapThreadQueue = mapThreadQueue;
    }

    @Override
    public int getThreadModel() {
        return threadModel;
    }
    
    /**
     * 未反序列化,仅仅是新建消息体
     * 
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws InvalidProtocolBufferException 
     */
    public Message buildMessage() throws InstantiationException, IllegalAccessException, InvalidProtocolBufferException {
        Message.Builder cloneBuilder = this.builder.clone();
        cloneBuilder.clear();
        return cloneBuilder.build();
    }
    
    /**
     * 反序列化,获取消息体
     *
     * @param ioBuffer
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws com.google.protobuf.InvalidProtocolBufferException
     */
    public Message buildMessage(IoBuffer ioBuffer) throws InstantiationException, IllegalAccessException, InvalidProtocolBufferException {
        int size = ioBuffer.remaining();
        byte[] messageData = new byte[size];
        ioBuffer.get(messageData);
        
        // TODO builder是否需要考虑对象池,以保证线程安全以及效率,有待测试
        Message.Builder cloneBuilder = this.builder.clone();
//        cloneBuilder.clear();
        cloneBuilder.mergeFrom(messageData);
        return cloneBuilder.build();
    }
    
    /**
     * 反序列化,获取消息体
     * 
     * @param data 数据源,可能包含msgID
     * @param off
     * @param len
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws InvalidProtocolBufferException 
     */
    public Message buildMessage(byte[] data, int off, int len) throws InstantiationException, IllegalAccessException, InvalidProtocolBufferException {
        
        // TODO builder是否需要考虑对象池,以保证线程安全以及效率,有待测试
        Message.Builder cloneBuilder = this.builder.clone();
//        cloneBuilder.clear();
        cloneBuilder.mergeFrom(data, off, len);
        return cloneBuilder.build();
    }
    
    /**
     * 获取请求处理对象
     *
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    @Override
    public IHandler newHandler() throws InstantiationException, IllegalAccessException {
        if (handlerClass == null) return null;
        return handlerClass.newInstance();
    }

    
//    /**
//     * 
//     * @return 
//     */
//    public Message buildMessage4Res() {
//        if (messageClass4Res != null && builder4Res != null) {
//            Message.Builder cloneBuilder = builder4Res.clone();
////            cloneBuilder.clear();
//            return cloneBuilder.build();
//        }
//        return null;
//    }

    /**
     * 获得请求消息构造器
     * @return 
     */
    public Message.Builder getBuilder() {
        return builder.clone();
    }

//    /**
//     * 获得响应消息构造器
//     * @return 
//     */
//    public Message.Builder getBuilder4Res() {
//        return builder4Res.clone();
//    }

    public int getMapThreadQueue() {
        return mapThreadQueue;
    }
    
}
